/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { CustomerView } from './components/CustomerPortal/CustomerView';
import { AdminDashboard } from './components/AdminPortal/AdminDashboard';
import { DriverView } from './components/DriverApp/DriverView';
import { OnboardingTour } from './components/OnboardingTour';

const AppContent: React.FC = () => {
  const { currentView } = useApp();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar />

      {/* Main View Router */}
      <div className="flex-1 flex flex-col">
        {currentView === 'customer' && <CustomerView />}
        {currentView === 'admin' && <AdminDashboard />}
        {currentView === 'driver' && <DriverView />}
      </div>

      {/* Interactive Walkthrough Tour */}
      <OnboardingTour />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
