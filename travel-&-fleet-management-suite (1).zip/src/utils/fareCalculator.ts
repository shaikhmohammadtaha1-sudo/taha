import { Vehicle, WebsiteCMS } from '../types';

export interface RouteEstimate {
  distanceKm: number;
  durationHrs: number;
  tollEstimate: number;
  routeSummary: string;
}

// Popular predefined routes across India with realistic highway distances & toll counts
export const POPULAR_ROUTES: Record<string, RouteEstimate> = {
  'mumbai_pune': { distanceKm: 155, durationHrs: 3.2, tollEstimate: 320, routeSummary: 'Mumbai-Pune Expressway' },
  'mumbai_shirwal': { distanceKm: 164, durationHrs: 3.5, tollEstimate: 350, routeSummary: 'Mumbai-Pune-Satara Highway' },
  'pune_shirwal': { distanceKm: 55, durationHrs: 1.2, tollEstimate: 110, routeSummary: 'NH 48 Pune-Satara Road' },
  'mumbai_lonavala': { distanceKm: 85, durationHrs: 2.0, tollEstimate: 240, routeSummary: 'Mumbai-Pune Expressway Ghats' },
  'mumbai_shirdi': { distanceKm: 240, durationHrs: 4.8, tollEstimate: 420, routeSummary: 'Samruddhi Mahamarg / NH 160' },
  'delhi_agra': { distanceKm: 235, durationHrs: 3.8, tollEstimate: 450, routeSummary: 'Yamuna Expressway' },
  'delhi_jaipur': { distanceKm: 280, durationHrs: 4.5, tollEstimate: 420, routeSummary: 'NH 48 Delhi-Jaipur Highway' },
  'bangalore_mysore': { distanceKm: 145, durationHrs: 2.5, tollEstimate: 280, routeSummary: 'Bengaluru-Mysuru Access Highway' },
  'chennai_pondicherry': { distanceKm: 165, durationHrs: 3.5, tollEstimate: 190, routeSummary: 'East Coast Road (ECR)' },
  'hyderabad_vijayawada': { distanceKm: 275, durationHrs: 4.8, tollEstimate: 390, routeSummary: 'NH 65 Highway' },
  'ahmedabad_surat': { distanceKm: 260, durationHrs: 4.0, tollEstimate: 360, routeSummary: 'NE 1 & NH 48' },
  'chandigarh_shimla': { distanceKm: 115, durationHrs: 3.8, tollEstimate: 150, routeSummary: 'Himalayan Expressway NH 5' },
};

export function estimateRouteDetails(pickup: string, drop: string, tripType: string): RouteEstimate {
  const pNorm = pickup.toLowerCase().trim();
  const dNorm = drop.toLowerCase().trim();

  // Daily point-to-point city rides default distance (e.g. 8-18 km in city)
  if (tripType === 'daily_ride') {
    const charSum = (pNorm + dNorm).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const cityDist = 8 + (charSum % 22); // between 8 km and 30 km
    const cityMins = Math.round(cityDist * 2.8); // city traffic approx 20 km/h
    return {
      distanceKm: cityDist,
      durationHrs: Number((cityMins / 60).toFixed(1)),
      tollEstimate: 0,
      routeSummary: 'City Direct Route',
    };
  }

  // Check matching predefined outstation keys
  for (const [key, val] of Object.entries(POPULAR_ROUTES)) {
    const [c1, c2] = key.split('_');
    if ((pNorm.includes(c1) && dNorm.includes(c2)) || (pNorm.includes(c2) && dNorm.includes(c1))) {
      const isRound = tripType === 'round_trip';
      const mult = isRound ? 2 : 1;
      return {
        distanceKm: Math.round(val.distanceKm * mult),
        durationHrs: Number((val.durationHrs * (isRound ? 1.8 : 1)).toFixed(1)),
        tollEstimate: Math.round(val.tollEstimate * mult),
        routeSummary: val.routeSummary,
      };
    }
  }

  // Local Rental 8hr/80km default
  if (tripType === 'local_rental') {
    return {
      distanceKm: 80,
      durationHrs: 8.0,
      tollEstimate: 80,
      routeSummary: 'City Full Day Rental (8 Hrs / 80 Km Package)',
    };
  }

  // Outstation fallback calculation
  const charSum = (pNorm + dNorm).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const baseOneWayDist = 80 + (charSum % 220);
  const isRound = tripType === 'round_trip';
  const dist = isRound ? baseOneWayDist * 2 : baseOneWayDist;
  const hrs = Number((dist / 55).toFixed(1));
  const tolls = Math.round((dist / 70) * 85);

  return {
    distanceKm: dist,
    durationHrs: Math.max(1.5, hrs),
    tollEstimate: tolls,
    routeSummary: `National Highway Route (${dist} km)`,
  };
}

export interface FareCalculationResult {
  tripType: string;
  distanceKm: number;
  billableDistanceKm: number;
  minKmPerDay: number;
  days: number;
  perKmRate: number;
  distanceFareComponent: number;
  baseFareComponent: number;
  fuelComponentEstimate: number;
  tollEstimate: number;
  driverAllowance: number;
  driverAllowancePerDay: number;
  nightCharge: number;
  taxAmount: number;
  totalFare: number;
  estimatedDriverProfit: number;
  breakup: {
    label: string;
    description: string;
    amount: number;
  }[];
}

export function calculateDetailedFare(
  vehicle: Vehicle,
  cms: WebsiteCMS,
  distanceKm: number,
  tripType: string,
  pickupTime: string,
  returnDate?: string,
  pickupDate?: string,
  extraHours: number = 0
): FareCalculationResult {
  const isNight = isNightTime(pickupTime);
  const nightCharge = isNight ? (cms.driverNightAllowanceRate || 250) : 0;

  // ==========================================
  // 1. DAILY RIDES (NORMAL POINT-TO-POINT CITY PRICING)
  // No 250km minimum, no driver outstation batta, normal city pricing!
  // ==========================================
  if (tripType === 'daily_ride') {
    // Normal city base fare (first 2 km included)
    const baseCityFareMap: Record<string, number> = {
      hatchback: 60,
      sedan: 80,
      suv: 120,
      luxury_suv: 180,
      luxury: 300,
      tempo_traveller: 400,
    };
    const cityBaseFare = baseCityFareMap[vehicle.category] || baseCityFareMap[vehicle.id] || 80;
    const cityPerKmRate = vehicle.localExtraKmRate || vehicle.ratePerKm || 13;
    
    // Distance beyond base 2 km
    const billableExtraKm = Math.max(0, distanceKm - 2);
    const distanceFareComponent = Math.round(billableExtraKm * cityPerKmRate);
    const subtotal = cityBaseFare + distanceFareComponent + (isNight ? 50 : 0);
    const taxAmount = Math.round((subtotal * (cms.defaultTaxPct || 5)) / 100);
    const totalFare = Math.round(subtotal + taxAmount);

    const litersConsumed = distanceKm / Math.max(6, vehicle.fuelEfficiencyKmPerL || 18);
    const fuelComponentEstimate = Math.round(litersConsumed * (cms.fuelIndexPrice || 95));

    const breakup = [
      {
        label: 'Base Fare (First 2 km incl.)',
        description: 'Standard city flag-drop fare',
        amount: cityBaseFare,
      },
    ];

    if (billableExtraKm > 0) {
      breakup.push({
        label: `Distance Charge (${billableExtraKm} km @ ₹${cityPerKmRate}/km)`,
        description: `Kilometers beyond base 2 km (${distanceKm} km total)`,
        amount: distanceFareComponent,
      });
    }

    if (isNight) {
      breakup.push({
        label: 'Night Time Convenience Charge',
        description: 'City night ride charge (10 PM - 6 AM)',
        amount: 50,
      });
    }

    breakup.push({
      label: `GST (${cms.defaultTaxPct || 5}%)`,
      description: 'Government Goods & Services Tax',
      amount: taxAmount,
    });

    return {
      tripType: 'daily_ride',
      distanceKm,
      billableDistanceKm: distanceKm,
      minKmPerDay: 2,
      days: 1,
      perKmRate: cityPerKmRate,
      distanceFareComponent,
      baseFareComponent: cityBaseFare,
      fuelComponentEstimate,
      tollEstimate: 0,
      driverAllowance: 0,
      driverAllowancePerDay: 0,
      nightCharge: isNight ? 50 : 0,
      taxAmount,
      totalFare,
      estimatedDriverProfit: Math.max(0, totalFare - fuelComponentEstimate - 30),
      breakup,
    };
  }

  // ==========================================
  // 2. OUTSTATION ROUND TRIP
  // Outstation min km per day (250/300 km) + Per-KM Rate + Driver Batta/day + Fastag Tolls
  // ==========================================
  if (tripType === 'round_trip') {
    let days = 1;
    if (pickupDate && returnDate && returnDate >= pickupDate) {
      const d1 = new Date(pickupDate);
      const d2 = new Date(returnDate);
      const diffDays = Math.ceil((d2.getTime() - d1.getTime()) / (1000 * 3600 * 24)) + 1;
      days = Math.max(1, diffDays);
    }

    const minKmPerDay = vehicle.outstationMinKmPerDay || 250;
    const minTotalKm = minKmPerDay * days;
    const billableDistanceKm = Math.max(distanceKm, minTotalKm);
    const perKmRate = vehicle.outstationPerKmRate || vehicle.ratePerKm || 13;
    const distanceFareComponent = Math.round(billableDistanceKm * perKmRate);
    const driverAllowancePerDay = vehicle.driverAllowancePerDay || 350;
    const driverAllowance = driverAllowancePerDay * days;
    const tollEstimate = Math.round((distanceKm / 75) * 80);

    const subtotal = distanceFareComponent + driverAllowance + nightCharge + tollEstimate;
    const taxAmount = Math.round((subtotal * (cms.defaultTaxPct || 5)) / 100);
    const totalFare = Math.round(subtotal + taxAmount);

    const litersConsumed = distanceKm / Math.max(6, vehicle.fuelEfficiencyKmPerL || 15);
    const fuelComponentEstimate = Math.round(litersConsumed * (cms.fuelIndexPrice || 95));
    const operatingCost = fuelComponentEstimate + tollEstimate + driverAllowance * 0.8;
    const estimatedDriverProfit = Math.max(0, totalFare - operatingCost);

    const breakup = [
      {
        label: `Base Distance Fare (${billableDistanceKm} km @ ₹${perKmRate}/km)`,
        description: billableDistanceKm > distanceKm ? `Minimum ${minKmPerDay} km/day applied for ${days} day(s)` : `${distanceKm} km round trip`,
        amount: distanceFareComponent,
      },
      {
        label: `Driver Allowance / Batta (${days} day${days > 1 ? 's' : ''})`,
        description: `₹${driverAllowancePerDay}/day for ${days} day(s)`,
        amount: driverAllowance,
      },
      {
        label: 'Fastag Tolls & Highway Taxes',
        description: 'Estimated standard highway toll plaza charges',
        amount: tollEstimate,
      },
    ];

    if (nightCharge > 0) {
      breakup.push({
        label: 'Night Driving Allowance',
        description: 'Applies between 10:00 PM and 6:00 AM',
        amount: nightCharge,
      });
    }

    breakup.push({
      label: `GST (${cms.defaultTaxPct || 5}%)`,
      description: 'Government Goods & Services Tax',
      amount: taxAmount,
    });

    return {
      tripType,
      distanceKm,
      billableDistanceKm,
      minKmPerDay,
      days,
      perKmRate,
      distanceFareComponent,
      baseFareComponent: 0,
      fuelComponentEstimate,
      tollEstimate,
      driverAllowance,
      driverAllowancePerDay,
      nightCharge,
      taxAmount,
      totalFare,
      estimatedDriverProfit,
      breakup,
    };
  }

  // ==========================================
  // 3. OUTSTATION ONE WAY
  // Intercity one way direct ride with outstation rate & single-day chauffeur allowance
  // ==========================================
  if (tripType === 'one_way' || tripType === 'outstation_tour') {
    const perKmRate = vehicle.outstationPerKmRate || vehicle.ratePerKm || 13;
    const billableDistanceKm = Math.max(distanceKm, 100);
    const distanceFareComponent = Math.round(billableDistanceKm * perKmRate);
    const driverAllowancePerDay = vehicle.driverAllowancePerDay || 300;
    const driverAllowance = driverAllowancePerDay;
    const tollEstimate = Math.round((distanceKm / 75) * 80);

    const subtotal = distanceFareComponent + driverAllowance + nightCharge + tollEstimate;
    const taxAmount = Math.round((subtotal * (cms.defaultTaxPct || 5)) / 100);
    const totalFare = Math.round(subtotal + taxAmount);

    const litersConsumed = distanceKm / Math.max(6, vehicle.fuelEfficiencyKmPerL || 15);
    const fuelComponentEstimate = Math.round(litersConsumed * (cms.fuelIndexPrice || 95));
    const operatingCost = fuelComponentEstimate + tollEstimate + driverAllowance * 0.8;
    const estimatedDriverProfit = Math.max(0, totalFare - operatingCost);

    const breakup = [
      {
        label: `Base Distance Fare (${billableDistanceKm} km @ ₹${perKmRate}/km)`,
        description: `One way direct route: ${distanceKm} km`,
        amount: distanceFareComponent,
      },
      {
        label: 'Driver Allowance (Batta)',
        description: 'Single day outstation chauffeur allowance',
        amount: driverAllowance,
      },
      {
        label: 'Highway Tolls & Fastag (Est.)',
        description: 'Toll plaza charges along highway route',
        amount: tollEstimate,
      },
    ];

    if (nightCharge > 0) {
      breakup.push({
        label: 'Night Driving Allowance',
        description: 'Applies between 10:00 PM and 6:00 AM',
        amount: nightCharge,
      });
    }

    breakup.push({
      label: `GST (${cms.defaultTaxPct || 5}%)`,
      description: 'Government Goods & Services Tax',
      amount: taxAmount,
    });

    return {
      tripType,
      distanceKm,
      billableDistanceKm,
      minKmPerDay: vehicle.outstationMinKmPerDay || 250,
      days: 1,
      perKmRate,
      distanceFareComponent,
      baseFareComponent: 0,
      fuelComponentEstimate,
      tollEstimate,
      driverAllowance,
      driverAllowancePerDay,
      nightCharge,
      taxAmount,
      totalFare,
      estimatedDriverProfit,
      breakup,
    };
  }

  // ==========================================
  // 4. LOCAL RENTALS (8 HRS / 80 KM PACKAGE)
  // Base 8h/80km package + Extra KM + Extra Hr rates
  // ==========================================
  const localBase = vehicle.localBaseFare8hr80km || 2200;
  const extraKm = Math.max(0, distanceKm - 80);
  const extraKmCharge = extraKm * (vehicle.localExtraKmRate || 13);
  const extraHrCharge = extraHours * (vehicle.localExtraHrRate || 110);
  const subtotal = localBase + extraKmCharge + extraHrCharge + nightCharge;
  const taxAmount = Math.round((subtotal * (cms.defaultTaxPct || 5)) / 100);
  const totalFare = Math.round(subtotal + taxAmount);

  const litersConsumed = distanceKm / Math.max(6, vehicle.fuelEfficiencyKmPerL || 15);
  const fuelComponentEstimate = Math.round(litersConsumed * (cms.fuelIndexPrice || 95));

  const breakup = [
    {
      label: 'Local Base Package (8 hrs / 80 km)',
      description: 'Standard city rental package included',
      amount: localBase,
    },
  ];

  if (extraKm > 0) {
    breakup.push({
      label: `Extra Distance (${extraKm} km @ ₹${vehicle.localExtraKmRate || 13}/km)`,
      description: 'Kilometers beyond 80 km package',
      amount: extraKmCharge,
    });
  }

  if (extraHours > 0) {
    breakup.push({
      label: `Extra Time (${extraHours} hrs @ ₹${vehicle.localExtraHrRate || 110}/hr)`,
      description: 'Hours beyond 8 hrs package',
      amount: extraHrCharge,
    });
  }

  breakup.push({
    label: `GST (${cms.defaultTaxPct || 5}%)`,
    description: 'Government Goods & Services Tax',
    amount: taxAmount,
  });

  return {
    tripType: 'local_rental',
    distanceKm,
    billableDistanceKm: distanceKm,
    minKmPerDay: 80,
    days: 1,
    perKmRate: vehicle.localExtraKmRate || 13,
    distanceFareComponent: extraKmCharge,
    baseFareComponent: localBase,
    fuelComponentEstimate,
    tollEstimate: 0,
    driverAllowance: 0,
    driverAllowancePerDay: 0,
    nightCharge,
    taxAmount,
    totalFare,
    estimatedDriverProfit: Math.max(0, totalFare - fuelComponentEstimate - 200),
    breakup,
  };
}

function isNightTime(timeStr: string): boolean {
  if (!timeStr) return false;
  const [hour] = timeStr.split(':').map(Number);
  return hour >= 22 || hour < 6;
}
