import * as XLSX from 'xlsx';
import { Inquiry, TripFinancialRecord, Vehicle, MaintenanceLog } from '../types';

/**
 * Exports data to an Excel file (.xlsx) with styled sheets
 */
export function exportToExcel(data: Record<string, unknown>[], fileName: string, sheetName = 'Sheet1') {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, `${fileName}.xlsx`);
}

/**
 * Export Financial Profit & Loss Statement
 */
export function exportProfitLossExcel(trips: TripFinancialRecord[], startDate?: string, endDate?: string) {
  const formattedRows = trips.map((t, idx) => ({
    'Sr No': idx + 1,
    'Trip ID': t.tripNumber,
    'Date': t.date,
    'Customer': t.customerName,
    'Route': `${t.pickupLocation} -> ${t.dropLocation}`,
    'Vehicle Plate': t.vehiclePlate,
    'Driver': t.driverName,
    'Distance (KM)': t.distanceKm,
    'Gross Revenue (₹)': t.revenue,
    'Fuel Cost (₹)': t.fuelExpense,
    'Tolls & Taxes (₹)': t.tollExpense,
    'Driver Payout (₹)': t.driverPayout,
    'Maintenance Allocation (₹)': t.maintenanceAllocated,
    'Other Expenses (₹)': t.otherExpense,
    'Net Profit (₹)': t.netProfit,
    'Profit Margin %': t.revenue > 0 ? `${((t.netProfit / t.revenue) * 100).toFixed(1)}%` : '0%',
    'Payment Status': t.paymentStatus.toUpperCase(),
  }));

  // Summary row
  const totalRev = trips.reduce((s, r) => s + r.revenue, 0);
  const totalFuel = trips.reduce((s, r) => s + r.fuelExpense, 0);
  const totalTolls = trips.reduce((s, r) => s + r.tollExpense, 0);
  const totalDriver = trips.reduce((s, r) => s + r.driverPayout, 0);
  const totalMaint = trips.reduce((s, r) => s + r.maintenanceAllocated, 0);
  const totalProfit = trips.reduce((s, r) => s + r.netProfit, 0);

  formattedRows.push({
    'Sr No': 'TOTAL',
    'Trip ID': '',
    'Date': '',
    'Customer': 'TOTAL SUMMARY',
    'Route': '',
    'Vehicle Plate': '',
    'Driver': '',
    'Distance (KM)': trips.reduce((s, r) => s + r.distanceKm, 0),
    'Gross Revenue (₹)': totalRev,
    'Fuel Cost (₹)': totalFuel,
    'Tolls & Taxes (₹)': totalTolls,
    'Driver Payout (₹)': totalDriver,
    'Maintenance Allocation (₹)': totalMaint,
    'Other Expenses (₹)': trips.reduce((s, r) => s + r.otherExpense, 0),
    'Net Profit (₹)': totalProfit,
    'Profit Margin %': totalRev > 0 ? `${((totalProfit / totalRev) * 100).toFixed(1)}%` : '0%',
    'Payment Status': '',
  } as unknown as typeof formattedRows[0]);

  exportToExcel(formattedRows, `Profit_and_Loss_Report_${new Date().toISOString().slice(0, 10)}`, 'P&L Statement');
}

/**
 * Export CRM Inquiries & Dispositions Report
 */
export function exportInquiriesExcel(inquiries: Inquiry[]) {
  const rows = inquiries.map((inq, idx) => ({
    'Sr': idx + 1,
    'Inquiry No': inq.inquiryNumber,
    'Created At': inq.createdAt,
    'Customer Name': inq.customerName,
    'Phone': inq.phone,
    'Email': inq.email || 'N/A',
    'Pickup': inq.pickupLocation,
    'Drop': inq.dropLocation,
    'Trip Type': inq.tripType.replace('_', ' ').toUpperCase(),
    'Vehicle': inq.vehicleName,
    'Est Distance (KM)': inq.estimatedDistanceKm,
    'Total Quote (₹)': inq.totalQuote,
    'Status': inq.status.toUpperCase(),
    'Follow-up Date & Time': inq.followupDate ? `${inq.followupDate} ${inq.followupTime || ''}` : 'N/A',
    'Not Interested Reason': inq.notInterestedReason ? inq.notInterestedReason.replace('_', ' ').toUpperCase() : 'N/A',
    'Loss Analysis Notes': inq.notInterestedNotes || inq.notes || '',
  }));

  exportToExcel(rows, `Inquiries_CRM_Report_${new Date().toISOString().slice(0, 10)}`, 'Inquiries CRM');
}

/**
 * Export Fleet Status & Maintenance Audit
 */
export function exportFleetAuditExcel(vehicles: Vehicle[], maintenanceLogs: MaintenanceLog[]) {
  const wb = XLSX.utils.book_new();

  const fleetRows = vehicles.map((v) => {
    const kmSinceLast = v.currentOdometerKm - v.lastServiceKm;
    const kmRemaining = v.serviceIntervalKm - kmSinceLast;
    const isDue = kmRemaining <= 500;
    return {
      'Vehicle ID': v.id,
      'Name': v.name,
      'Plate Number': v.plateNumber,
      'Category': v.category.toUpperCase(),
      'Ownership': v.ownershipType.replace('_', ' ').toUpperCase(),
      'Fuel Type': v.fuelType.toUpperCase(),
      'Current Odo (KM)': v.currentOdometerKm,
      'Last Service (KM)': v.lastServiceKm,
      'Service Interval (KM)': v.serviceIntervalKm,
      'KM to Next Service': kmRemaining,
      'Maintenance Status': isDue ? '⚠️ SERVICE DUE / OVERDUE' : '✅ HEALTHY',
      'Insurance Expiry': v.insuranceExpiry,
      'Assigned Driver': v.driverName || 'Unassigned',
      'Operating Status': v.status.toUpperCase(),
    };
  });

  const maintRows = maintenanceLogs.map((m) => ({
    'Log ID': m.id,
    'Date': m.serviceDate,
    'Vehicle': m.vehicleName,
    'Plate': m.plateNumber,
    'Odometer at Service': m.odometerKmAtService,
    'Service Type': m.serviceType.replace('_', ' ').toUpperCase(),
    'Cost (₹)': m.cost,
    'Garage': m.garageName,
    'Notes': m.notes,
  }));

  const wsFleet = XLSX.utils.json_to_sheet(fleetRows);
  const wsMaint = XLSX.utils.json_to_sheet(maintRows);

  XLSX.utils.book_append_sheet(wb, wsFleet, 'Vehicles Status');
  XLSX.utils.book_append_sheet(wb, wsMaint, 'Service History');

  XLSX.writeFile(wb, `Fleet_and_Maintenance_Audit_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

/**
 * Generate Sample Excel / CSV file template for bulk uploads
 */
export function downloadSampleBulkUploadTemplate() {
  const sampleData = [
    {
      'Date (YYYY-MM-DD)': '2026-08-18',
      'Customer Name': 'Rajesh Sharma',
      'Pickup Location': 'Mumbai Airport T2',
      'Drop Location': 'Pune Hinjewadi',
      'Vehicle Plate': 'MH-12-AB-9821',
      'Driver Name': 'Ramesh Kumar',
      'Distance KM': 160,
      'Revenue (₹)': 4800,
      'Fuel Expense (₹)': 1400,
      'Toll Expense (₹)': 320,
      'Driver Payout (₹)': 1200,
      'Other Expense (₹)': 150,
      'Payment Status': 'PAID',
    },
    {
      'Date (YYYY-MM-DD)': '2026-08-19',
      'Customer Name': 'Anita Sen',
      'Pickup Location': 'Delhi Connaught Place',
      'Drop Location': 'Agra Taj Mahal',
      'Vehicle Plate': 'DL-01-CZ-4412',
      'Driver Name': 'Amit Singh',
      'Distance KM': 240,
      'Revenue (₹)': 6500,
      'Fuel Expense (₹)': 1900,
      'Toll Expense (₹)': 450,
      'Driver Payout (₹)': 1600,
      'Other Expense (₹)': 200,
      'Payment Status': 'PAID',
    },
  ];

  const ws = XLSX.utils.json_to_sheet(sampleData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Bulk Upload Template');
  XLSX.writeFile(wb, 'Bulk_Trip_Upload_Template.xlsx');
}

export interface BulkUploadParseResult {
  successRows: TripFinancialRecord[];
  errorRows: { rowNumber: number; reason: string; rawData: unknown }[];
  totalParsed: number;
}

/**
 * Parses uploaded Excel / CSV file and extracts TripFinancialRecords
 */
export async function parseBulkExcelFile(file: File): Promise<BulkUploadParseResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rawJson: Record<string, unknown>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        const successRows: TripFinancialRecord[] = [];
        const errorRows: { rowNumber: number; reason: string; rawData: unknown }[] = [];

        rawJson.forEach((row, idx) => {
          const rowNum = idx + 2; // +1 header, +1 1-based index
          const date = String(row['Date (YYYY-MM-DD)'] || row['Date'] || new Date().toISOString().slice(0, 10)).trim();
          const customerName = String(row['Customer Name'] || row['Customer'] || '').trim();
          const pickup = String(row['Pickup Location'] || row['Pickup'] || '').trim();
          const drop = String(row['Drop Location'] || row['Drop'] || '').trim();
          const plate = String(row['Vehicle Plate'] || row['Plate'] || 'DL-01-GENERIC').trim();
          const driver = String(row['Driver Name'] || row['Driver'] || 'Assigned Driver').trim();

          const dist = parseFloat(String(row['Distance KM'] || row['Distance'] || '100')) || 100;
          const rev = parseFloat(String(row['Revenue (₹)'] || row['Revenue'] || '0')) || 0;
          const fuel = parseFloat(String(row['Fuel Expense (₹)'] || row['Fuel'] || '0')) || 0;
          const tolls = parseFloat(String(row['Toll Expense (₹)'] || row['Tolls'] || '0')) || 0;
          const driverPay = parseFloat(String(row['Driver Payout (₹)'] || row['Driver Payout'] || '0')) || 0;
          const other = parseFloat(String(row['Other Expense (₹)'] || row['Other'] || '0')) || 0;

          if (!customerName || !pickup || !drop) {
            errorRows.push({
              rowNumber: rowNum,
              reason: 'Missing Customer Name or Route (Pickup/Drop)',
              rawData: row,
            });
            return;
          }

          const maintAlloc = Math.round(dist * 1.5);
          const netProf = rev - (fuel + tolls + driverPay + other + maintAlloc);

          const record: TripFinancialRecord = {
            id: 'imp_' + Math.random().toString(36).substring(2, 9),
            tripNumber: `TRP-${Math.floor(1000 + Math.random() * 9000)}`,
            date: date || new Date().toISOString().slice(0, 10),
            customerName,
            pickupLocation: pickup,
            dropLocation: drop,
            vehiclePlate: plate,
            driverName: driver,
            distanceKm: dist,
            revenue: rev,
            fuelExpense: fuel,
            tollExpense: tolls,
            driverPayout: driverPay,
            maintenanceAllocated: maintAlloc,
            otherExpense: other,
            netProfit: netProf,
            paymentStatus: String(row['Payment Status'] || 'paid').toLowerCase() === 'paid' ? 'paid' : 'pending',
          };

          successRows.push(record);
        });

        resolve({
          successRows,
          errorRows,
          totalParsed: rawJson.length,
        });
      } catch (err) {
        reject(new Error(`Failed to parse file: ${(err as Error).message}`));
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
}
