// Pan-India Live Geocoding, Search & Road Routing Engine

export interface IndiaPlace {
  name: string;
  desc: string;
  lat: number;
  lng: number;
  type: 'airport' | 'city' | 'hub' | 'tour' | 'landmark';
}

export const TOP_INDIAN_LOCATIONS: IndiaPlace[] = [
  // Maharashtra & Mumbai Region
  { name: 'Mumbai Airport Terminal 2 (CSMIA International)', desc: 'Sahar, Andheri East, Mumbai, Maharashtra', lat: 19.0896, lng: 72.8656, type: 'airport' },
  { name: 'Mumbai Airport Terminal 1 (Domestic)', desc: 'Santacruz East, Mumbai, Maharashtra', lat: 19.0911, lng: 72.8524, type: 'airport' },
  { name: 'Bandra Kurla Complex (BKC)', desc: 'Financial District, Mumbai, Maharashtra', lat: 19.0657, lng: 72.8687, type: 'hub' },
  { name: 'Chhatrapati Shivaji Maharaj Terminus (CSMT)', desc: 'Fort, South Mumbai, Maharashtra', lat: 18.9398, lng: 72.8354, type: 'hub' },
  { name: 'Pune Hinjewadi IT Park Phase 1-3', desc: 'Rajiv Gandhi Infotech Park, Pune, Maharashtra', lat: 18.5913, lng: 73.7389, type: 'hub' },
  { name: 'Pune Airport (PNQ Lohegaon)', desc: 'Lohegaon, Pune, Maharashtra', lat: 18.5822, lng: 73.9197, type: 'airport' },
  { name: 'Lonavala & Khandala Express Ghats', desc: 'Pune Highway Hill Station, Maharashtra', lat: 18.7557, lng: 73.4091, type: 'tour' },
  { name: 'Mahabaleshwar & Panchgani Hill Resort', desc: 'Satara District, Maharashtra', lat: 17.9237, lng: 73.6586, type: 'tour' },
  { name: 'Shirdi Sai Baba Temple', desc: 'Ahmednagar, Maharashtra', lat: 19.7668, lng: 74.4762, type: 'tour' },
  { name: 'Nashik Sula Vineyards & Trimbakeshwar', desc: 'Nashik, Maharashtra', lat: 19.9975, lng: 73.7898, type: 'tour' },
  { name: 'Alibaug Beach & Mandwa Jetty', desc: 'Raigad Coastline, Maharashtra', lat: 18.6414, lng: 72.8722, type: 'tour' },
  { name: 'Nagpur Zero Mile & Dr. Babasaheb Ambedkar Airport', desc: 'Nagpur, Maharashtra', lat: 21.0922, lng: 79.0472, type: 'city' },

  // Delhi NCR & North India
  { name: 'Delhi IGI Airport Terminal 3 (DEL)', desc: 'New Delhi, Delhi NCR', lat: 28.5562, lng: 77.1000, type: 'airport' },
  { name: 'Connaught Place & Central Secretariat', desc: 'New Delhi, Delhi NCR', lat: 28.6315, lng: 77.2167, type: 'hub' },
  { name: 'Gurugram Cyber Hub & DLF Phase 1-5', desc: 'Gurugram, Haryana / Delhi NCR', lat: 28.4952, lng: 77.0890, type: 'hub' },
  { name: 'Noida Sector 62 & Expressway Hub', desc: 'Gautam Buddha Nagar, Uttar Pradesh', lat: 28.6270, lng: 77.3725, type: 'hub' },
  { name: 'Agra Taj Mahal & Expressway Entry', desc: 'Agra, Uttar Pradesh', lat: 27.1751, lng: 78.0421, type: 'tour' },
  { name: 'Jaipur Pink City & Hawa Mahal', desc: 'Jaipur, Rajasthan', lat: 26.9239, lng: 75.8267, type: 'tour' },
  { name: 'Jaipur International Airport (JAI)', desc: 'Sanganer, Jaipur, Rajasthan', lat: 26.8242, lng: 75.8122, type: 'airport' },
  { name: 'Chandigarh Sector 17 & Airport', desc: 'Chandigarh Capital Region', lat: 30.7333, lng: 76.7794, type: 'city' },
  { name: 'Shimla Mall Road & Ridge', desc: 'Shimla, Himachal Pradesh', lat: 31.1048, lng: 77.1734, type: 'tour' },
  { name: 'Manali & Solang Valley', desc: 'Kullu District, Himachal Pradesh', lat: 32.2432, lng: 77.1892, type: 'tour' },
  { name: 'Dehradun & Mussoorie Mall Road', desc: 'Uttarakhand', lat: 30.3165, lng: 78.0322, type: 'tour' },
  { name: 'Rishikesh Laxman Jhula & Tapovan', desc: 'Uttarakhand Ganga River Hub', lat: 30.0869, lng: 78.2676, type: 'tour' },
  { name: 'Amritsar Golden Temple & Wagah Border', desc: 'Amritsar, Punjab', lat: 31.6200, lng: 74.8765, type: 'tour' },
  { name: 'Lucknow Hazratganj & Airport (LKO)', desc: 'Lucknow, Uttar Pradesh', lat: 26.8467, lng: 80.9462, type: 'city' },
  { name: 'Varanasi Kashi Vishwanath & Ghats', desc: 'Varanasi, Uttar Pradesh', lat: 25.3176, lng: 82.9739, type: 'tour' },

  // South India
  { name: 'Bengaluru Kempegowda International Airport (BLR)', desc: 'Devanahalli, Bengaluru, Karnataka', lat: 13.1986, lng: 77.7066, type: 'airport' },
  { name: 'Bengaluru Electronic City & Whitefield', desc: 'Tech Hubs, Bengaluru, Karnataka', lat: 12.8452, lng: 77.6602, type: 'hub' },
  { name: 'Mysuru Palace & Chamundi Hill', desc: 'Mysuru, Karnataka', lat: 12.3051, lng: 76.6551, type: 'tour' },
  { name: 'Hyderabad Rajiv Gandhi Airport (HYD)', desc: 'Shamshabad, Hyderabad, Telangana', lat: 17.2403, lng: 78.4294, type: 'airport' },
  { name: 'Hyderabad HITEC City & Gachibowli', desc: 'Financial District, Hyderabad, Telangana', lat: 17.4435, lng: 78.3772, type: 'hub' },
  { name: 'Chennai International Airport (MAA)', desc: 'Meenambakkam, Chennai, Tamil Nadu', lat: 12.9941, lng: 80.1709, type: 'airport' },
  { name: 'Chennai OMR IT Corridor & T. Nagar', desc: 'Chennai, Tamil Nadu', lat: 12.9698, lng: 80.2458, type: 'hub' },
  { name: 'Kochi Cochin International Airport (COK)', desc: 'Nedumbassery, Kochi, Kerala', lat: 10.1518, lng: 76.3930, type: 'airport' },
  { name: 'Munnar Tea Estates & Hill Station', desc: 'Idukki District, Kerala', lat: 10.0889, lng: 77.0595, type: 'tour' },
  { name: 'Goa Mopa / Dabolim Airport & Calangute Beach', desc: 'North & South Goa', lat: 15.2993, lng: 74.1240, type: 'tour' },
  { name: 'Ooty Nilgiri Hills & Coonoor', desc: 'Tamil Nadu Mountain Corridor', lat: 11.4102, lng: 76.6950, type: 'tour' },
  { name: 'Visakhapatnam Beach Road & Port Hub', desc: 'Andhra Pradesh Coastal City', lat: 17.6868, lng: 83.2185, type: 'city' },

  // West & Central India
  { name: 'Ahmedabad Sardar Vallabhbhai Patel Airport (AMD)', desc: 'Hansol, Ahmedabad, Gujarat', lat: 23.0772, lng: 72.6347, type: 'airport' },
  { name: 'Surat Diamond Bourse & Textile Hub', desc: 'Surat, Gujarat', lat: 21.1702, lng: 72.8311, type: 'city' },
  { name: 'Indore Rajwada & Airport (IDR)', desc: 'Indore, Madhya Pradesh', lat: 22.7196, lng: 75.8577, type: 'city' },
  { name: 'Bhopal Upper Lake & Habibganj Hub', desc: 'Bhopal, Madhya Pradesh', lat: 23.2599, lng: 77.4126, type: 'city' },

  // East & North East India
  { name: 'Kolkata Netaji Subhash Chandra Bose Airport (CCU)', desc: 'Dum Dum, Kolkata, West Bengal', lat: 22.6547, lng: 88.4467, type: 'airport' },
  { name: 'Kolkata Park Street & Howrah Station', desc: 'Kolkata, West Bengal', lat: 22.5552, lng: 88.3518, type: 'city' },
  { name: 'Darjeeling Himalayan Toy Train & Mall Road', desc: 'West Bengal Tea Garden Hills', lat: 27.0410, lng: 88.2663, type: 'tour' },
  { name: 'Bhubaneswar Temple City & Puri Jagannath', desc: 'Odisha Pilgrimage & Beach', lat: 20.2961, lng: 85.8245, type: 'tour' },
  { name: 'Guwahati Kamakhya Temple & Airport (GAU)', desc: 'Guwahati, Assam', lat: 26.1445, lng: 91.7362, type: 'city' },
  { name: 'Patna Junction & Airport (PAT)', desc: 'Patna, Bihar', lat: 25.5941, lng: 85.1376, type: 'city' },
];

// Live Pan-India Geocoding with OSM Nominatim API + Fallback
export async function searchIndiaLocations(query: string): Promise<IndiaPlace[]> {
  const trimmed = query.trim().toLowerCase();
  if (!trimmed || trimmed.length < 2) {
    return TOP_INDIAN_LOCATIONS.slice(0, 10);
  }

  // 1. Instant local fuzzy match
  const localMatches = TOP_INDIAN_LOCATIONS.filter(
    (loc) =>
      loc.name.toLowerCase().includes(trimmed) ||
      loc.desc.toLowerCase().includes(trimmed)
  );

  // 2. Fetch live Nominatim Geocoding across all of India
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const url = `https://nominatim.openstreetmap.org/search?format=json&countrycodes=in&q=${encodeURIComponent(
      query
    )}&addressdetails=1&limit=8`;

    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept-Language': 'en-IN,en;q=0.9',
      },
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      const liveResults: IndiaPlace[] = (data || []).map((item: any) => {
        const address = item.address || {};
        const title = item.name || address.city || address.town || address.village || address.suburb || item.display_name.split(',')[0];
        const state = address.state || address.county || 'India';
        const fullDesc = item.display_name;

        let type: IndiaPlace['type'] = 'landmark';
        if (item.type === 'aerodrome' || item.class === 'aeroway') type = 'airport';
        else if (item.type === 'city' || item.type === 'administrative') type = 'city';
        else if (item.type === 'attraction' || item.type === 'tourism') type = 'tour';

        return {
          name: title,
          desc: fullDesc,
          lat: parseFloat(item.lat),
          lng: parseFloat(item.lon),
          type,
        };
      });

      // Combine local matches and live results, deduplicating
      const combined = [...liveResults];
      localMatches.forEach((m) => {
        if (!combined.some((c) => Math.abs(c.lat - m.lat) < 0.05 && Math.abs(c.lng - m.lng) < 0.05)) {
          combined.push(m);
        }
      });

      return combined.slice(0, 10);
    }
  } catch (err) {
    console.warn('Live Nominatim geocoding offline/slow, using local matching:', err);
  }

  return localMatches.length > 0 ? localMatches : TOP_INDIAN_LOCATIONS.slice(0, 8);
}

// Live Road Routing using OSRM with real highway geometry
export async function getLiveRoadRoute(
  origin: [number, number],
  dest: [number, number]
): Promise<{
  distanceKm: number;
  durationHrs: number;
  durationText: string;
  coordinates: [number, number][];
} | null> {
  const [lat1, lng1] = origin;
  const [lat2, lng2] = dest;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const url = `https://router.project-osrm.org/route/v1/driving/${lng1},${lat1};${lng2},${lat2}?overview=full&geometries=geojson`;

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data.routes && data.routes.length > 0) {
        const route = data.routes[0];
        const distMeters = route.distance || 0;
        const durationSec = route.duration || 0;

        const distanceKm = Math.max(1, Math.round((distMeters / 1000) * 10) / 10);
        const durationHrs = Math.max(0.1, Math.round((durationSec / 3600) * 10) / 10);
        const hours = Math.floor(durationHrs);
        const mins = Math.round((durationHrs % 1) * 60);
        const durationText = hours > 0 ? `${hours} hr ${mins} min` : `${mins} min`;

        const coordinates: [number, number][] = (route.geometry?.coordinates || []).map(
          ([lng, lat]: [number, number]) => [lat, lng]
        );

        return {
          distanceKm,
          durationHrs,
          durationText,
          coordinates,
        };
      }
    }
  } catch (err) {
    console.warn('OSRM live routing fallback calculation:', err);
  }

  // Algorithmic highway distance estimation fallback
  const dLat = (lat2 - lat1) * 111;
  const dLng = (lng2 - lng1) * 111 * Math.cos((lat1 * Math.PI) / 180);
  const crowFlies = Math.sqrt(dLat * dLat + dLng * dLng);
  // Real Indian road curve factor: 1.32x crow-flies distance
  const distanceKm = Math.max(5, Math.round(crowFlies * 1.32));
  const durationHrs = Math.max(0.2, Math.round((distanceKm / 52) * 10) / 10);
  const hours = Math.floor(durationHrs);
  const mins = Math.round((durationHrs % 1) * 60);

  return {
    distanceKm,
    durationHrs,
    durationText: hours > 0 ? `${hours} hr ${mins} min` : `${mins} min`,
    coordinates: [
      [lat1, lng1],
      [(lat1 + lat2) / 2 + 0.02, (lng1 + lng2) / 2 + 0.02],
      [lat2, lng2],
    ],
  };
}
