/**
 * Bundles deployment files for 1-click Netlify drag-and-drop
 * and standalone Android APK configuration with Firestore background driver tracking
 */

export interface DeploymentConfig {
  projectId: string;
  apiKey: string;
  authDomain: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export function generateNetlifyToml(): string {
  return `[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[build]
  publish = "dist"
  command = "npm run build"

[build.environment]
  NODE_VERSION = "20"
`;
}

export function generateNetlifyRedirects(): string {
  return `/*    /index.html   200\n`;
}

export function generateFirestoreDriverScript(config?: Partial<DeploymentConfig>): string {
  const pId = config?.projectId || 'transvoyage-travel-fleet';
  const k = config?.apiKey || 'AIzaSyDemoKeyReplaceWithYours';
  return `/**
 * TransVoyage Autonomous Driver App & Real-Time Firestore Sync
 * Ready for Netlify Drop & Capacitor Android APK Build
 */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js';
import { getFirestore, doc, setDoc, onSnapshot, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: "${k}",
  authDomain: "${pId}.firebaseapp.com",
  projectId: "${pId}",
  storageBucket: "${pId}.appspot.com",
  messagingSenderId: "${config?.messagingSenderId || '1029384756'}",
  appId: "${config?.appId || '1:1029384756:web:abcd1234ef56'}"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Driver background location broadcaster
export function startDriverTracking(driverId, onLocationUpdate) {
  if (!navigator.geolocation) {
    console.warn("Geolocation not supported by device.");
    return null;
  }

  const watchId = navigator.geolocation.watchPosition(
    async (pos) => {
      const { latitude, longitude, speed, heading, accuracy } = pos.coords;
      const payload = {
        driverId,
        lat: latitude,
        lng: longitude,
        speedKmph: speed ? Math.round(speed * 3.6) : 0,
        heading: heading || 0,
        accuracyMeters: Math.round(accuracy),
        updatedAt: serverTimestamp(),
        batteryLevel: await getBatteryStatus(),
        status: 'available'
      };

      // Push to Firestore collection 'drivers_live'
      try {
        await setDoc(doc(db, "drivers_live", driverId), payload, { merge: true });
        if (onLocationUpdate) onLocationUpdate(payload);
      } catch (err) {
        console.error("Firestore sync error:", err);
      }
    },
    (err) => console.error("GPS Error:", err),
    { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
  );

  return watchId;
}

async function getBatteryStatus() {
  try {
    if ('getBattery' in navigator) {
      const bat = await (navigator as any).getBattery();
      return Math.round(bat.level * 100);
    }
  } catch {}
  return 95;
}
`;
}

export const generateFirestoreStandaloneScript = generateFirestoreDriverScript;

export function generateCapacitorConfig(): string {
  return `{
  "appId": "com.transvoyage.driverapp",
  "appName": "TransVoyage Driver",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "plugins": {
    "Geolocation": {
      "requestPermissions": true
    },
    "BackgroundRunner": {
      "label": "com.transvoyage.driver.background",
      "src": "background.js",
      "event": "locationPing",
      "repeat": true,
      "interval": 15,
      "autoStart": true
    }
  }
}`;
}

export const generateAndroidCapacitorConfig = generateCapacitorConfig;

export function generateAndroidManifestSnippet(): string {
  return `<!-- Place in android/app/src/main/AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.transvoyage.driverapp">
    
    <!-- Required Permissions for Real-Time Driver Fleet Tracking -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="TransVoyage Driver"
        android:usesCleartextTraffic="true"
        android:theme="@style/AppTheme">
        
        <service
            android:name="com.transvoyage.driver.LocationService"
            android:foregroundServiceType="location"
            android:enabled="true"
            android:exported="false" />
    </application>
</manifest>`;
}

export const generateAndroidManifestXml = generateAndroidManifestSnippet;

export function downloadTextFile(filename: string, text: string) {
  const element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}
