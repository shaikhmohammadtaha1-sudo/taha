import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Car,
  ShieldCheck,
  Smartphone,
  PhoneCall,
  Flame,
  Wrench,
  MessageSquare,
  Lock,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    cms,
    inquiries,
    vehicles,
    isGpsTrackingActive,
    isAdminLoggedIn,
  } = useApp();

  // Pending Inquiries count
  const newInquiriesCount = inquiries.filter((inq) => inq.status === 'new' || inq.status === 'followup').length;

  // Maintenance Due Count
  const maintenanceAlertCount = vehicles.filter((v) => {
    const kmSinceLast = v.currentOdometerKm - v.lastServiceKm;
    return v.serviceIntervalKm - kmSinceLast <= 500;
  }).length;

  return (
    <header id="main-navigation-header" className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Notification Announcement Bar */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs font-medium flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2 max-w-2xl truncate">
          <span className="flex items-center gap-1 bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded text-[11px] font-semibold border border-indigo-500/30">
            <Flame className="w-3 h-3 text-amber-400" /> LIVE FUEL INDEX: ₹{cms.fuelIndexPrice}/L
          </span>
          <span className="truncate">{cms.promoNotice}</span>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          <a
            href={`tel:${cms.phone}`}
            className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
          >
            <PhoneCall className="w-3 h-3 text-emerald-400" />
            <span className="font-semibold">{cms.phone}</span>
          </a>
          <a
            href={`https://wa.me/${cms.whatsapp.replace(/[^0-9]/g, '')}`}
            target="_blank"
            rel="noreferrer"
            className="hidden sm:flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
          >
            <MessageSquare className="w-3 h-3" />
            <span>WhatsApp Dispatch</span>
          </a>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo & Name */}
        <div
          onClick={() => setCurrentView('customer')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-800 flex items-center justify-center text-white shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform">
            <Car className="w-5 h-5" />
          </div>
          <div>
            <span className="text-lg font-extrabold tracking-tight text-slate-900 block leading-tight font-['Outfit',sans-serif]">
              {cms.brandName}
            </span>
            <span className="text-[11px] font-medium text-slate-500 block truncate max-w-[240px] sm:max-w-md">
              {cms.brandTagline}
            </span>
          </div>
        </div>

        {/* View Switchers (Customer, Admin Suite, Driver App) */}
        <nav className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80">
          {/* Customer Portal */}
          <button
            id="nav-btn-customer-view"
            onClick={() => setCurrentView('customer')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              currentView === 'customer'
                ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
            }`}
          >
            <Car className="w-4 h-4 text-indigo-600" />
            <span>Customer Booking</span>
          </button>

          {/* Admin Management Suite */}
          <button
            id="nav-btn-admin-view"
            onClick={() => setCurrentView('admin')}
            className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              currentView === 'admin'
                ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            <span>Admin Suite</span>
            {/* Badges */}
            <div className="flex items-center gap-1">
              {newInquiriesCount > 0 && (
                <span className="flex items-center justify-center h-4.5 min-w-4.5 px-1 bg-rose-500 text-white text-[10px] font-bold rounded-full shadow-xs">
                  {newInquiriesCount}
                </span>
              )}
              {maintenanceAlertCount > 0 && (
                <span
                  title={`${maintenanceAlertCount} vehicles require service`}
                  className="flex items-center justify-center w-4 h-4 bg-amber-500 text-white text-[10px] font-bold rounded-full"
                >
                  <Wrench className="w-2.5 h-2.5" />
                </span>
              )}
            </div>
          </button>

          {/* Driver Mobile App */}
          <button
            id="nav-btn-driver-view"
            onClick={() => setCurrentView('driver')}
            className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              currentView === 'driver'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Driver App</span>
            {isGpsTrackingActive && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-white animate-pulse" />
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};
