import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Driver } from '../../types';
import { getLiveRoadRoute } from '../../utils/indiaGeoService';
import { Navigation, Clock, Fuel, ShieldCheck } from 'lucide-react';

interface LeafletMapProps {
  drivers?: Driver[];
  selectedDriverId?: string;
  onSelectDriver?: (driverId: string) => void;
  pickupCoords?: [number, number];
  dropCoords?: [number, number];
  pickupLocation?: string;
  dropLocation?: string;
  onRouteCalculated?: (route: { distanceKm: number; durationHrs: number }) => void;
  center?: [number, number];
  zoom?: number;
  height?: string;
  className?: string;
  showAllFleetBounds?: boolean;
}

export const LeafletMap: React.FC<LeafletMapProps> = ({
  drivers = [],
  selectedDriverId,
  onSelectDriver,
  pickupCoords,
  dropCoords,
  pickupLocation,
  dropLocation,
  onRouteCalculated,
  center = [19.076, 72.8777],
  zoom = 11,
  height = '420px',
  className = '',
  showAllFleetBounds = false,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);
  const [routeStats, setRouteStats] = useState<{ distanceKm: number; durationText: string } | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: center as [number, number],
        zoom,
        zoomControl: true,
        attributionControl: false,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update Markers and Routes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;
    if (!map || !markersLayer) return;

    markersLayer.clearLayers();

    if (routeLayerRef.current) {
      routeLayerRef.current.remove();
      routeLayerRef.current = null;
    }

    const bounds = L.latLngBounds([]);

    // 1. Render Driver Markers
    drivers.forEach((driver) => {
      const isSelected = driver.id === selectedDriverId;
      const statusColor =
        driver.status === 'available'
          ? '#10b981'
          : driver.status === 'on_trip'
          ? '#3b82f6'
          : driver.status === 'break'
          ? '#f59e0b'
          : '#94a3b8';

      const customIcon = L.divIcon({
        className: 'custom-driver-pin',
        html: `
          <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 42px; height: 42px;">
            <div style="
              position: absolute;
              width: ${isSelected ? '46px' : '36px'};
              height: ${isSelected ? '46px' : '36px'};
              background: ${statusColor};
              border: 3px solid #ffffff;
              border-radius: 50%;
              box-shadow: 0 4px 12px rgba(0,0,0,0.3);
              display: flex;
              align-items: center;
              justify-content: center;
              transition: all 0.3s ease;
            ">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/>
                <circle cx="7" cy="17" r="2"/>
                <path d="M9 17h6"/>
                <circle cx="17" cy="17" r="2"/>
              </svg>
            </div>
          </div>
        `,
        iconSize: [42, 42],
        iconAnchor: [21, 21],
      });

      const marker = L.marker([driver.currentLat, driver.currentLng], { icon: customIcon });

      const popupContent = `
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; min-width: 200px; padding: 4px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
            <strong style="font-size: 14px; color: #0f172a;">${driver.name}</strong>
            <span style="font-size: 10px; font-weight: bold; text-transform: uppercase; padding: 2px 6px; border-radius: 4px; background: ${statusColor}20; color: ${statusColor}; border: 1px solid ${statusColor}40;">
              ${driver.status.replace('_', ' ')}
            </span>
          </div>
          <div style="font-size: 12px; color: #475569; margin-bottom: 3px;">
            🚗 <b>${driver.assignedVehicleName || 'Vehicle'}</b> (${driver.assignedVehiclePlate || 'N/A'})
          </div>
          <div style="font-size: 12px; color: #475569; margin-bottom: 3px;">
            📍 ${driver.currentLocationName || 'En route'}
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 11px; color: #64748b; margin-top: 6px; border-top: 1px solid #e2e8f0; padding-top: 4px;">
            <span>🔋 ${driver.batteryPct}% Battery</span>
            <span>⚡ ${driver.speedKmph} km/h</span>
            <span>⭐ ${driver.rating}</span>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);

      marker.on('click', () => {
        if (onSelectDriver) {
          onSelectDriver(driver.id);
        }
      });

      marker.addTo(markersLayer);
      bounds.extend([driver.currentLat, driver.currentLng]);
    });

    // 2. Render Pickup & Drop Route
    if (pickupCoords && dropCoords) {
      // Pickup marker (Green)
      const pickupIcon = L.divIcon({
        className: 'pickup-pin',
        html: `
          <div style="background: #10b981; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; border: 3px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.35);">
            P
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      L.marker(pickupCoords, { icon: pickupIcon })
        .bindPopup(`<b>Pickup:</b> ${pickupLocation || 'Start Location'}`)
        .addTo(markersLayer);

      // Drop marker (Red)
      const dropIcon = L.divIcon({
        className: 'drop-pin',
        html: `
          <div style="background: #ef4444; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; border: 3px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.35);">
            D
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      L.marker(dropCoords, { icon: dropIcon })
        .bindPopup(`<b>Drop:</b> ${dropLocation || 'Destination'}`)
        .addTo(markersLayer);

      bounds.extend(pickupCoords);
      bounds.extend(dropCoords);

      // Fetch live road route geometry
      getLiveRoadRoute(pickupCoords, dropCoords).then((route) => {
        if (!route) return;

        setRouteStats({
          distanceKm: route.distanceKm,
          durationText: route.durationText,
        });

        if (onRouteCalculated) {
          onRouteCalculated({
            distanceKm: route.distanceKm,
            durationHrs: route.durationHrs,
          });
        }

        if (mapInstanceRef.current) {
          if (routeLayerRef.current) {
            routeLayerRef.current.remove();
          }

          routeLayerRef.current = L.polyline(route.coordinates, {
            color: '#4f46e5',
            weight: 5,
            opacity: 0.85,
            lineJoin: 'round',
          }).addTo(mapInstanceRef.current);

          const routeBounds = L.latLngBounds(route.coordinates);
          mapInstanceRef.current.fitBounds(routeBounds, { padding: [50, 50], maxZoom: 14 });
        }
      });
    }

    if (showAllFleetBounds && bounds.isValid() && drivers.length > 0 && (!pickupCoords || !dropCoords)) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }
  }, [drivers, selectedDriverId, pickupCoords, dropCoords, pickupLocation, dropLocation, showAllFleetBounds, onSelectDriver, onRouteCalculated]);

  return (
    <div
      id="fleet-live-map-container"
      className={`relative w-full rounded-2xl overflow-hidden shadow-inner border border-slate-200 ${className}`}
      style={{ height }}
    >
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Route Distance Badge */}
      {routeStats && (
        <div className="absolute top-3 left-3 z-[400] bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-xl shadow-lg border border-indigo-100 text-slate-800 flex items-center gap-3 text-xs font-semibold">
          <div className="flex items-center gap-1 text-indigo-700">
            <Navigation className="w-3.5 h-3.5 text-indigo-600" />
            <span>{routeStats.distanceKm} KM Live Route</span>
          </div>
          <div className="h-3 w-px bg-slate-200" />
          <div className="flex items-center gap-1 text-slate-700">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>{routeStats.durationText}</span>
          </div>
        </div>
      )}

      {/* Map Legend Overlay */}
      <div className="absolute top-3 right-3 z-[400] bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-md border border-slate-200 text-[11px] flex items-center gap-2.5">
        <span className="flex items-center gap-1 font-medium text-slate-700">
          <span className="w-2 h-2 rounded-full bg-emerald-500" /> Available
        </span>
        <span className="flex items-center gap-1 font-medium text-slate-700">
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" /> On Trip
        </span>
        <span className="flex items-center gap-1 font-medium text-slate-700">
          <span className="w-2 h-2 rounded-full bg-amber-500" /> Break
        </span>
      </div>
    </div>
  );
};
