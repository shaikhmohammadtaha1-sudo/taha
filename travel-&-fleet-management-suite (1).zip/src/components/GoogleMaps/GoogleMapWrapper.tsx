import React, { useState, useEffect } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { Key, MapPin, ExternalLink, Sparkles } from 'lucide-react';

export const getGoogleMapsApiKey = (): string => {
  const key =
    process.env.GOOGLE_MAPS_PLATFORM_KEY ||
    (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
    (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
    '';

  return typeof key === 'string' ? key.trim() : '';
};

// A valid Google Maps key is non-empty, not a placeholder, and starts with AIza
export const isValidGoogleMapsKey = (key: string): boolean => {
  return Boolean(key) && key !== 'YOUR_API_KEY' && key !== 'MY_GOOGLE_MAPS_KEY' && key.startsWith('AIza') && key.length >= 35;
};

export const hasValidGoogleMapsKey = isValidGoogleMapsKey(getGoogleMapsApiKey());

interface GoogleMapWrapperProps {
  children: React.ReactNode;
  fallbackHeight?: string;
  fallbackTitle?: string;
  fallbackSubtitle?: string;
  onAuthFailure?: () => void;
}

export const GoogleMapWrapper: React.FC<GoogleMapWrapperProps> = ({
  children,
  fallbackHeight = '420px',
  fallbackTitle = 'Google Maps Platform Ready',
  fallbackSubtitle = 'To enable live Google Maps routing, polyline traffic, and Places Autocomplete, provide a Google Maps API Key.',
  onAuthFailure,
}) => {
  const [apiKey, setApiKey] = useState<string>(getGoogleMapsApiKey());
  const [authFailed, setAuthFailed] = useState<boolean>(false);
  const [customKeyInput, setCustomKeyInput] = useState<string>('');
  const [isSettingKey, setIsSettingKey] = useState<boolean>(false);

  // Capture Google Maps auth errors (e.g. InvalidKeyMapError) gracefully
  useEffect(() => {
    const originalAuthFailure = (window as any).gm_authFailure;
    (window as any).gm_authFailure = () => {
      console.warn('Google Maps API auth failure (gm_authFailure). Gracefully pivoting to standard map.');
      setAuthFailed(true);
      if (onAuthFailure) onAuthFailure();
      if (typeof originalAuthFailure === 'function') {
        try {
          originalAuthFailure();
        } catch {}
      }
    };

    return () => {
      (window as any).gm_authFailure = originalAuthFailure;
    };
  }, [onAuthFailure]);

  const hasKey = isValidGoogleMapsKey(apiKey);

  const handleApplyCustomKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customKeyInput.trim()) return;
    (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY = customKeyInput.trim();
    setApiKey(customKeyInput.trim());
    setAuthFailed(false);
    setIsSettingKey(false);
  };

  const fallbackUI = (
    <div
      className="w-full relative rounded-2xl overflow-hidden border border-slate-700 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white flex flex-col items-center justify-center p-6 text-center shadow-lg"
      style={{ minHeight: fallbackHeight }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px] opacity-15 pointer-events-none" />

      <div className="relative z-10 max-w-md space-y-3.5">
        <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-400/30 flex items-center justify-center mx-auto text-indigo-400 shadow-inner">
          <MapPin className="w-6 h-6 animate-pulse" />
        </div>

        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-semibold uppercase tracking-wider mb-1.5 border border-indigo-400/20">
            <Sparkles className="w-3 h-3" /> Live Google Maps Platform
          </div>
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">{fallbackTitle}</h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            {authFailed
              ? 'The current API key is not activated for Maps JavaScript API or is invalid. You can use the standard built-in interactive map or enter an active key.'
              : fallbackSubtitle}
          </p>
        </div>

        {isSettingKey ? (
          <form onSubmit={handleApplyCustomKey} className="space-y-2 pt-1">
            <input
              type="text"
              value={customKeyInput}
              onChange={(e) => setCustomKeyInput(e.target.value)}
              placeholder="Paste Google Maps API Key (AIza...)"
              className="w-full px-3 py-2 bg-slate-900/90 rounded-xl border border-indigo-400/40 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setIsSettingKey(false)}
                className="px-3 py-1.5 rounded-lg text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 cursor-pointer"
              >
                Apply Key
              </button>
            </div>
          </form>
        ) : (
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsSettingKey(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-md cursor-pointer"
            >
              <Key className="w-3.5 h-3.5 text-amber-300" /> Enter Maps Key
            </button>
            <a
              href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700 transition-all"
            >
              Cloud Console <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        )}
      </div>
    </div>
  );

  if (!hasKey || authFailed) {
    return fallbackUI;
  }

  return (
    <APIProvider apiKey={apiKey} version="weekly">
      {children}
    </APIProvider>
  );
};
