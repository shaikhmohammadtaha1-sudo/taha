import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Search, Loader2, Navigation, Building2, Plane, Globe, Check } from 'lucide-react';
import { searchIndiaLocations, IndiaPlace, TOP_INDIAN_LOCATIONS } from '../../utils/indiaGeoService';

interface PlaceAutocompleteInputProps {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  onPlaceSelect?: (place: { address: string; lat: number; lng: number }) => void;
  placeholder?: string;
  label?: string;
  className?: string;
}

export const PlaceAutocompleteInput: React.FC<PlaceAutocompleteInputProps> = ({
  id,
  value,
  onChange,
  onPlaceSelect,
  placeholder = 'Type any city, airport, landmark in India...',
  label,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [suggestions, setSuggestions] = useState<IndiaPlace[]>(TOP_INDIAN_LOCATIONS.slice(0, 8));
  const containerRef = useRef<HTMLDivElement>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value;
    onChange(text);

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    if (!text.trim()) {
      setSuggestions(TOP_INDIAN_LOCATIONS.slice(0, 8));
      setIsLoading(false);
      setIsOpen(false);
      return;
    }

    setIsLoading(true);
    setIsOpen(true);

    debounceTimerRef.current = setTimeout(async () => {
      try {
        const results = await searchIndiaLocations(text);
        setSuggestions(results);
      } catch {
        setSuggestions(TOP_INDIAN_LOCATIONS.slice(0, 6));
      } finally {
        setIsLoading(false);
      }
    }, 250);
  };

  const handleSelect = (place: IndiaPlace) => {
    onChange(place.name);
    setIsOpen(false);
    if (onPlaceSelect) {
      onPlaceSelect({
        address: `${place.name} (${place.desc})`,
        lat: place.lat,
        lng: place.lng,
      });
    }
  };

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      {label && <label className="block text-xs font-semibold text-slate-700 mb-1">{label}</label>}
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-600" />
        <input
          id={id}
          type="text"
          value={value}
          onChange={handleInputChange}
          onFocus={() => {
            if (suggestions.length > 0) setIsOpen(true);
          }}
          placeholder={placeholder}
          className="w-full pl-9 pr-9 py-2.5 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xs sm:text-sm shadow-xs transition-all text-slate-900 font-medium"
        />
        {isLoading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-600 animate-spin" />
        )}
      </div>

      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 max-h-72 overflow-y-auto divide-y divide-slate-100 p-1.5 animate-in fade-in-50 zoom-in-95 duration-150">
          <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Globe className="w-3 h-3 text-indigo-500" /> Pan-India Live Search
            </span>
            {isLoading ? <span>Searching India...</span> : <span>{suggestions.length} Results</span>}
          </div>

          {suggestions.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500">
              No matching Indian location found. Try city, state, or landmark name.
            </div>
          ) : (
            suggestions.map((item, idx) => (
              <button
                key={`${item.name}-${idx}`}
                type="button"
                onClick={() => handleSelect(item)}
                className="w-full text-left px-3 py-2.5 hover:bg-indigo-50/80 rounded-xl transition-colors flex items-start gap-2.5 text-xs cursor-pointer group"
              >
                <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors shrink-0 mt-0.5">
                  {item.type === 'airport' ? (
                    <Plane className="w-3.5 h-3.5" />
                  ) : item.type === 'hub' ? (
                    <Building2 className="w-3.5 h-3.5" />
                  ) : (
                    <Navigation className="w-3.5 h-3.5" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 block truncate group-hover:text-indigo-900">
                      {item.name}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded ml-2 shrink-0">
                      {item.type}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 block truncate mt-0.5">{item.desc}</span>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};
