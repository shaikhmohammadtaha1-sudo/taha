import React, { useEffect, useRef, useState } from 'react';
import { Map, AdvancedMarker, Pin, useMap, useMapsLibrary, InfoWindow } from '@vis.gl/react-google-maps';
import { Driver } from '../../types';
import { Navigation, Clock, Fuel, ShieldCheck, Car } from 'lucide-react';

interface RouteInfo {
  distanceKm: number;
  durationHrs: number;
  durationText: string;
}

interface LiveGoogleRouteMapProps {
  pickupLocation: string;
  dropLocation: string;
  pickupCoords?: [number, number];
  dropCoords?: [number, number];
  drivers?: Driver[];
  onRouteCalculated?: (route: { distanceKm: number; durationHrs: number }) => void;
  onMapClick?: (lat: number, lng: number) => void;
  height?: string;
}

const RouteDirectionsRenderer: React.FC<{
  pickupCoords?: [number, number];
  dropCoords?: [number, number];
  pickupLocation: string;
  dropLocation: string;
  onRouteCalculated?: (route: { distanceKm: number; durationHrs: number }) => void;
  setRouteInfo: React.Dispatch<React.SetStateAction<RouteInfo | null>>;
}> = ({ pickupCoords, dropCoords, pickupLocation, dropLocation, onRouteCalculated, setRouteInfo }) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);

  useEffect(() => {
    if (!map) return;

    if (!routesLib) {
      if (pickupCoords && dropCoords) {
        const dLat = (dropCoords[0] - pickupCoords[0]) * 111;
        const dLng = (dropCoords[1] - pickupCoords[1]) * 111 * Math.cos((pickupCoords[0] * Math.PI) / 180);
        const approxKm = Math.max(1, Math.round(Math.sqrt(dLat * dLat + dLng * dLng) * 1.35));
        const approxHrs = Math.max(0.2, Math.round((approxKm / 45) * 10) / 10);
        setRouteInfo({
          distanceKm: approxKm,
          durationHrs: approxHrs,
          durationText: `${Math.floor(approxHrs)} hr ${Math.round((approxHrs % 1) * 60)} min`,
        });
        if (onRouteCalculated) onRouteCalculated({ distanceKm: approxKm, durationHrs: approxHrs });
      }
      return;
    }

    if (!directionsRendererRef.current) {
      directionsRendererRef.current = new routesLib.DirectionsRenderer({
        map,
        suppressMarkers: true,
        polylineOptions: {
          strokeColor: '#4f46e5',
          strokeWeight: 5,
          strokeOpacity: 0.85,
        },
      });
    }

    const origin: google.maps.LatLngLiteral | string | null = pickupCoords
      ? { lat: pickupCoords[0], lng: pickupCoords[1] }
      : pickupLocation || null;

    const destination: google.maps.LatLngLiteral | string | null = dropCoords
      ? { lat: dropCoords[0], lng: dropCoords[1] }
      : dropLocation || null;

    if (!origin || !destination) return;

    const directionsService = new routesLib.DirectionsService();

    directionsService.route(
      {
        origin,
        destination,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK && result) {
          directionsRendererRef.current?.setDirections(result);
          const leg = result.routes[0]?.legs[0];
          if (leg) {
            const distanceKm = Math.max(1, Math.round((leg.distance?.value || 0) / 100) / 10);
            const durationSec = leg.duration?.value || 0;
            const durationHrs = Math.max(0.1, Math.round((durationSec / 3600) * 10) / 10);
            const durationText = leg.duration?.text || `${Math.round(durationSec / 60)} mins`;

            setRouteInfo({
              distanceKm,
              durationHrs,
              durationText,
            });

            if (onRouteCalculated) {
              onRouteCalculated({ distanceKm, durationHrs });
            }
          }
        } else {
          console.warn('DirectionsService note:', status);
        }
      }
    );

    return () => {
      if (directionsRendererRef.current) {
        directionsRendererRef.current.setMap(null);
        directionsRendererRef.current = null;
      }
    };
  }, [routesLib, map, pickupCoords, dropCoords, pickupLocation, dropLocation, onRouteCalculated, setRouteInfo]);

  return null;
};

export const LiveGoogleRouteMap: React.FC<LiveGoogleRouteMapProps> = ({
  pickupLocation,
  dropLocation,
  pickupCoords,
  dropCoords,
  drivers = [],
  onRouteCalculated,
  onMapClick,
  height = '460px',
}) => {
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);

  const defaultCenter = pickupCoords
    ? { lat: pickupCoords[0], lng: pickupCoords[1] }
    : { lat: 19.0896, lng: 72.8656 };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden shadow-md border border-slate-200 bg-slate-900" style={{ height }}>
      <Map
        defaultCenter={defaultCenter}
        defaultZoom={12}
        mapId="TRANSVOYAGE_CUSTOMER_MAP"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
        onClick={(e) => {
          if (e.detail.latLng && onMapClick) {
            onMapClick(e.detail.latLng.lat, e.detail.latLng.lng);
          }
        }}
      >
        {/* Pickup Marker */}
        {pickupCoords && (
          <AdvancedMarker position={{ lat: pickupCoords[0], lng: pickupCoords[1] }} title="Pickup Location">
            <Pin background="#10b981" glyphColor="#ffffff" borderColor="#047857" scale={1.2} />
          </AdvancedMarker>
        )}

        {/* Drop Marker */}
        {dropCoords && (
          <AdvancedMarker position={{ lat: dropCoords[0], lng: dropCoords[1] }} title="Destination Drop Location">
            <Pin background="#ef4444" glyphColor="#ffffff" borderColor="#b91c1c" scale={1.2} />
          </AdvancedMarker>
        )}

        {/* Fleet Drivers near pickup */}
        {drivers.map((driver) => (
          <AdvancedMarker
            key={driver.id}
            position={{ lat: driver.currentLat, lng: driver.currentLng }}
            title={`${driver.name} (${driver.assignedVehicleName || 'Cab'})`}
            onClick={() => setSelectedDriver(driver)}
          >
            <div className="relative group cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-indigo-600 border-2 border-white shadow-md flex items-center justify-center text-white transform hover:scale-110 transition-transform">
                <Car className="w-4 h-4" />
              </div>
              <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/90 text-white text-[9px] px-1 rounded whitespace-nowrap shadow">
                {driver.name.split(' ')[0]}
              </span>
            </div>
          </AdvancedMarker>
        ))}

        {/* InfoWindow for selected driver */}
        {selectedDriver && (
          <InfoWindow
            position={{ lat: selectedDriver.currentLat, lng: selectedDriver.currentLng }}
            onCloseClick={() => setSelectedDriver(null)}
          >
            <div className="p-1 text-slate-800 text-xs max-w-xs space-y-1">
              <div className="font-bold text-sm text-indigo-700 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                {selectedDriver.name}
              </div>
              <p className="text-slate-600">{selectedDriver.assignedVehicleName} • {selectedDriver.assignedVehiclePlate}</p>
              <div className="flex items-center gap-2 pt-1 font-semibold text-emerald-700">
                <span>⭐ {selectedDriver.rating}</span>
                <span>• {selectedDriver.status.toUpperCase()}</span>
                <span>• Battery {selectedDriver.batteryPct}%</span>
              </div>
            </div>
          </InfoWindow>
        )}

        {/* Google Routes Computer */}
        <RouteDirectionsRenderer
          pickupCoords={pickupCoords}
          dropCoords={dropCoords}
          pickupLocation={pickupLocation}
          dropLocation={dropLocation}
          onRouteCalculated={onRouteCalculated}
          setRouteInfo={setRouteInfo}
        />
      </Map>

      {/* Floating Route Metrics Badge */}
      {routeInfo && (
        <div className="absolute top-3 left-3 z-10 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-xl border border-indigo-100 shadow-lg text-slate-800 flex items-center gap-4 text-xs font-semibold">
          <div className="flex items-center gap-1.5 text-indigo-700">
            <Navigation className="w-4 h-4 text-indigo-600" />
            <span>{routeInfo.distanceKm} KM</span>
          </div>
          <div className="h-4 w-px bg-slate-200" />
          <div className="flex items-center gap-1.5 text-slate-700">
            <Clock className="w-4 h-4 text-amber-500" />
            <span>{routeInfo.durationText}</span>
          </div>
          <div className="h-4 w-px bg-slate-200" />
          <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
            <Fuel className="w-4 h-4 text-emerald-600" />
            <span>Live Fuel Computed</span>
          </div>
        </div>
      )}
    </div>
  );
};
