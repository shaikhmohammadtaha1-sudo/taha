import React, { useState } from 'react';
import { Map, AdvancedMarker, Pin, InfoWindow } from '@vis.gl/react-google-maps';
import { Driver } from '../../types';
import { ShieldCheck, Phone, Zap, Gauge, MapPin, CheckCircle, Navigation } from 'lucide-react';

interface LiveGoogleFleetMapProps {
  drivers: Driver[];
  selectedDriverId?: string;
  onSelectDriver?: (driverId: string) => void;
  height?: string;
}

export const LiveGoogleFleetMap: React.FC<LiveGoogleFleetMapProps> = ({
  drivers,
  selectedDriverId,
  onSelectDriver,
  height = '540px',
}) => {
  const [activeDriverPopup, setActiveDriverPopup] = useState<Driver | null>(null);

  const selectedDriver = drivers.find((d) => d.id === selectedDriverId) || drivers[0];

  const mapCenter = selectedDriver
    ? { lat: selectedDriver.currentLat, lng: selectedDriver.currentLng }
    : { lat: 19.076, lng: 72.8777 };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-slate-950" style={{ height }}>
      <Map
        defaultCenter={mapCenter}
        defaultZoom={11}
        mapId="TRANSVOYAGE_ADMIN_FLEET_MAP"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
      >
        {drivers.map((driver) => {
          const isSelected = driver.id === selectedDriverId;
          const pinColor =
            driver.status === 'available'
              ? '#10b981'
              : driver.status === 'on_trip'
              ? '#3b82f6'
              : driver.status === 'break'
              ? '#f59e0b'
              : '#64748b';

          return (
            <AdvancedMarker
              key={driver.id}
              position={{ lat: driver.currentLat, lng: driver.currentLng }}
              title={`${driver.name} - ${driver.status.toUpperCase()}`}
              onClick={() => {
                setActiveDriverPopup(driver);
                if (onSelectDriver) onSelectDriver(driver.id);
              }}
            >
              <div className="relative cursor-pointer group flex flex-col items-center">
                {/* Speed & Battery Top Pill */}
                <div
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold shadow-md border flex items-center gap-1 mb-1 transition-transform ${
                    isSelected ? 'scale-110 ring-2 ring-indigo-400 bg-indigo-900 text-white' : 'bg-slate-900/90 text-white border-slate-700'
                  }`}
                >
                  <Gauge className="w-3 h-3 text-cyan-400" />
                  <span>{driver.speedKmph} km/h</span>
                  <span className="text-slate-400">•</span>
                  <span className={driver.batteryPct < 20 ? 'text-rose-400' : 'text-emerald-400'}>{driver.batteryPct}%</span>
                </div>

                <Pin
                  background={pinColor}
                  glyphColor="#ffffff"
                  borderColor={isSelected ? '#4338ca' : '#1e293b'}
                  scale={isSelected ? 1.3 : 1.05}
                />

                {/* Driver Name label */}
                <div className="mt-1 px-1.5 py-0.5 rounded bg-slate-900/90 text-white text-[10px] font-medium tracking-tight shadow">
                  {driver.name.split(' ')[0]}
                </div>
              </div>
            </AdvancedMarker>
          );
        })}

        {/* Selected Driver InfoWindow */}
        {activeDriverPopup && (
          <InfoWindow
            position={{ lat: activeDriverPopup.currentLat, lng: activeDriverPopup.currentLng }}
            onCloseClick={() => setActiveDriverPopup(null)}
          >
            <div className="p-2 text-slate-800 text-xs max-w-xs space-y-2">
              <div className="flex items-center justify-between gap-2 border-b pb-1.5">
                <div className="font-bold text-sm text-indigo-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  {activeDriverPopup.name}
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    activeDriverPopup.status === 'available'
                      ? 'bg-emerald-100 text-emerald-800'
                      : activeDriverPopup.status === 'on_trip'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {activeDriverPopup.status.replace('_', ' ')}
                </span>
              </div>

              <div className="space-y-1 text-slate-600 text-[11px]">
                <p className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{activeDriverPopup.currentLocationName}</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="font-semibold text-slate-700">{activeDriverPopup.assignedVehicleName}</span> ({activeDriverPopup.assignedVehiclePlate})
                </p>
                <p className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{activeDriverPopup.phone}</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 border-t text-[10px] text-slate-600">
                <div className="bg-slate-50 p-1.5 rounded">
                  <span className="block text-slate-400">Today Earnings</span>
                  <span className="font-bold text-emerald-600 text-xs">₹{activeDriverPopup.todayEarnings}</span>
                </div>
                <div className="bg-slate-50 p-1.5 rounded">
                  <span className="block text-slate-400">Trips Done</span>
                  <span className="font-bold text-indigo-600 text-xs">{activeDriverPopup.todayTrips} completed</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 pt-1">
                <a
                  href={`tel:${activeDriverPopup.phone}`}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-center text-[11px] flex items-center justify-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Call Driver
                </a>
              </div>
            </div>
          </InfoWindow>
        )}
      </Map>
    </div>
  );
};
