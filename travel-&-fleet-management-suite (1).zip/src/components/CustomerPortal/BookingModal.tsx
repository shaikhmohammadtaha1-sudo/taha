import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Vehicle } from '../../types';
import { calculateDetailedFare } from '../../utils/fareCalculator';
import {
  X,
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Car,
  User,
  Phone,
  Mail,
  FileText,
  ShieldCheck,
  ArrowRight,
  MessageSquare,
} from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingData: {
    vehicle: Vehicle;
    pickup: string;
    drop: string;
    tripType: 'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour';
    pickupDate: string;
    pickupTime: string;
    returnDate?: string;
    estimatedDistanceKm: number;
    estimatedDurationHrs: number;
    totalFare: number;
    breakdown: ReturnType<typeof calculateDetailedFare>;
  } | null;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, bookingData }) => {
  const { addInquiry, cms } = useApp();

  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [passengers, setPassengers] = useState<number>(2);
  const [notes, setNotes] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [confirmedInquiryNo, setConfirmedInquiryNo] = useState<string>('');

  if (!isOpen || !bookingData) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone) return;

    const inqId = addInquiry({
      customerName,
      phone,
      email,
      pickupLocation: bookingData.pickup,
      dropLocation: bookingData.drop,
      tripType: bookingData.tripType,
      pickupDate: bookingData.pickupDate,
      pickupTime: bookingData.pickupTime,
      returnDate: bookingData.returnDate,
      passengers,
      vehicleId: bookingData.vehicle.id,
      vehicleName: bookingData.vehicle.name,
      estimatedDistanceKm: bookingData.estimatedDistanceKm,
      estimatedDurationHrs: bookingData.estimatedDurationHrs,
      calculatedBaseFare: bookingData.breakdown.baseFareComponent,
      estimatedFuelCost: bookingData.breakdown.fuelComponentEstimate,
      estimatedTolls: bookingData.breakdown.tollEstimate,
      driverAllowance: bookingData.breakdown.driverAllowance,
      nightCharges: bookingData.breakdown.nightCharge,
      taxAmount: bookingData.breakdown.taxAmount,
      totalQuote: bookingData.totalFare,
      status: 'new',
      notes: notes ? notes : 'Direct Web Instant Inquiry',
    });

    setConfirmedInquiryNo(`INQ-${inqId.slice(-4)}`);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setCustomerName('');
    setPhone('');
    setEmail('');
    setNotes('');
    onClose();
  };

  return (
    <div id="customer-booking-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-xl">
              <Car className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold">
                {isSubmitted ? 'Booking Inquiry Confirmed!' : 'Review & Confirm Ride Booking'}
              </h3>
              <p className="text-xs text-slate-400">
                {isSubmitted ? 'Our operations desk has received your request.' : `${bookingData.vehicle.name} • ${bookingData.tripType.replace('_', ' ').toUpperCase()}`}
              </p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Journey Summary Bar */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs sm:text-sm">
              <div className="flex items-center justify-between font-semibold text-slate-800">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  {bookingData.pickup} ➔ {bookingData.drop}
                </span>
                <span className="text-indigo-600 font-bold">
                  {bookingData.vehicle.name}
                </span>
              </div>
              <div className="flex flex-wrap gap-4 text-slate-500 text-xs pt-1 border-t border-slate-200">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" /> {bookingData.pickupDate}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" /> {bookingData.pickupTime}
                </span>
                <span>Est. Distance: {bookingData.estimatedDistanceKm} KM</span>
                <span className="text-emerald-700 font-medium">Chauffeur & AC Included</span>
              </div>
            </div>

            {/* Passenger Details */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Passenger Contact Details
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      id="input-book-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Rameshwar Patil"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mobile Phone (WhatsApp) *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      id="input-book-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98XXX XXXXX"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address (Optional)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Number of Passengers
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={bookingData.vehicle.seatingCapacity}
                    value={passengers}
                    onChange={(e) => setPassengers(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Special Notes / Flight Number / Requests
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Need child seat, excess luggage, flight arriving on Terminal 2 gate 4..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Guarantee Note */}
            <div className="flex items-start gap-2.5 p-3.5 bg-emerald-50 text-emerald-800 rounded-xl text-xs border border-emerald-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <b>Verified Quote & Booking Dispatch:</b> No upfront charges. Our dispatch admin verifies highway tolls, driver allowance, and dispatches your official quote and chauffeur details directly to your WhatsApp.
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="btn-submit-booking-inquiry"
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-md shadow-indigo-200 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <span>Submit Inquiry & Receive Quote</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        ) : (
          /* Submission Success State */
          <div className="p-8 text-center space-y-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="inline-block px-3 py-1 bg-slate-100 rounded-full text-xs font-mono font-bold text-slate-700 mb-2">
                Inquiry Ref: {confirmedInquiryNo}
              </span>
              <h4 className="text-2xl font-bold text-slate-900">
                Inquiry Submitted Successfully!
              </h4>
              <p className="text-sm text-slate-600 max-w-md mx-auto mt-2">
                Thank you <b>{customerName}</b>. Our operations desk has received your request for <b>{bookingData.vehicle.name}</b> and is preparing your verified quote.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs sm:text-sm space-y-1.5 max-w-md mx-auto">
              <div className="flex justify-between">
                <span className="text-slate-500">Route:</span>
                <span className="font-semibold text-slate-800">{bookingData.pickup} ➔ {bookingData.drop}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pickup Date & Time:</span>
                <span className="font-semibold text-slate-800">{bookingData.pickupDate} at {bookingData.pickupTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Estimated Distance:</span>
                <span className="font-semibold text-slate-800">{bookingData.estimatedDistanceKm} KM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="font-bold text-indigo-600">Under Review by Dispatch</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href={`https://wa.me/${cms.whatsapp.replace(/\D/g, '')}?text=Hello%20${encodeURIComponent(cms.brandName)},%20I%20have%20submitted%20inquiry%20${confirmedInquiryNo}%20for%20pickup%20on%20${bookingData.pickupDate}.%20Please%20share%20quote%20and%20chauffeur%20details.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-200 transition-all"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Instant WhatsApp Updates</span>
              </a>

              <button
                onClick={handleReset}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                Close & Return
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
