import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Vehicle } from '../../types';
import { estimateRouteDetails, calculateDetailedFare, FareCalculationResult } from '../../utils/fareCalculator';
import {
  MapPin,
  Calendar,
  Clock,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Check,
  Fuel,
  Users,
  Info,
  Map as MapIcon,
  Navigation,
  Sparkles,
  Car,
  Layers,
  Zap,
} from 'lucide-react';
import { GoogleMapWrapper, hasValidGoogleMapsKey } from '../GoogleMaps/GoogleMapWrapper';
import { LiveGoogleRouteMap } from '../GoogleMaps/LiveGoogleRouteMap';
import { PlaceAutocompleteInput } from '../GoogleMaps/PlaceAutocompleteInput';
import { LeafletMap } from '../Common/LeafletMap';
import { PriceBreakupModal } from './PriceBreakupModal';

interface FareCalculatorWidgetProps {
  onSelectBooking: (details: {
    vehicle: Vehicle;
    pickup: string;
    drop: string;
    tripType: 'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour';
    pickupDate: string;
    pickupTime: string;
    returnDate?: string;
    estimatedDistanceKm: number;
    estimatedDurationHrs: number;
    totalFare: number;
    breakdown: ReturnType<typeof calculateDetailedFare>;
  }) => void;
}

export const FareCalculatorWidget: React.FC<FareCalculatorWidgetProps> = ({ onSelectBooking }) => {
  const { vehicles, cms, drivers } = useApp();

  const [topServiceTab, setTopServiceTab] = useState<'daily' | 'outstation' | 'rentals'>('outstation');
  const [journeyType, setJourneyType] = useState<'one_way' | 'round_trip'>('round_trip');
  const [rentalPackage, setRentalPackage] = useState<'8hr_80km' | '4hr_40km' | '12hr_120km'>('8hr_80km');
  const [rideTimingMode, setRideTimingMode] = useState<'now' | 'later'>('now');

  const [pickup, setPickup] = useState<string>('Bright Spark Diagnostic Centre, Aasawari Gruhsankul, Shop No 1');
  const [drop, setDrop] = useState<string>('Shirwal, Maharashtra India');
  const [pickupCoords, setPickupCoords] = useState<[number, number] | undefined>([18.5204, 73.8567]);
  const [dropCoords, setDropCoords] = useState<[number, number] | undefined>([18.1362, 73.9829]);

  const [pickupDate, setPickupDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [pickupTime, setPickupTime] = useState<string>('23:45');
  const [returnDate, setReturnDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });
  const [returnTime, setReturnTime] = useState<string>('05:45');

  const [selectedVehicleForBreakup, setSelectedVehicleForBreakup] = useState<Vehicle | null>(null);
  const [isBreakupModalOpen, setIsBreakupModalOpen] = useState<boolean>(false);

  const [mapEngine, setMapEngine] = useState<'google' | 'leaflet'>(hasValidGoogleMapsKey ? 'google' : 'leaflet');
  const [showLiveMap, setShowLiveMap] = useState<boolean>(false);
  const [liveMapKm, setLiveMapKm] = useState<number | null>(null);
  const [liveMapDuration, setLiveMapDuration] = useState<number | null>(null);

  // Synchronize trip type with top tabs & journey type
  const effectiveTripType = useMemo<'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour'>(() => {
    if (topServiceTab === 'daily') return 'daily_ride';
    if (topServiceTab === 'rentals') return 'local_rental';
    return journeyType;
  }, [topServiceTab, journeyType]);

  // When switching service tabs, provide contextual defaults
  const handleSelectServiceTab = (tab: 'daily' | 'outstation' | 'rentals') => {
    setTopServiceTab(tab);
    setLiveMapKm(null);
    setLiveMapDuration(null);

    if (tab === 'daily') {
      setPickup('Bandra Kurla Complex (BKC), Mumbai');
      setDrop('Mumbai Domestic Airport Terminal 1');
      setPickupCoords([19.0657, 72.8687]);
      setDropCoords([19.0886, 72.8535]);
    } else if (tab === 'outstation') {
      setPickup('Bright Spark Diagnostic Centre, Aasawari Gruhsankul, Shop No 1');
      setDrop('Shirwal, Maharashtra India');
      setPickupCoords([18.5204, 73.8567]);
      setDropCoords([18.1362, 73.9829]);
    } else if (tab === 'rentals') {
      setPickup('Mumbai Airport Terminal 2');
      setDrop('Full Day City Tour & Business Meetings');
    }
  };

  // Fallback distance estimation
  const fallbackRoute = useMemo(() => {
    return estimateRouteDetails(pickup, drop, effectiveTripType);
  }, [pickup, drop, effectiveTripType]);

  // Active distance
  const activeDistanceKm = useMemo(() => {
    if (liveMapKm && liveMapKm > 0) {
      if (effectiveTripType === 'round_trip') return Math.round(liveMapKm * 2);
      return liveMapKm;
    }
    return fallbackRoute.distanceKm;
  }, [liveMapKm, fallbackRoute.distanceKm, effectiveTripType]);

  const activeDurationHrs = useMemo(() => {
    if (liveMapDuration && liveMapDuration > 0) {
      if (effectiveTripType === 'round_trip') return Math.round(liveMapDuration * 2 * 10) / 10;
      return liveMapDuration;
    }
    return fallbackRoute.durationHrs;
  }, [liveMapDuration, fallbackRoute.durationHrs, effectiveTripType]);

  // Handle clicking on vehicle card
  const handleOpenVehicleBreakup = (vehicle: Vehicle) => {
    setSelectedVehicleForBreakup(vehicle);
    setIsBreakupModalOpen(true);
  };

  const handleConfirmBookingFromModal = (fareResult: FareCalculationResult) => {
    if (!selectedVehicleForBreakup) return;
    onSelectBooking({
      vehicle: selectedVehicleForBreakup,
      pickup,
      drop: effectiveTripType === 'local_rental' ? 'City Rental Tour (8h/80km)' : drop,
      tripType: effectiveTripType,
      pickupDate,
      pickupTime,
      returnDate: effectiveTripType === 'round_trip' ? returnDate : undefined,
      estimatedDistanceKm: activeDistanceKm,
      estimatedDurationHrs: activeDurationHrs,
      totalFare: fareResult.totalFare,
      breakdown: fareResult,
    });
  };

  return (
    <section id="fare-calculator-widget" className="relative -mt-12 z-20 max-w-4xl mx-auto px-3 sm:px-6 mb-16">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* 1. TOP SERVICE TABS: DAILY RIDES | OUTSTATION | RENTALS */}
        <div className="border-b border-slate-200 bg-slate-50/70 px-4 py-3 flex items-center justify-around sm:justify-center sm:gap-10">
          {/* DAILY RIDES */}
          <button
            type="button"
            onClick={() => handleSelectServiceTab('daily')}
            className={`text-xs sm:text-sm font-extrabold uppercase tracking-wider transition-all py-1.5 px-4 rounded-full cursor-pointer flex items-center gap-1.5 ${
              topServiceTab === 'daily'
                ? 'bg-amber-300 text-slate-950 shadow-xs ring-1 ring-amber-400 font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>DAILY RIDES</span>
          </button>

          {/* OUTSTATION */}
          <button
            type="button"
            onClick={() => handleSelectServiceTab('outstation')}
            className={`text-xs sm:text-sm font-extrabold uppercase tracking-wider transition-all py-1.5 px-5 rounded-full cursor-pointer flex items-center gap-1.5 ${
              topServiceTab === 'outstation'
                ? 'bg-[#d9f99d] text-slate-950 shadow-xs ring-1 ring-lime-400 font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>OUTSTATION</span>
          </button>

          {/* RENTALS */}
          <button
            type="button"
            onClick={() => handleSelectServiceTab('rentals')}
            className={`text-xs sm:text-sm font-extrabold uppercase tracking-wider transition-all py-1.5 px-4 rounded-full cursor-pointer flex items-center gap-1.5 ${
              topServiceTab === 'rentals'
                ? 'bg-amber-300 text-slate-950 shadow-xs ring-1 ring-amber-400 font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>RENTALS</span>
          </button>
        </div>

        {/* 2. FROM & TO ADDRESS FIELDS */}
        <div className="p-4 sm:p-6 space-y-4 bg-white">
          <div className="space-y-3 bg-slate-50/80 p-3.5 sm:p-4 rounded-2xl border border-slate-200">
            {/* FROM */}
            <div className="flex items-start gap-3">
              <span className="text-[11px] font-bold text-slate-400 uppercase w-12 pt-2.5 shrink-0">
                FROM
              </span>
              <div className="flex-1">
                <PlaceAutocompleteInput
                  id="outstation-pickup-input"
                  value={pickup}
                  onChange={(val) => {
                    setPickup(val);
                    setLiveMapKm(null);
                  }}
                  onPlaceSelect={(place) => {
                    setPickup(place.address);
                    setPickupCoords([place.lat, place.lng]);
                  }}
                  placeholder={
                    topServiceTab === 'daily'
                      ? 'Enter pickup locality, metro or office...'
                      : 'Enter pickup address, airport or hub...'
                  }
                />
              </div>
            </div>

            {/* TO */}
            {topServiceTab !== 'rentals' ? (
              <div className="flex items-start gap-3 pt-2 border-t border-slate-200/80">
                <span className="text-[11px] font-bold text-slate-400 uppercase w-12 pt-2.5 shrink-0">
                  TO
                </span>
                <div className="flex-1">
                  <PlaceAutocompleteInput
                    id="outstation-drop-input"
                    value={drop}
                    onChange={(val) => {
                      setDrop(val);
                      setLiveMapKm(null);
                    }}
                    onPlaceSelect={(place) => {
                      setDrop(place.address);
                      setDropCoords([place.lat, place.lng]);
                    }}
                    placeholder={
                      topServiceTab === 'daily'
                        ? 'Enter destination drop in city...'
                        : 'Enter destination city, hotel or address in India...'
                    }
                  />
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-3 pt-2 border-t border-slate-200/80">
                <span className="text-[11px] font-bold text-slate-400 uppercase w-12 pt-2.5 shrink-0">
                  PACKAGE
                </span>
                <div className="flex-1 grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setRentalPackage('8hr_80km')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      rentalPackage === '8hr_80km'
                        ? 'border-slate-900 bg-slate-900 text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    8 Hrs / 80 Km
                  </button>
                  <button
                    type="button"
                    onClick={() => setRentalPackage('4hr_40km')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      rentalPackage === '4hr_40km'
                        ? 'border-slate-900 bg-slate-900 text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    4 Hrs / 40 Km
                  </button>
                  <button
                    type="button"
                    onClick={() => setRentalPackage('12hr_120km')}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      rentalPackage === '12hr_120km'
                        ? 'border-slate-900 bg-slate-900 text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    12 Hrs / 120 Km
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 3. JOURNEY SELECTOR (OUTSTATION ONLY) or TIMING (DAILY RIDES) */}
          {topServiceTab === 'outstation' && (
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-bold text-slate-500 uppercase w-16 shrink-0">
                JOURNEY
              </span>
              <div className="grid grid-cols-2 gap-3 flex-1">
                {/* One Way Button */}
                <button
                  type="button"
                  onClick={() => setJourneyType('one_way')}
                  className={`py-3 px-4 rounded-2xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                    journeyType === 'one_way'
                      ? 'border-slate-900 bg-slate-50 text-slate-950 shadow-sm'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      journeyType === 'one_way'
                        ? 'border-slate-900 bg-slate-900 text-white'
                        : 'border-slate-400 bg-transparent'
                    }`}
                  >
                    {journeyType === 'one_way' && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span>One Way</span>
                </button>

                {/* Round Trip Button */}
                <button
                  type="button"
                  onClick={() => setJourneyType('round_trip')}
                  className={`py-3 px-4 rounded-2xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                    journeyType === 'round_trip'
                      ? 'border-slate-900 bg-slate-50 text-slate-950 shadow-sm'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      journeyType === 'round_trip'
                        ? 'border-slate-900 bg-slate-900 text-white'
                        : 'border-slate-400 bg-transparent'
                    }`}
                  >
                    {journeyType === 'round_trip' && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span>Round Trip</span>
                </button>
              </div>
            </div>
          )}

          {/* Daily Rides: Ride Now vs Schedule Later */}
          {topServiceTab === 'daily' && (
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-bold text-slate-500 uppercase w-16 shrink-0">
                TIMING
              </span>
              <div className="grid grid-cols-2 gap-3 flex-1">
                <button
                  type="button"
                  onClick={() => setRideTimingMode('now')}
                  className={`py-2.5 px-4 rounded-2xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    rideTimingMode === 'now'
                      ? 'border-slate-900 bg-slate-900 text-white shadow-sm'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span>Ride Now (ETA 3 mins)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRideTimingMode('later')}
                  className={`py-2.5 px-4 rounded-2xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    rideTimingMode === 'later'
                      ? 'border-slate-900 bg-slate-900 text-white shadow-sm'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Schedule for Later</span>
                </button>
              </div>
            </div>
          )}

          {/* 4. DEPART & RETURN DATE/TIME SELECTORS */}
          {(topServiceTab !== 'daily' || rideTimingMode === 'later') && (
            <div className="space-y-2.5 animate-in fade-in duration-200">
              {/* DEPART */}
              <div className="flex items-center gap-3">
                <span className="text-[11px] font-bold text-slate-500 uppercase w-16 shrink-0">
                  DEPART
                </span>
                <div className="grid grid-cols-2 gap-3 flex-1">
                  <input
                    type="date"
                    value={pickupDate}
                    min={new Date().toISOString().slice(0, 10)}
                    onChange={(e) => setPickupDate(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                  <input
                    type="time"
                    value={pickupTime}
                    onChange={(e) => setPickupTime(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                </div>
              </div>

              {/* RETURN (Visible for Outstation Round Trip) */}
              {topServiceTab === 'outstation' && journeyType === 'round_trip' && (
                <div className="flex items-center gap-3 animate-in fade-in duration-200">
                  <span className="text-[11px] font-bold text-slate-500 uppercase w-16 shrink-0">
                    RETURN
                  </span>
                  <div className="grid grid-cols-2 gap-3 flex-1">
                    <input
                      type="date"
                      value={returnDate}
                      min={pickupDate}
                      onChange={(e) => setReturnDate(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                    />
                    <input
                      type="time"
                      value={returnTime}
                      onChange={(e) => setReturnTime(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 5. YELLOW HIGHLIGHT INFO BANNER */}
          <div className="bg-[#fef9c3] rounded-2xl p-3.5 sm:p-4 border border-amber-200/80 flex items-start gap-3 shadow-xs">
            <div className="w-8 h-8 rounded-full bg-amber-400/30 border border-amber-500/40 flex items-center justify-center text-amber-900 shrink-0 mt-0.5">
              <MapPin className="w-4 h-4 text-amber-800" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                {topServiceTab === 'daily'
                  ? `Direct City Ride: Approx ${activeDistanceKm} km (${Math.max(12, Math.round(activeDurationHrs * 60))} mins)`
                  : topServiceTab === 'rentals'
                  ? 'City Full Day Rental (8 Hours / 80 KM Included)'
                  : journeyType === 'round_trip'
                  ? `${Math.max(1, Math.round(activeDurationHrs))} hour round trip of about ${activeDistanceKm} km`
                  : `About ${activeDistanceKm} km`}
              </h4>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-[11px] text-slate-700 font-medium">
                {topServiceTab === 'daily' ? (
                  <>
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600 stroke-[3]" /> Standard metered city rates
                    </span>
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600 stroke-[3]" /> No outstation min distance
                    </span>
                  </>
                ) : (
                  <>
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600 stroke-[3]" /> No pre-payment required
                    </span>
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3 text-emerald-600 stroke-[3]" /> Free cancellation
                    </span>
                  </>
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowLiveMap(!showLiveMap)}
              className="px-2.5 py-1 rounded-lg bg-white hover:bg-amber-100 text-slate-800 border border-amber-300 text-[11px] font-semibold flex items-center gap-1 transition-all cursor-pointer shrink-0"
            >
              <MapIcon className="w-3 h-3 text-indigo-600" />
              <span>{showLiveMap ? 'Hide Map' : 'View Map'}</span>
            </button>
          </div>

          {/* Live Map Preview Drawer if toggled */}
          {showLiveMap && (
            <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-md animate-in fade-in duration-200">
              <div className="bg-slate-900 text-white px-3.5 py-2 flex items-center justify-between text-xs">
                <span className="font-bold flex items-center gap-1.5">
                  <Navigation className="w-3.5 h-3.5 text-indigo-400" /> Live Route & Distance Engine
                </span>
                <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg text-[10px]">
                  <button
                    type="button"
                    onClick={() => setMapEngine('google')}
                    className={`px-2 py-0.5 rounded ${
                      mapEngine === 'google' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Google
                  </button>
                  <button
                    type="button"
                    onClick={() => setMapEngine('leaflet')}
                    className={`px-2 py-0.5 rounded ${
                      mapEngine === 'leaflet' ? 'bg-indigo-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Standard
                  </button>
                </div>
              </div>

              {mapEngine === 'google' ? (
                <GoogleMapWrapper fallbackHeight="260px">
                  <LiveGoogleRouteMap
                    pickupLocation={pickup}
                    dropLocation={drop}
                    pickupCoords={pickupCoords}
                    dropCoords={dropCoords}
                    drivers={drivers}
                    onRouteCalculated={({ distanceKm, durationHrs }) => {
                      setLiveMapKm(distanceKm);
                      setLiveMapDuration(durationHrs);
                    }}
                    height="260px"
                  />
                </GoogleMapWrapper>
              ) : (
                <LeafletMap
                  pickupCoords={pickupCoords}
                  dropCoords={dropCoords}
                  pickupLocation={pickup}
                  dropLocation={drop}
                  onRouteCalculated={({ distanceKm, durationHrs }) => {
                    setLiveMapKm(distanceKm);
                    setLiveMapDuration(durationHrs);
                  }}
                  drivers={drivers}
                  height="260px"
                />
              )}
            </div>
          )}

          {/* 6. FLEET VEHICLE CARDS LIST */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800 uppercase tracking-wider px-1">
              <span>
                {topServiceTab === 'daily'
                  ? 'Available City Cabs'
                  : topServiceTab === 'rentals'
                  ? 'Rental Fleet Packages'
                  : 'Outstation Fleet Categories'}
              </span>
              <span className="text-[11px] text-indigo-600 font-semibold normal-case">
                Select cab to book ride
              </span>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs">
              {vehicles.map((veh) => {
                const fareObj = calculateDetailedFare(
                  veh,
                  cms,
                  activeDistanceKm,
                  effectiveTripType,
                  pickupTime,
                  returnDate,
                  pickupDate
                );

                return (
                  <div
                    key={veh.id}
                    onClick={() => handleOpenVehicleBreakup(veh)}
                    className="p-3.5 sm:p-4 hover:bg-slate-50/90 transition-all cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    {/* Left: Car Image & Details */}
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="w-14 h-11 sm:w-16 sm:h-12 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                        <img
                          src={veh.imageUrl}
                          alt={veh.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate group-hover:text-indigo-900">
                            {veh.name}
                          </h4>
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-semibold">
                            {veh.seatingCapacity} Seater
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">
                          {veh.subtitleModels || veh.model} • {veh.acType}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate hidden sm:block">
                          {topServiceTab === 'daily'
                            ? `AC Cab • 3-5 mins away • Sanitized Chauffeur`
                            : topServiceTab === 'rentals'
                            ? `8h / 80km package • Multi-stop city tour`
                            : veh.features[0] || 'Sanitized AC Cab with Chauffeur'}
                        </p>
                      </div>
                    </div>

                    {/* Right: Booking Action Button */}
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 group-hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-colors">
                          <span>Request Ride</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          Instant Dispatch
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 7. PRICE BREAKUP MODAL */}
      {selectedVehicleForBreakup && (
        <PriceBreakupModal
          isOpen={isBreakupModalOpen}
          onClose={() => setIsBreakupModalOpen(false)}
          vehicle={selectedVehicleForBreakup}
          cms={cms}
          distanceKm={activeDistanceKm}
          durationHrs={activeDurationHrs}
          tripType={effectiveTripType}
          pickup={pickup}
          drop={effectiveTripType === 'local_rental' ? 'City Local Tour (8h/80km)' : drop}
          pickupDate={pickupDate}
          pickupTime={pickupTime}
          returnDate={returnDate}
          onConfirmBooking={handleConfirmBookingFromModal}
        />
      )}
    </section>
  );
};
