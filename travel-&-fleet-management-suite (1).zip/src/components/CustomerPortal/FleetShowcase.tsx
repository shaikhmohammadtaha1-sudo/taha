import React from 'react';
import { useApp } from '../../context/AppContext';
import { Vehicle } from '../../types';
import { Users, Briefcase, Fuel, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface FleetShowcaseProps {
  onQuickBook: (vehicle: Vehicle) => void;
}

export const FleetShowcase: React.FC<FleetShowcaseProps> = ({ onQuickBook }) => {
  const { vehicles, cms } = useApp();

  return (
    <section id="fleet-showcase-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold uppercase tracking-wider mb-3">
          <ShieldCheck className="w-4 h-4 text-indigo-600" />
          <span>Executive & Tourism Fleet</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-['Outfit',sans-serif]">
          Choose the Perfect Ride for Your Journey
        </h2>
        <p className="mt-3 text-slate-600 text-sm sm:text-base">
          From economical city commute cabs to luxury outstation cruisers, all cars are maintained with strict scheduled servicing and real-time GPS telemetry.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {vehicles.map((vehicle) => {
          const isCompanyOwned = vehicle.ownershipType === 'company_owned';
          return (
            <div
              key={vehicle.id}
              className="bg-white rounded-3xl border border-slate-200/80 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden group"
            >
              {/* Vehicle Image with Badge */}
              <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-slate-100">
                <img
                  src={vehicle.imageUrl}
                  alt={vehicle.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className="px-2.5 py-1 bg-slate-900/80 backdrop-blur-md text-white text-xs font-semibold rounded-lg">
                    {vehicle.category.replace('_', ' ').toUpperCase()}
                  </span>
                  {isCompanyOwned && (
                    <span className="px-2.5 py-1 bg-emerald-600/90 backdrop-blur-md text-white text-[11px] font-semibold rounded-lg">
                      Company Owned
                    </span>
                  )}
                </div>
                <div className="absolute bottom-3 right-3 px-3 py-1 bg-white/90 backdrop-blur-md text-slate-900 text-xs font-bold rounded-lg shadow-sm">
                  {vehicle.acType}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {vehicle.name}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" /> {vehicle.seatingCapacity} Passengers
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-3.5 h-3.5 text-slate-400" /> {vehicle.luggageCapacity} Bags
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                      <Fuel className="w-3.5 h-3.5" /> AC Chauffeur
                    </span>
                  </div>

                  {/* Feature Highlights */}
                  <div className="space-y-1.5 mb-6">
                    {vehicle.features.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Booking Action */}
                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block font-medium">Pricing Model</span>
                    <span className="text-xs font-bold text-slate-800">
                      Verified Route Quote
                    </span>
                  </div>

                  <button
                    onClick={() => onQuickBook(vehicle)}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm shadow-indigo-200 cursor-pointer"
                  >
                    <span>Request Booking</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
