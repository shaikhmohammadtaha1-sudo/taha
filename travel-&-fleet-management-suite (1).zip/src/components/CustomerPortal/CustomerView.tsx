import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Vehicle } from '../../types';
import { HeroBanner } from './HeroBanner';
import { FareCalculatorWidget } from './FareCalculatorWidget';
import { FleetShowcase } from './FleetShowcase';
import { BookingModal } from './BookingModal';
import { calculateDetailedFare } from '../../utils/fareCalculator';
import {
  ShieldCheck,
  Zap,
  PhoneCall,
  Clock,
  Car,
  Compass,
  FileSpreadsheet,
  Award,
  Smartphone,
} from 'lucide-react';

export const CustomerView: React.FC = () => {
  const { cms, vehicles, setCurrentView, setAdminTab } = useApp();

  const [activeBookingData, setActiveBookingData] = useState<{
    vehicle: Vehicle;
    pickup: string;
    drop: string;
    tripType: 'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour';
    pickupDate: string;
    pickupTime: string;
    returnDate?: string;
    estimatedDistanceKm: number;
    estimatedDurationHrs: number;
    totalFare: number;
    breakdown: ReturnType<typeof calculateDetailedFare>;
  } | null>(null);

  const [isBookingModalOpen, setIsBookingModalOpen] = useState<boolean>(false);

  const handleSelectBooking = (details: typeof activeBookingData) => {
    setActiveBookingData(details);
    setIsBookingModalOpen(true);
  };

  const handleQuickBook = (vehicle: Vehicle) => {
    const defaultBreakdown = calculateDetailedFare(
      vehicle,
      cms,
      155,
      'one_way',
      '10:00'
    );
    setActiveBookingData({
      vehicle,
      pickup: 'Mumbai Airport Terminal 2',
      drop: 'Pune Hinjewadi Phase 1',
      tripType: 'one_way',
      pickupDate: new Date().toISOString().slice(0, 10),
      pickupTime: '10:00',
      estimatedDistanceKm: 155,
      estimatedDurationHrs: 3.2,
      totalFare: defaultBreakdown.totalFare,
      breakdown: defaultBreakdown,
    });
    setIsBookingModalOpen(true);
  };

  return (
    <div id="customer-public-portal-view" className="min-h-screen bg-slate-50 flex flex-col">
      {/* 1. Hero Banner */}
      <HeroBanner />

      {/* 2. Interactive Fare Calculator */}
      <FareCalculatorWidget onSelectBooking={handleSelectBooking} />

      {/* 3. Fleet Showcase */}
      <FleetShowcase onQuickBook={handleQuickBook} />

      {/* 4. Why TransVoyage Feature Strip */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl sm:text-3xl font-bold font-['Outfit',sans-serif]">
              Engineered for Seamless Highway & Corporate Travel
            </h3>
            <p className="text-slate-400 text-sm mt-2">
              Every vehicle undergoes strict preventive maintenance audits, backed by satellite GPS speed and route telemetry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
              <div className="p-3 bg-indigo-600/20 text-indigo-400 w-fit rounded-xl mb-4 border border-indigo-500/30">
                <Compass className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Live Dynamic Fuel & Toll Engine</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Fares are calculated algorithmically matching vehicle fuel efficiency (km/l), current fuel rates, and actual Fastag highway tolls.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
              <div className="p-3 bg-emerald-600/20 text-emerald-400 w-fit rounded-xl mb-4 border border-emerald-500/30">
                <Smartphone className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Real-Time Driver App Bridge</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Autonomous driver companion application streams GPS coordinates directly to dispatch without requiring third-party intermediary dispatch servers.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
              <div className="p-3 bg-amber-600/20 text-amber-400 w-fit rounded-xl mb-4 border border-amber-500/30">
                <Award className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Strict Odometer Service Audits</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Company-owned cars are serviced every 10,000 km with active digital reminders preventing breakdowns during long-distance client journeys.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Footer */}
      <footer className="mt-auto bg-slate-950 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 text-white font-bold text-lg font-['Outfit',sans-serif] mb-2">
                <Car className="w-5 h-5 text-indigo-400" />
                <span>{cms.brandName}</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 max-w-sm leading-relaxed mb-4">
                {cms.aboutUs}
              </p>
              <div className="text-xs text-slate-300 space-y-1">
                <div>📍 {cms.address}</div>
                <div>📞 Phone: {cms.phone} | WhatsApp: {cms.whatsapp}</div>
                <div>✉️ Email: {cms.email}</div>
              </div>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
                Fleet Categories
              </h5>
              <ul className="space-y-2 text-xs">
                {vehicles.map((v) => (
                  <li key={v.id} className="hover:text-white transition-colors">
                    {v.name} ({v.category.toUpperCase()})
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
                Operations & Portals
              </h5>
              <ul className="space-y-2 text-xs">
                <li>
                  <button
                    onClick={() => {
                      setCurrentView('admin');
                      setAdminTab('analytics');
                    }}
                    className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
                  >
                    🛡️ Admin Management Dashboard
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setCurrentView('admin');
                      setAdminTab('inquiries');
                    }}
                    className="text-slate-300 hover:text-white cursor-pointer"
                  >
                    📋 CRM Inquiries & Follow-ups
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setCurrentView('driver')}
                    className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                  >
                    📱 Driver Companion App
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => {
                      setCurrentView('admin');
                      setAdminTab('export_apk');
                    }}
                    className="text-slate-300 hover:text-white cursor-pointer"
                  >
                    📦 Netlify Drop & APK Hub
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <div>
              <div className="text-slate-400 font-medium">
                © {new Date().getFullYear()} {cms.legalCompanyName || cms.brandName} • {cms.copyrightNotice || 'All Rights Reserved.'}
              </div>
              {cms.customFooterNote && (
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {cms.customFooterNote}
                </div>
              )}
            </div>
            <div className="flex gap-4">
              <span>Privacy Policy</span>
              <span>•</span>
              <span>Terms of Fleet Service</span>
              <span>•</span>
              <span>Fastag Disclaimers</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        bookingData={activeBookingData}
      />
    </div>
  );
};
