import React from 'react';
import { useApp } from '../../context/AppContext';
import { Shield, Sparkles, Navigation, Clock, Award, Phone } from 'lucide-react';

export const HeroBanner: React.FC = () => {
  const { cms, vehicles, startTour } = useApp();

  return (
    <div id="customer-hero-banner" className="relative overflow-hidden bg-slate-900 text-white">
      {/* Background Image with Dark Vignette Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={cms.heroBannerImage}
          alt="Fleet Highway Travel"
          className="w-full h-full object-cover object-center opacity-25 scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-slate-900/40" />
      </div>

      {/* Decorative Glow */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-16 lg:pb-24">
        <div className="max-w-3xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-semibold uppercase tracking-wider mb-6">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Verified Fleet & GPS Monitored Chauffeurs</span>
          </div>

          {/* Headline (CMS editable) */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight font-['Outfit',sans-serif] mb-4">
            {cms.heroHeadline}
          </h1>

          {/* Subheadline (CMS editable) */}
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-8">
            {cms.heroSubheadline}
          </p>

          {/* Quick Action Buttons & Tour Guide */}
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#fare-calculator-section"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02]"
            >
              <Navigation className="w-4 h-4" />
              <span>Calculate Highway Fare</span>
            </a>

            <button
              onClick={startTour}
              className="inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-slate-800/90 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-xl font-semibold text-sm transition-all hover:text-white cursor-pointer"
            >
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Platform Interactive Tour</span>
            </button>

            <a
              href={`tel:${cms.phone}`}
              className="inline-flex items-center justify-center gap-2 px-4 py-3.5 text-slate-300 hover:text-white text-sm font-medium transition-colors"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Call Us: {cms.phone}</span>
            </a>
          </div>

          {/* Key Metrics Strip */}
          <div className="grid grid-cols-3 gap-4 pt-10 mt-10 border-t border-slate-800/80">
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit',sans-serif]">
                {vehicles.length}+
              </div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Active Fleet Vehicles</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit',sans-serif]">
                100%
              </div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">GPS Live Tracked</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit',sans-serif]">
                ₹0
              </div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Hidden Surcharges</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
