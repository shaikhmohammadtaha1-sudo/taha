import React from 'react';
import { Vehicle, WebsiteCMS } from '../../types';
import { calculateDetailedFare, FareCalculationResult } from '../../utils/fareCalculator';
import {
  X,
  ShieldCheck,
  Fuel,
  Navigation,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Info,
  Car,
  Users,
  Briefcase,
  MapPin,
} from 'lucide-react';

interface PriceBreakupModalProps {
  isOpen: boolean;
  onClose: () => void;
  vehicle: Vehicle;
  cms: WebsiteCMS;
  distanceKm: number;
  durationHrs: number;
  tripType: 'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour';
  pickup: string;
  drop: string;
  pickupDate: string;
  pickupTime: string;
  returnDate?: string;
  onConfirmBooking: (fareResult: FareCalculationResult) => void;
}

export const PriceBreakupModal: React.FC<PriceBreakupModalProps> = ({
  isOpen,
  onClose,
  vehicle,
  cms,
  distanceKm,
  durationHrs,
  tripType,
  pickup,
  drop,
  pickupDate,
  pickupTime,
  returnDate,
  onConfirmBooking,
}) => {
  if (!isOpen || !vehicle) return null;

  const fareResult = calculateDetailedFare(
    vehicle,
    cms,
    distanceKm,
    tripType,
    pickupTime,
    returnDate,
    pickupDate
  );

  const isRound = tripType === 'round_trip';
  const isDaily = tripType === 'daily_ride';
  const isRental = tripType === 'local_rental';

  const badgeText = isDaily
    ? 'Daily City Ride'
    : isRental
    ? 'City Rental Package'
    : isRound
    ? 'Outstation Round Trip'
    : 'Outstation One Way';

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <img
              src={vehicle.imageUrl}
              alt={vehicle.name}
              referrerPolicy="no-referrer"
              className="w-14 h-10 object-cover rounded-xl border border-slate-700 bg-slate-800 shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">{vehicle.name}</h3>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
                  {badgeText}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {vehicle.subtitleModels || vehicle.model} • {vehicle.acType}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 divide-y divide-slate-100">
          {/* Route & Distance Summary */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold text-slate-800 uppercase tracking-wider text-[11px]">
                {isDaily ? 'City Trip Route' : 'Journey Summary'}
              </span>
              <span className="text-indigo-600 font-bold">
                {isRound
                  ? `${distanceKm} KM Round Trip`
                  : isRental
                  ? '8 Hours / 80 KM Package'
                  : `About ${distanceKm} KM`}
              </span>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs space-y-2">
              <div className="flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0" />
                <div className="min-w-0">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Pickup Location</span>
                  <span className="text-slate-800 font-medium truncate block">{pickup}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 mt-1 shrink-0" />
                <div className="min-w-0">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Destination Drop</span>
                  <span className="text-slate-800 font-medium truncate block">{drop}</span>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-slate-200/80 text-[11px] text-slate-600 font-medium">
                <span>🗓️ {pickupDate} at {pickupTime}</span>
                {returnDate && isRound && <span>↩️ Return: {returnDate}</span>}
              </div>
            </div>
          </div>

          {/* Vehicle Specifications */}
          <div className="pt-4">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Vehicle Capacity & Amenities
            </h4>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <Users className="w-4 h-4 text-indigo-600 mx-auto mb-1" />
                <span className="font-bold text-slate-800 block">{vehicle.seatingCapacity} Seats</span>
                <span className="text-[10px] text-slate-400">Passengers</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <Briefcase className="w-4 h-4 text-indigo-600 mx-auto mb-1" />
                <span className="font-bold text-slate-800 block">{vehicle.luggageCapacity} Bags</span>
                <span className="text-[10px] text-slate-400">Luggage Space</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <Fuel className="w-4 h-4 text-emerald-600 mx-auto mb-1" />
                <span className="font-bold text-slate-800 block">{vehicle.acType}</span>
                <span className="text-[10px] text-slate-400">Chilled AC</span>
              </div>
            </div>
          </div>

          {/* Transparent Dispatch Note */}
          <div className="pt-4">
            <div className="p-3.5 bg-indigo-50/80 rounded-2xl border border-indigo-200 text-xs text-indigo-900 space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Transparent Verified Booking Process</span>
              </div>
              <p className="text-[11px] text-indigo-800 leading-relaxed">
                Submit your booking inquiry to receive the verified official quote directly on your WhatsApp/SMS. Our admin desk verifies live distance, highway tolls, and assigns your chauffeur.
              </p>
            </div>
          </div>

          {/* Inclusions & Exclusions */}
          <div className="pt-4 grid grid-cols-2 gap-3 text-xs">
            <div className="bg-emerald-50/80 border border-emerald-200 p-3 rounded-2xl">
              <span className="font-bold text-emerald-900 text-[11px] uppercase flex items-center gap-1 mb-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Inclusions
              </span>
              <ul className="space-y-1 text-[11px] text-emerald-800">
                <li>• Clean Sanitized AC Cab</li>
                <li>• Uniformed Chauffeur</li>
                <li>• Route Fuel & Fastag</li>
                <li>• 24x7 Control Room Support</li>
              </ul>
            </div>

            <div className="bg-amber-50/80 border border-amber-200 p-3 rounded-2xl">
              <span className="font-bold text-amber-900 text-[11px] uppercase flex items-center gap-1 mb-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" /> Exclusions
              </span>
              <ul className="space-y-1 text-[11px] text-amber-800">
                <li>• Airport / Mall parking tickets</li>
                <li>• Extra detours beyond route</li>
                <li>• Multiple day halts (if any)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">
              Booking Type
            </span>
            <span className="text-sm font-bold text-slate-900">
              No Pre-payment Required
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              onConfirmBooking(fareResult);
              onClose();
            }}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 active:scale-[0.98] text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer transition-all"
          >
            <span>Proceed to Book Ride</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
