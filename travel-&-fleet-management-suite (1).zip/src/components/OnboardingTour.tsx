import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  MapPin,
  Calculator,
  ShieldCheck,
  Smartphone,
  X,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Trash2,
  FileSpreadsheet,
  Settings,
  Car,
} from 'lucide-react';

export const OnboardingTour: React.FC = () => {
  const { isTourActive, tourStepIndex, nextTourStep, prevTourStep, skipTour, setCurrentView, setAdminTab } = useApp();

  if (!isTourActive) return null;

  const tourSteps = [
    {
      title: 'Admin Control Center & Executive Analytics',
      description: 'Review real-time net revenue, total completed trips, chauffeur payouts, and live business profit margins with dynamic period filtering.',
      icon: <Sparkles className="w-8 h-8 text-indigo-500" />,
      badge: 'Admin Tour 1 of 5: Analytics',
      onEnter: () => {
        setCurrentView('admin');
        setAdminTab('analytics');
      },
    },
    {
      title: 'Inquiry CRM & Custom Toll / Quote Adjuster',
      description: 'Review incoming customer trip inquiries, edit highway tolls, customize per-km pricing, apply discounts or state permit surcharges, and send verified WhatsApp quotes.',
      icon: <Calculator className="w-8 h-8 text-emerald-500" />,
      badge: 'Admin Tour 2 of 5: Inquiries & Tolls',
      onEnter: () => {
        setCurrentView('admin');
        setAdminTab('inquiries');
      },
    },
    {
      title: 'Recycle Dump & Inquiry Recovery Archive',
      description: 'Deleted inquiries are never lost permanently. They are safely archived in the Recycle Dump with recorded deletion reasons and can be restored with a single click.',
      icon: <Trash2 className="w-8 h-8 text-rose-500" />,
      badge: 'Admin Tour 3 of 5: Recycle Dump',
      onEnter: () => {
        setCurrentView('admin');
        setAdminTab('dump');
      },
    },
    {
      title: 'Fleet Health & 10,000 KM Service Reminders',
      description: 'Monitor fleet odometer readings, schedule maintenance audits, insurance renewal alerts, and ensure every vehicle is roadworthy for outstation journeys.',
      icon: <Car className="w-8 h-8 text-amber-500" />,
      badge: 'Admin Tour 4 of 5: Fleet Audits',
      onEnter: () => {
        setCurrentView('admin');
        setAdminTab('fleet');
      },
    },
    {
      title: 'Excel Financial Reports & Driver APK Hub',
      description: 'Generate formatted Excel spreadsheets for accounting audits, download Driver App Android APK configurations, or customize website branding and fuel pricing.',
      icon: <FileSpreadsheet className="w-8 h-8 text-purple-500" />,
      badge: 'Admin Tour 5 of 5: Excel & APK Hub',
      onEnter: () => {
        setCurrentView('admin');
        setAdminTab('export_apk');
      },
    },
  ];

  const currentStep = tourSteps[tourStepIndex] || tourSteps[0];
  const isLastStep = tourStepIndex === tourSteps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      skipTour();
    } else {
      nextTourStep();
      const nextStepObj = tourSteps[tourStepIndex + 1];
      if (nextStepObj?.onEnter) {
        nextStepObj.onEnter();
      }
    }
  };

  const handlePrev = () => {
    prevTourStep();
    const prevStepObj = tourSteps[tourStepIndex - 1];
    if (prevStepObj?.onEnter) {
      prevStepObj.onEnter();
    }
  };

  return (
    <div id="interactive-onboarding-tour-modal" className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Top Header Bar with Accent */}
        <div className="h-2 bg-gradient-to-r from-indigo-500 via-sky-500 to-emerald-500" />
        
        <div className="p-6 md:p-8">
          {/* Top Row: Badge & Skip button */}
          <div className="flex items-center justify-between mb-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wide bg-indigo-50 text-indigo-700 border border-indigo-100">
              {currentStep.badge}
            </span>
            <button
              id="btn-skip-tour"
              onClick={skipTour}
              className="flex items-center gap-1 text-xs font-medium text-slate-400 hover:text-slate-700 transition-colors p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              <span>Exit Tour</span>
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Icon & Title */}
          <div className="flex items-start gap-4 mb-4">
            <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-2xl shrink-0 shadow-sm">
              {currentStep.icon}
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 leading-tight">
                {currentStep.title}
              </h3>
            </div>
          </div>

          {/* Body Description */}
          <p className="text-sm text-slate-600 leading-relaxed mb-6">
            {currentStep.description}
          </p>

          {/* Step Progress Dots */}
          <div className="flex items-center justify-center gap-2 mb-6">
            {tourSteps.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all duration-300 ${
                  idx === tourStepIndex
                    ? 'w-8 bg-indigo-600'
                    : idx < tourStepIndex
                    ? 'w-2.5 bg-indigo-300'
                    : 'w-2.5 bg-slate-200'
                }`}
              />
            ))}
          </div>

          {/* Bottom Action Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <button
              id="btn-tour-prev"
              onClick={handlePrev}
              disabled={tourStepIndex === 0}
              className={`flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                tourStepIndex === 0
                  ? 'text-slate-300 cursor-not-allowed'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              id="btn-tour-next"
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-200 transition-all cursor-pointer"
            >
              <span>{isLastStep ? 'Complete Tour' : 'Next Step'}</span>
              {isLastStep ? <CheckCircle2 className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
