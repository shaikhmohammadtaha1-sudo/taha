import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Driver, DriverStatus } from '../../types';
import {
  Smartphone,
  Radio,
  Power,
  Navigation,
  Phone,
  CheckCircle2,
  AlertCircle,
  MapPin,
  Car,
  Battery,
  Shield,
  Clock,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Play,
  RotateCcw,
  Zap,
} from 'lucide-react';

export const DriverView: React.FC = () => {
  const {
    drivers,
    selectedDriverId,
    setSelectedDriverId,
    updateDriverStatus,
    updateDriverLocation,
    inquiries,
    setCurrentView,
    setAdminTab,
    cms,
  } = useApp();

  const [isDeviceFrame, setIsDeviceFrame] = useState<boolean>(true);
  const [isSimulatingGps, setIsSimulatingGps] = useState<boolean>(true);

  const activeDriver = drivers.find((d) => d.id === selectedDriverId) || drivers[0];

  // Active Assigned Inquiries for this driver
  const assignedInquiries = inquiries.filter(
    (i) => i.assignedDriverId === activeDriver?.id || (activeDriver?.status === 'on_trip' && i.status === 'confirmed')
  );
  const activeTrip = assignedInquiries[0];

  // Simulated live location ping
  useEffect(() => {
    if (!isSimulatingGps || !activeDriver) return;

    const interval = setInterval(() => {
      const latDelta = (Math.random() - 0.5) * 0.001;
      const lngDelta = (Math.random() - 0.5) * 0.001;
      const speed = activeDriver.status === 'on_trip' ? Math.floor(45 + Math.random() * 35) : activeDriver.status === 'available' ? Math.floor(Math.random() * 10) : 0;

      updateDriverLocation(
        activeDriver.id,
        activeDriver.currentLat + latDelta,
        activeDriver.currentLng + lngDelta,
        activeDriver.currentLocationName,
        speed
      );
    }, 4000);

    return () => clearInterval(interval);
  }, [isSimulatingGps, activeDriver, updateDriverLocation]);

  if (!activeDriver) {
    return (
      <div className="p-8 text-center text-slate-500">
        No driver profiles found in system.
      </div>
    );
  }

  const driverAppContent = (
    <div className="bg-slate-900 text-white min-h-full flex flex-col font-sans">
      {/* Driver App Top Bar */}
      <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={activeDriver.photoUrl}
              alt={activeDriver.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-indigo-500"
              referrerPolicy="no-referrer"
            />
            <span
              className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-slate-950 ${
                activeDriver.status === 'available'
                  ? 'bg-emerald-500'
                  : activeDriver.status === 'on_trip'
                  ? 'bg-blue-500'
                  : activeDriver.status === 'break'
                  ? 'bg-amber-500'
                  : 'bg-slate-500'
              }`}
            />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">{activeDriver.name}</h3>
            <div className="text-[11px] text-slate-400">
              {activeDriver.assignedVehicleName} ({activeDriver.assignedVehiclePlate})
            </div>
          </div>
        </div>

        {/* GPS Live Badge & Battery */}
        <div className="flex items-center gap-2 text-xs">
          <span className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-800/60 font-semibold">
            <Radio className="w-3 h-3 animate-pulse text-emerald-400" /> GPS LIVE
          </span>
          <span className="flex items-center gap-1 text-slate-400 text-xs">
            <Battery className="w-3.5 h-3.5" /> {activeDriver.batteryPct}%
          </span>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {/* Status Mode Switcher */}
        <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700/80 space-y-2">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Chauffeur Shift Status
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => updateDriverStatus(activeDriver.id, 'available')}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeDriver.status === 'available'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900'
                  : 'bg-slate-900/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>Available (Online)</span>
            </button>

            <button
              onClick={() => updateDriverStatus(activeDriver.id, 'on_trip')}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                activeDriver.status === 'on_trip'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900'
                  : 'bg-slate-900/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>On Active Trip</span>
            </button>

            <button
              onClick={() => updateDriverStatus(activeDriver.id, 'break')}
              className={`p-2 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1 cursor-pointer ${
                activeDriver.status === 'break'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-slate-900/60 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Lunch / Break</span>
            </button>

            <button
              onClick={() => updateDriverStatus(activeDriver.id, 'offline')}
              className={`p-2 rounded-xl text-xs font-medium transition-all flex items-center justify-center gap-1 cursor-pointer ${
                activeDriver.status === 'offline'
                  ? 'bg-slate-700 text-white'
                  : 'bg-slate-900/60 text-slate-400 hover:bg-slate-700'
              }`}
            >
              <span>Offline (Off Duty)</span>
            </button>
          </div>
        </div>

        {/* Live GPS Telemetry Card */}
        <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Telemetry Broadcast</span>
            <span className="text-emerald-400 font-mono font-bold">Auto-Syncing to Admin</span>
          </div>

          <div className="grid grid-cols-3 gap-2 py-2 text-center bg-slate-950/60 rounded-xl border border-slate-800">
            <div>
              <div className="text-sm font-bold text-white font-mono">{activeDriver.speedKmph}</div>
              <div className="text-[10px] text-slate-400">Speed (KM/H)</div>
            </div>
            <div>
              <div className="text-sm font-bold text-emerald-400 font-mono">
                {activeDriver.currentLat.toFixed(3)}°
              </div>
              <div className="text-[10px] text-slate-400">Latitude</div>
            </div>
            <div>
              <div className="text-sm font-bold text-emerald-400 font-mono">
                {activeDriver.currentLng.toFixed(3)}°
              </div>
              <div className="text-[10px] text-slate-400">Longitude</div>
            </div>
          </div>

          <div className="text-[11px] text-slate-300 flex items-center gap-1.5 pt-1">
            <MapPin className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="truncate">{activeDriver.currentLocationName}</span>
          </div>
        </div>

        {/* Active Assigned Trip Card */}
        {activeTrip ? (
          <div className="bg-gradient-to-br from-indigo-900/80 to-slate-800 p-4 rounded-2xl border border-indigo-700/60 space-y-3 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/30 text-indigo-300 text-[10px] font-bold uppercase tracking-wider border border-indigo-400/30">
                Assigned Booking ({activeTrip.inquiryNumber})
              </span>
              <span className="text-xs font-extrabold text-emerald-400">
                ₹{activeTrip.totalQuote} Fare
              </span>
            </div>

            <div>
              <h4 className="text-sm font-bold text-white">{activeTrip.customerName}</h4>
              <a
                href={`tel:${activeTrip.phone}`}
                className="text-xs text-indigo-300 hover:underline flex items-center gap-1 mt-0.5"
              >
                <Phone className="w-3 h-3" /> Call Passenger: {activeTrip.phone}
              </a>
            </div>

            <div className="p-2.5 bg-slate-950/60 rounded-xl space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-medium text-slate-200">From: {activeTrip.pickupLocation}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                <span className="font-medium text-slate-200">To: {activeTrip.dropLocation}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => updateDriverStatus(activeDriver.id, 'on_trip')}
                className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md cursor-pointer"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Start Journey</span>
              </button>

              <button
                onClick={() => updateDriverStatus(activeDriver.id, 'available')}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Trip Completed</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-5 bg-slate-800/60 rounded-2xl border border-slate-700/60 text-center space-y-2">
            <Car className="w-8 h-8 text-slate-500 mx-auto" />
            <h4 className="text-xs font-bold text-slate-300">No Active Trip Assigned</h4>
            <p className="text-[11px] text-slate-400">
              Stay online in 'Available' mode to receive customer trip dispatches from the admin desk.
            </p>
          </div>
        )}

        {/* Shift Earnings Summary */}
        <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
            Today's Duty Metrics
          </span>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-950/60 rounded-xl">
              <div className="text-lg font-extrabold text-emerald-400">
                ₹{activeDriver.todayEarnings}
              </div>
              <div className="text-[11px] text-slate-400">Today's Payout</div>
            </div>
            <div className="p-3 bg-slate-950/60 rounded-xl">
              <div className="text-lg font-extrabold text-white">
                {activeDriver.todayTrips} / {activeDriver.totalCompletedTrips}
              </div>
              <div className="text-[11px] text-slate-400">Trips Done (Today / All)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Driver Footer Switcher */}
      <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>TransVoyage Driver v2.4 (APK Build)</span>
        <button
          onClick={() => {
            setCurrentView('admin');
            setAdminTab('live_map');
          }}
          className="text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer"
        >
          Open Admin View →
        </button>
      </div>
    </div>
  );

  return (
    <div id="driver-companion-app-root" className="min-h-screen bg-slate-950 p-4 sm:p-8 flex flex-col items-center justify-center">
      {/* Top Test Controls Bar */}
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-800 p-4 rounded-2xl mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-600 rounded-xl">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold">Autonomous Driver Companion Simulator</h2>
            <p className="text-xs text-slate-400">
              Installs as standalone Android APK; continuously feeds live GPS & status to Admin.
            </p>
          </div>
        </div>

        {/* Chauffeur Switcher & Mode Toggles */}
        <div className="flex items-center gap-3 flex-wrap">
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-0.5">
              Simulated Driver Profile:
            </label>
            <select
              value={activeDriver.id}
              onChange={(e) => setSelectedDriverId(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-semibold text-white border border-slate-700"
            >
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.assignedVehiclePlate})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setIsDeviceFrame(!isDeviceFrame)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 cursor-pointer"
          >
            {isDeviceFrame ? 'Full Screen Layout' : 'Smartphone Bezel'}
          </button>

          <button
            onClick={() => setCurrentView('customer')}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-bold text-white shadow-xs cursor-pointer"
          >
            Customer View
          </button>
        </div>
      </div>

      {/* Smartphone Device Frame or Full Screen */}
      {isDeviceFrame ? (
        <div className="relative w-full max-w-[390px] h-[780px] bg-black rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800 flex flex-col overflow-hidden">
          {/* Dynamic Island / Speaker notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-30 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 mr-2" />
            <div className="w-2 h-2 rounded-full bg-indigo-900" />
          </div>

          <div className="w-full h-full rounded-[38px] overflow-hidden flex flex-col pt-4">
            {driverAppContent}
          </div>
        </div>
      ) : (
        <div className="w-full max-w-xl bg-slate-900 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
          {driverAppContent}
        </div>
      )}
    </div>
  );
};
