import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  generateNetlifyRedirects,
  generateNetlifyToml,
  generateFirestoreStandaloneScript,
  generateAndroidCapacitorConfig,
  generateAndroidManifestXml,
  downloadTextFile,
} from '../../utils/exportBundler';
import {
  Rocket,
  Smartphone,
  Flame,
  Download,
  Copy,
  Check,
  ExternalLink,
  Code,
  Layers,
  Terminal,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

export const DeployAndApkTab: React.FC = () => {
  const { cms, drivers } = useApp();
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const netlifyToml = generateNetlifyToml();
  const redirects = generateNetlifyRedirects();
  const firestoreScript = generateFirestoreStandaloneScript();
  const androidManifest = generateAndroidManifestXml();
  const capacitorConfig = generateAndroidCapacitorConfig();

  const handleDownloadAllDeploymentConfigs = () => {
    downloadTextFile('netlify.toml', netlifyToml);
    setTimeout(() => downloadTextFile('_redirects', redirects), 300);
    setTimeout(() => downloadTextFile('firebase-driver-sync.js', firestoreScript), 600);
    setTimeout(() => downloadTextFile('AndroidManifest.xml', androidManifest), 900);
    setTimeout(() => downloadTextFile('capacitor.config.json', capacitorConfig), 1200);
  };

  return (
    <div id="admin-deploy-apk-tab" className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
            Netlify Drop, Firestore & Driver APK Deployment Hub
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            One-click drag-and-drop web release bundles, autonomous Firestore sync bridges, and Android Driver APK configurations.
          </p>
        </div>

        <button
          onClick={handleDownloadAllDeploymentConfigs}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-indigo-200 transition-all cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Download All Deployment Bundles</span>
        </button>
      </div>

      {/* Grid: 3 Pillars (Netlify, Driver APK, Firestore) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 1. Netlify Drop Box */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2.5 bg-cyan-50 text-cyan-600 rounded-xl">
                <Rocket className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">1. Netlify Drag & Drop</h3>
                <span className="text-[11px] text-emerald-600 font-bold">Single-Click Web Host</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              To publish on Netlify without setting up build pipelines:
            </p>

            <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
              <li>Run <code className="font-mono bg-white px-1.5 py-0.5 rounded border">npm run build</code> to produce the <code className="font-mono font-bold text-indigo-600">dist/</code> folder.</li>
              <li>Include <code className="font-mono font-bold text-slate-800">_redirects</code> for SPA routing.</li>
              <li>Visit <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-indigo-600 font-bold underline inline-flex items-center gap-0.5">app.netlify.com/drop <ExternalLink className="w-3 h-3" /></a> and drop the folder!</li>
            </ol>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-700">netlify.toml</span>
              <button
                onClick={() => handleCopy(netlifyToml, 'netlify_toml')}
                className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'netlify_toml' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copiedSection === 'netlify_toml' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-2.5 bg-slate-900 text-slate-300 rounded-xl text-[11px] font-mono overflow-x-auto">
              {netlifyToml}
            </pre>
          </div>
        </div>

        {/* 2. Autonomous Driver APK */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">2. Driver Android APK</h3>
                <span className="text-[11px] text-indigo-600 font-bold">Auto-Connecting Chauffeur App</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Driver app packaged for Android APK with automatic background GPS broadcasting:
            </p>

            <div className="space-y-2 text-xs text-slate-600 bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
              <div className="flex items-center gap-2 text-slate-800 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Background High Precision GPS</span>
              </div>
              <div className="flex items-center gap-2 text-slate-800 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Zero-Login Chauffeur Identifier</span>
              </div>
              <div className="flex items-center gap-2 text-slate-800 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Live Battery & Speed Telemetry</span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-700">AndroidManifest.xml (GPS Permissions)</span>
              <button
                onClick={() => handleCopy(androidManifest, 'manifest')}
                className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'manifest' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copiedSection === 'manifest' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-2.5 bg-slate-900 text-slate-300 rounded-xl text-[10px] font-mono overflow-x-auto max-h-24">
              {androidManifest.slice(0, 300)}...
            </pre>
          </div>
        </div>

        {/* 3. Firestore Autonomous Data Bridge */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">3. Firestore Real-Time Bridge</h3>
                <span className="text-[11px] text-amber-600 font-bold">Cloud Data Sync</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Bi-directional schema synchronizing driver locations and booking inquiries:
            </p>

            <div className="text-xs font-mono bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1 text-slate-700">
              <div>📁 /drivers/{'{driverId}'} ➔ GPS, status, battery</div>
              <div>📁 /inquiries/{'{inquiryId}'} ➔ Bookings, follow-up</div>
              <div>📁 /trips/{'{tripId}'} ➔ Revenue, fuel, profit</div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-700">Standalone Sync Agent</span>
              <button
                onClick={() => handleCopy(firestoreScript, 'firestore_code')}
                className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
              >
                {copiedSection === 'firestore_code' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copiedSection === 'firestore_code' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-2.5 bg-slate-900 text-slate-300 rounded-xl text-[10px] font-mono overflow-x-auto max-h-24">
              {firestoreScript.slice(0, 320)}...
            </pre>
          </div>
        </div>
      </div>

      {/* Build & Run Terminal Commands Reference */}
      <div className="bg-slate-900 text-slate-300 p-6 rounded-3xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-bold text-sm font-mono">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>Terminal Commands to Build Standalone APK & Netlify Bundle</span>
          </div>
          <span className="text-xs text-slate-400">Node.js 18+ / Android SDK</span>
        </div>

        <pre className="p-4 bg-slate-950 rounded-2xl text-xs font-mono text-emerald-400 overflow-x-auto space-y-1">
          <div># 1. Build React Web Production Distribution for Netlify Drop:</div>
          <div className="text-white">npm run build</div>
          <div className="text-slate-500"># Result: dist/ folder ready to drop into https://app.netlify.com/drop</div>
          <div className="pt-2"># 2. Package Android APK using Capacitor:</div>
          <div className="text-white">npx cap init "{cms.brandName}" "com.transvoyage.driverapp" --web-dir dist</div>
          <div className="text-white">npx cap add android</div>
          <div className="text-white">npx cap copy android</div>
          <div className="text-white">npx cap open android # Builds standalone .apk in Android Studio</div>
        </pre>
      </div>
    </div>
  );
};
