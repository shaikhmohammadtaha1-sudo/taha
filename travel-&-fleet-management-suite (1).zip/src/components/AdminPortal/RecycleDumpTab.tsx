import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DeletedInquiry, DeletedTripFinancialRecord } from '../../types';
import {
  Trash2,
  RotateCcw,
  AlertTriangle,
  Search,
  Calendar,
  Clock,
  Car,
  MapPin,
  Phone,
  User,
  ShieldAlert,
  CheckCircle2,
  X,
  FileSpreadsheet,
  TrendingUp,
  DollarSign,
  Layers,
  Archive,
} from 'lucide-react';

export const RecycleDumpTab: React.FC = () => {
  const {
    deletedInquiries,
    deletedTrips,
    restoreInquiryFromDump,
    permanentlyPurgeInquiry,
    restoreTripFromDump,
    permanentlyPurgeTrip,
    clearAllDump,
    cms,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'inquiries' | 'financials'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInquiryToPurge, setSelectedInquiryToPurge] = useState<DeletedInquiry | null>(null);
  const [selectedTripToPurge, setSelectedTripToPurge] = useState<DeletedTripFinancialRecord | null>(null);
  const [showClearAllConfirm, setShowClearAllConfirm] = useState(false);

  const filteredInquiries = deletedInquiries.filter((item) => {
    const query = searchTerm.toLowerCase();
    return (
      item.customerName.toLowerCase().includes(query) ||
      item.inquiryNumber.toLowerCase().includes(query) ||
      item.phone.includes(query) ||
      item.pickupLocation.toLowerCase().includes(query) ||
      item.dropLocation.toLowerCase().includes(query) ||
      item.vehicleName.toLowerCase().includes(query)
    );
  });

  const filteredTrips = deletedTrips.filter((trip) => {
    const query = searchTerm.toLowerCase();
    return (
      trip.tripNumber.toLowerCase().includes(query) ||
      trip.customerName.toLowerCase().includes(query) ||
      trip.vehiclePlate.toLowerCase().includes(query) ||
      trip.driverName.toLowerCase().includes(query) ||
      trip.pickupLocation.toLowerCase().includes(query) ||
      trip.dropLocation.toLowerCase().includes(query)
    );
  });

  const totalArchivedCount = deletedInquiries.length + deletedTrips.length;

  return (
    <div id="admin-recycle-dump-tab" className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
              Deleted Dump & Recycle Archive
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700 border border-rose-200">
              {totalArchivedCount} Archived Records
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Safely preserved database dump for inquiries and financial ledger entries. Admins can double-check, restore, or permanently purge records.
          </p>
        </div>

        {totalArchivedCount > 0 && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowClearAllConfirm(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-rose-200 transition-all cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Empty All Dump ({totalArchivedCount})</span>
            </button>
          </div>
        )}
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setActiveFilter('all')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>All Dump ({totalArchivedCount})</span>
          </button>

          <button
            onClick={() => setActiveFilter('inquiries')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'inquiries'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Inquiries ({deletedInquiries.length})</span>
          </button>

          <button
            onClick={() => setActiveFilter('financials')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'financials'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Financial Trips ({deletedTrips.length})</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search deleted records by number, customer, plate, route..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
          />
        </div>
      </div>

      {/* Empty State */}
      {((activeFilter === 'all' && filteredInquiries.length === 0 && filteredTrips.length === 0) ||
        (activeFilter === 'inquiries' && filteredInquiries.length === 0) ||
        (activeFilter === 'financials' && filteredTrips.length === 0)) && (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center mb-3">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-800">Recycle Dump is Empty</h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mt-1">
            {searchTerm
              ? 'No deleted records matched your search query.'
              : 'All records are clean in the active ledger and CRM pipelines. Whenever items are deleted with confirmation, they are preserved safely here.'}
          </p>
        </div>
      )}

      {/* SECTION 1: Deleted Financial Records */}
      {(activeFilter === 'all' || activeFilter === 'financials') && filteredTrips.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Deleted Financial Trip Records ({filteredTrips.length})
            </h3>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredTrips.map((trip) => (
              <div
                key={trip.id}
                className="bg-white rounded-2xl border border-emerald-100 p-5 shadow-xs hover:border-emerald-200 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                {/* Left Details */}
                <div className="space-y-3 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-lg bg-emerald-950 text-emerald-200 font-mono text-xs font-bold">
                      {trip.tripNumber}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold flex items-center gap-1">
                      <Trash2 className="w-3 h-3 text-rose-500" />
                      Deleted on: {trip.deletedAt}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium">
                      By: {trip.deletedBy}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-amber-50 text-amber-800 text-xs font-medium">
                      Reason: {trip.deleteReason || 'Administrator Action'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    {/* Customer Info */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{trip.customerName}</span>
                      </div>
                      <div className="text-slate-500">Date: {trip.date}</div>
                    </div>

                    {/* Route */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="text-slate-900 font-semibold flex items-center gap-1 truncate">
                        <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                        <span className="truncate">{trip.pickupLocation} ➔ {trip.dropLocation}</span>
                      </div>
                      <div className="text-slate-500">{trip.distanceKm} KM total run</div>
                    </div>

                    {/* Vehicle & Driver */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="text-slate-900 font-semibold flex items-center gap-1.5">
                        <Car className="w-3.5 h-3.5 text-slate-600" />
                        <span>{trip.vehiclePlate}</span>
                      </div>
                      <div className="text-slate-500">Driver: {trip.driverName}</div>
                    </div>

                    {/* Financial Figures */}
                    <div className="space-y-1 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Revenue:</span>
                        <span className="font-bold text-slate-800">₹{trip.revenue.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Net Profit:</span>
                        <span className="font-extrabold text-emerald-700">₹{trip.netProfit.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Action Buttons */}
                <div className="flex items-center gap-2.5 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100 shrink-0">
                  <button
                    onClick={() => restoreTripFromDump(trip.id)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs border border-emerald-200 transition-colors cursor-pointer"
                    title="Restore back to Active Financials Ledger"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Restore to Ledger</span>
                  </button>

                  <button
                    onClick={() => setSelectedTripToPurge(trip)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 transition-colors cursor-pointer"
                    title="Permanently remove financial trip from database"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>Purge</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 2: Deleted Inquiries */}
      {(activeFilter === 'all' || activeFilter === 'inquiries') && filteredInquiries.length > 0 && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Deleted CRM Inquiries ({filteredInquiries.length})
            </h3>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredInquiries.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                {/* Left Details */}
                <div className="space-y-3 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-900 text-white font-mono text-xs font-bold">
                      {item.inquiryNumber}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold flex items-center gap-1">
                      <Trash2 className="w-3 h-3 text-rose-500" />
                      Deleted on: {item.deletedAt}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium">
                      By: {item.deletedBy}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-amber-50 text-amber-800 text-xs font-medium">
                      Reason: {item.deleteReason || 'Administrator Action'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                    {/* Customer Info */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{item.customerName}</span>
                      </div>
                      <div className="text-slate-600 flex items-center gap-1.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{item.phone}</span>
                      </div>
                    </div>

                    {/* Route & Trip */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="text-slate-900 font-semibold flex items-center gap-1 truncate">
                        <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                        <span className="truncate">{item.pickupLocation} → {item.dropLocation}</span>
                      </div>
                      <div className="text-slate-500 flex items-center gap-2">
                        <span>{item.estimatedDistanceKm} km</span>
                        <span>•</span>
                        <span className="capitalize">{item.tripType.replace('_', ' ')}</span>
                      </div>
                    </div>

                    {/* Vehicle & Price */}
                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div className="text-slate-900 font-semibold flex items-center gap-1.5">
                        <Car className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{item.vehicleName}</span>
                      </div>
                      <div className="text-indigo-700 font-bold">
                        Original Quote: {cms.currencySymbol}{item.totalQuote?.toLocaleString('en-IN') || '0'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Action Buttons */}
                <div className="flex items-center gap-2.5 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100 shrink-0">
                  <button
                    onClick={() => restoreInquiryFromDump(item.id)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs border border-indigo-200 transition-colors cursor-pointer"
                    title="Restore back to Active CRM"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Restore to CRM</span>
                  </button>

                  <button
                    onClick={() => setSelectedInquiryToPurge(item)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 transition-colors cursor-pointer"
                    title="Permanently remove inquiry from database"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>Purge</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Confirmation Modal for Single Inquiry Purge */}
      {selectedInquiryToPurge && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Permanently Delete Inquiry?
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Are you sure you want to permanently delete inquiry <strong className="text-slate-800">{selectedInquiryToPurge.inquiryNumber}</strong> ({selectedInquiryToPurge.customerName})? This action cannot be undone.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setSelectedInquiryToPurge(null)}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  permanentlyPurgeInquiry(selectedInquiryToPurge.id);
                  setSelectedInquiryToPurge(null);
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Yes, Purge Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Single Financial Trip Purge */}
      {selectedTripToPurge && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Permanently Purge Financial Trip?
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Are you sure you want to permanently purge trip <strong className="text-slate-800">{selectedTripToPurge.tripNumber}</strong> ({selectedTripToPurge.customerName} - Net Profit ₹{selectedTripToPurge.netProfit}) from the database? This action is irreversible.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setSelectedTripToPurge(null)}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  permanentlyPurgeTrip(selectedTripToPurge.id);
                  setSelectedTripToPurge(null);
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Yes, Purge Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clear All Dump */}
      {showClearAllConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Empty Entire Recycle Dump?
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                This will permanently purge all <strong className="text-slate-800">{deletedInquiries.length}</strong> inquiries and <strong className="text-slate-800">{deletedTrips.length}</strong> financial records from the database dump.
              </p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowClearAllConfirm(false)}
                className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearAllDump();
                  setShowClearAllConfirm(false);
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Yes, Empty All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
