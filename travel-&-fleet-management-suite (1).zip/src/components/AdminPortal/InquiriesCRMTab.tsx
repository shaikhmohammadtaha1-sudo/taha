import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Inquiry, InquiryStatus, NotInterestedReason } from '../../types';
import { exportInquiriesExcel } from '../../utils/excelHelper';
import {
  Search,
  Filter,
  Calendar,
  Clock,
  User,
  Phone,
  Car,
  MapPin,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Tag,
  ChevronRight,
  MoreVertical,
  X,
  MessageSquare,
  AlertCircle,
  Calculator,
  Coins,
  Trash2,
  Send,
  Copy,
  Check,
  Percent,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';

export const InquiriesCRMTab: React.FC = () => {
  const {
    inquiries,
    updateInquiryStatus,
    updateInquiryAdminQuote,
    deleteInquiry,
    drivers,
    vehicles,
    cms,
    showToast,
  } = useApp();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Status Modal State
  const [selectedInquiryForAction, setSelectedInquiryForAction] = useState<Inquiry | null>(null);
  const [modalStatus, setModalStatus] = useState<InquiryStatus>('followup');
  const [followupDate, setFollowupDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [followupTime, setFollowupTime] = useState<string>('11:00');
  const [notInterestedReason, setNotInterestedReason] = useState<NotInterestedReason>('price_high');
  const [notInterestedNotes, setNotInterestedNotes] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [assignedDriverId, setAssignedDriverId] = useState<string>('');
  const [assignedVehicleId, setAssignedVehicleId] = useState<string>('');

  // Quote & Toll Adjustment Modal State
  const [selectedInquiryForQuote, setSelectedInquiryForQuote] = useState<Inquiry | null>(null);
  const [customDistanceKm, setCustomDistanceKm] = useState<number>(0);
  const [customRatePerKm, setCustomRatePerKm] = useState<number>(0);
  const [customTollFare, setCustomTollFare] = useState<number>(0);
  const [customDriverAllowance, setCustomDriverAllowance] = useState<number>(0);
  const [customNightCharges, setCustomNightCharges] = useState<number>(0);
  const [customDiscount, setCustomDiscount] = useState<number>(0);
  const [customSurcharge, setCustomSurcharge] = useState<number>(0);
  const [customNotes, setCustomNotes] = useState<string>('');
  const [copiedQuoteText, setCopiedQuoteText] = useState(false);

  // Delete Confirmation Modal State
  const [inquiryToDelete, setInquiryToDelete] = useState<Inquiry | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('Customer cancelled or duplicate entry');

  // Filtered & Searched Inquiries
  const filteredInquiries = useMemo(() => {
    return inquiries.filter((inq) => {
      const matchesStatus = filterStatus === 'all' || inq.status === filterStatus;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        inq.customerName.toLowerCase().includes(q) ||
        inq.phone.includes(q) ||
        inq.inquiryNumber.toLowerCase().includes(q) ||
        inq.pickupLocation.toLowerCase().includes(q) ||
        inq.dropLocation.toLowerCase().includes(q) ||
        inq.vehicleName.toLowerCase().includes(q);

      return matchesStatus && matchesSearch;
    });
  }, [inquiries, filterStatus, searchQuery]);

  const handleOpenActionModal = (inq: Inquiry) => {
    setSelectedInquiryForAction(inq);
    setModalStatus(inq.status);
    setFollowupDate(inq.followupDate || new Date().toISOString().slice(0, 10));
    setFollowupTime(inq.followupTime || '11:00');
    setNotInterestedReason(inq.notInterestedReason || 'price_high');
    setNotInterestedNotes(inq.notInterestedNotes || '');
    setNotes(inq.notes || '');
    setAssignedDriverId(inq.assignedDriverId || (drivers[0]?.id || ''));
    setAssignedVehicleId(inq.assignedVehicleId || (inq.vehicleId || vehicles[0]?.id || ''));
  };

  const handleSaveStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInquiryForAction) return;

    updateInquiryStatus(selectedInquiryForAction.id, modalStatus, {
      followupDate: modalStatus === 'followup' ? followupDate : undefined,
      followupTime: modalStatus === 'followup' ? followupTime : undefined,
      notInterestedReason: modalStatus === 'not_interested' ? notInterestedReason : undefined,
      notInterestedNotes: modalStatus === 'not_interested' ? notInterestedNotes : undefined,
      notes,
      assignedDriverId: modalStatus === 'confirmed' ? assignedDriverId : undefined,
      assignedVehicleId: modalStatus === 'confirmed' ? assignedVehicleId : undefined,
    });

    setSelectedInquiryForAction(null);
  };

  // Open Quote & Toll Adjustment Modal
  const handleOpenQuoteModal = (inq: Inquiry) => {
    setSelectedInquiryForQuote(inq);
    setCustomDistanceKm(inq.estimatedDistanceKm || 50);
    const v = vehicles.find((veh) => veh.id === inq.vehicleId) || vehicles[0];
    const initialRate = inq.adminCustomPerKmRate || v?.outstationPerKmRate || v?.ratePerKm || 14;
    setCustomRatePerKm(initialRate);
    setCustomTollFare(inq.adminCustomTollFare !== undefined ? inq.adminCustomTollFare : inq.estimatedTolls || 0);
    setCustomDriverAllowance(inq.driverAllowance !== undefined ? inq.driverAllowance : (v?.driverAllowancePerDay || 350));
    setCustomNightCharges(inq.nightCharges || 0);
    setCustomDiscount(inq.adminCustomDiscount || 0);
    setCustomSurcharge(inq.adminCustomSurcharge || 0);
    setCustomNotes(inq.notes || '');
    setCopiedQuoteText(false);
  };

  // Calculate live revised total in modal
  const calculatedDistanceCharge = Math.round(customDistanceKm * customRatePerKm);
  const calculatedSubtotal =
    calculatedDistanceCharge +
    customTollFare +
    customDriverAllowance +
    customNightCharges +
    customSurcharge -
    customDiscount;
  const calculatedTax = Math.round((calculatedSubtotal * (cms.defaultTaxPct || 5)) / 100);
  const calculatedFinalQuote = Math.max(0, calculatedSubtotal + calculatedTax);

  const handleSaveAndApproveQuote = (sendQuoteDirectly: boolean) => {
    if (!selectedInquiryForQuote) return;

    updateInquiryAdminQuote(selectedInquiryForQuote.id, {
      totalQuote: calculatedFinalQuote,
      adminCustomTollFare: customTollFare,
      adminCustomDiscount: customDiscount,
      adminCustomSurcharge: customSurcharge,
      adminCustomPerKmRate: customRatePerKm,
      isQuoteApprovedByAdmin: true,
      status: sendQuoteDirectly ? 'quote_sent' : selectedInquiryForQuote.status,
      notes: customNotes,
    });

    setSelectedInquiryForQuote(null);
  };

  const handleCopyQuoteMessage = () => {
    if (!selectedInquiryForQuote) return;
    const msg = `*${cms.brandName} - Official Booking Quote*\n` +
      `Trip ID: ${selectedInquiryForQuote.inquiryNumber}\n` +
      `Passenger: ${selectedInquiryForQuote.customerName}\n` +
      `Route: ${selectedInquiryForQuote.pickupLocation} ➔ ${selectedInquiryForQuote.dropLocation}\n` +
      `Vehicle: ${selectedInquiryForQuote.vehicleName}\n` +
      `Date & Time: ${selectedInquiryForQuote.pickupDate} at ${selectedInquiryForQuote.pickupTime}\n` +
      `Estimated Distance: ${customDistanceKm} KM (@ ₹${customRatePerKm}/km)\n` +
      `--------------------------------\n` +
      `Base Distance Fare: ₹${calculatedDistanceCharge}\n` +
      `Highway Tolls / Fastag: ₹${customTollFare}\n` +
      `Driver Allowance (Batta): ₹${customDriverAllowance}\n` +
      (customNightCharges > 0 ? `Night Charges: ₹${customNightCharges}\n` : '') +
      (customDiscount > 0 ? `Discount Applied: -₹${customDiscount}\n` : '') +
      `GST & Service Taxes (${cms.defaultTaxPct}%): ₹${calculatedTax}\n` +
      `--------------------------------\n` +
      `*Total Verified Fare: ₹${calculatedFinalQuote.toLocaleString('en-IN')}*\n\n` +
      `For inquiries or live GPS confirmation, call/WhatsApp us at ${cms.phone}.`;

    navigator.clipboard.writeText(msg);
    setCopiedQuoteText(true);
    showToast('📋 Customer Quote breakdown copied to clipboard!');
    setTimeout(() => setCopiedQuoteText(false), 3000);
  };

  const handleDeleteToDump = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryToDelete) return;
    deleteInquiry(inquiryToDelete.id, deleteReason);
    setInquiryToDelete(null);
  };

  const getStatusBadge = (inq: Inquiry) => {
    switch (inq.status) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" /> New Lead
          </span>
        );
      case 'quote_sent':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <Send className="w-3 h-3 text-indigo-600" /> Quote Sent
          </span>
        );
      case 'followup':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-500" />
            Follow-up: {inq.followupDate} {inq.followupTime || ''}
          </span>
        );
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Confirmed Ride
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200">
            <CheckCircle2 className="w-3 h-3 text-purple-500" /> Completed
          </span>
        );
      case 'not_interested':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-500" /> Not Interested
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
            {inq.status}
          </span>
        );
    }
  };

  return (
    <div id="admin-crm-inquiries-tab" className="space-y-6">
      {/* Header & Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
              Inquiries & Quote Management CRM
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
              {inquiries.length} Active Leads
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Review customer bookings, customize highway tolls & per-km pricing, approve quotes, and dispatch to chauffeurs.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => exportInquiriesExcel(inquiries)}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-200 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Inquiries (Excel)</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Box */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer, phone, route, inquiry no..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'All Leads' },
            { id: 'new', label: 'New' },
            { id: 'quote_sent', label: 'Quote Sent' },
            { id: 'followup', label: 'Needs Follow-up' },
            { id: 'confirmed', label: 'Confirmed' },
            { id: 'completed', label: 'Completed' },
            { id: 'not_interested', label: 'Not Interested' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                filterStatus === tab.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Inquiries Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[11px] font-bold border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Inquiry / Date</th>
                <th className="px-6 py-4">Customer & Contact</th>
                <th className="px-6 py-4">Route & Trip Details</th>
                <th className="px-6 py-4">Vehicle & Quote Breakdown</th>
                <th className="px-6 py-4">Status & Dispatch</th>
                <th className="px-6 py-4 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInquiries.length > 0 ? (
                filteredInquiries.map((inq) => (
                  <tr key={inq.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Inquiry ID & Time */}
                    <td className="px-6 py-4">
                      <span className="font-mono font-bold text-indigo-600 block">
                        {inq.inquiryNumber}
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {inq.createdAt}
                      </span>
                      {inq.isQuoteApprovedByAdmin && (
                        <span className="inline-flex items-center gap-1 mt-1 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                          <Check className="w-2.5 h-2.5" /> Quote Verified
                        </span>
                      )}
                    </td>

                    {/* Customer */}
                    <td className="px-6 py-4">
                      <span className="font-bold text-slate-900 block">
                        {inq.customerName}
                      </span>
                      <a
                        href={`tel:${inq.phone}`}
                        className="text-xs text-indigo-600 hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <Phone className="w-3 h-3" /> {inq.phone}
                      </a>
                      <a
                        href={`https://wa.me/${inq.phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-emerald-600 hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <MessageSquare className="w-3 h-3" /> WhatsApp
                      </a>
                    </td>

                    {/* Route */}
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-800 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                        <span className="truncate max-w-[200px]">{inq.pickupLocation} ➔ {inq.dropLocation}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 flex gap-2">
                        <span className="capitalize">{inq.tripType.replace('_', ' ')}</span>
                        <span>•</span>
                        <span>{inq.estimatedDistanceKm} KM</span>
                        <span>•</span>
                        <span>{inq.pickupDate} ({inq.pickupTime})</span>
                      </div>
                    </td>

                    {/* Vehicle & Pricing Breakdown */}
                    <td className="px-6 py-4">
                      <span className="font-semibold text-slate-800 block">
                        {inq.vehicleName}
                      </span>
                      <div className="mt-1 flex items-baseline gap-2">
                        <span className="text-base font-extrabold text-indigo-700 font-['Outfit',sans-serif]">
                          ₹{inq.totalQuote.toLocaleString('en-IN')}
                        </span>
                        {inq.adminCustomTollFare !== undefined && (
                          <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                            Tolls: ₹{inq.adminCustomTollFare}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 block">
                        Base: ₹{inq.calculatedBaseFare} + Batta: ₹{inq.driverAllowance}
                      </span>
                    </td>

                    {/* Status & Details */}
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <div>{getStatusBadge(inq)}</div>

                        {inq.status === 'not_interested' && inq.notInterestedReason && (
                          <div className="text-[11px] text-rose-600 font-medium">
                            Reason: <b>{inq.notInterestedReason.replace('_', ' ').toUpperCase()}</b>
                            {inq.notInterestedNotes && (
                              <span className="text-slate-500 block text-[10px] truncate max-w-[180px]">
                                "{inq.notInterestedNotes}"
                              </span>
                            )}
                          </div>
                        )}

                        {inq.status === 'confirmed' && inq.assignedDriverId && (
                          <div className="text-[11px] text-emerald-700 font-medium">
                            Chauffeur: {drivers.find((d) => d.id === inq.assignedDriverId)?.name || 'Assigned'}
                          </div>
                        )}

                        {inq.notes && (
                          <div className="text-[11px] text-slate-500 truncate max-w-[180px]">
                            📝 {inq.notes}
                          </div>
                        )}
                      </div>
                    </td>

                    {/* Action buttons */}
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Quote & Tolls button */}
                        <button
                          onClick={() => handleOpenQuoteModal(inq)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs transition-colors cursor-pointer"
                          title="Review & Adjust Quote, Tolls & Pricing"
                        >
                          <Calculator className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Quote / Tolls</span>
                        </button>

                        {/* Status / Tag button */}
                        <button
                          onClick={() => handleOpenActionModal(inq)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
                          title="Update Status / Assign Chauffeur"
                        >
                          <Tag className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Status</span>
                        </button>

                        {/* Delete to Dump button */}
                        <button
                          onClick={() => setInquiryToDelete(inq)}
                          className="inline-flex items-center p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Move to Recycle Dump"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    No inquiries found matching current filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quote & Custom Toll Adjustment Modal */}
      {selectedInquiryForQuote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-5 bg-slate-900 text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 rounded-xl text-white">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold">
                    Admin Fare & Highway Toll Quote Editor
                  </h3>
                  <p className="text-xs text-slate-400">
                    {selectedInquiryForQuote.inquiryNumber} • {selectedInquiryForQuote.customerName} ({selectedInquiryForQuote.vehicleName})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedInquiryForQuote(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Form Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-xs sm:text-sm">
              {/* Route Summary Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-bold text-slate-900">{selectedInquiryForQuote.pickupLocation}</span>
                  <span className="text-slate-400">➔</span>
                  <span className="font-bold text-slate-900">{selectedInquiryForQuote.dropLocation}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{selectedInquiryForQuote.pickupDate} at {selectedInquiryForQuote.pickupTime}</span>
                </div>
              </div>

              {/* Price Calculation Fields Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Distance KM */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Total Estimated Distance (KM)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={customDistanceKm}
                    onChange={(e) => setCustomDistanceKm(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Per KM Rate */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Rate per KM (₹)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="0.5"
                    value={customRatePerKm}
                    onChange={(e) => setCustomRatePerKm(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Custom Toll Fare (Key Feature) */}
                <div className="bg-amber-50/70 p-3 rounded-2xl border border-amber-200">
                  <label className="block text-xs font-bold text-amber-900 mb-1 flex items-center justify-between">
                    <span>Highway Tolls / Fastag (₹)</span>
                    <span className="text-[10px] text-amber-700 font-normal">Customizable</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={customTollFare}
                    onChange={(e) => setCustomTollFare(Number(e.target.value))}
                    placeholder="Enter highway toll amount..."
                    className="w-full p-2.5 bg-white border border-amber-300 rounded-xl text-slate-900 font-bold focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>

                {/* Driver Allowance (Batta) */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Driver Allowance / Day (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={customDriverAllowance}
                    onChange={(e) => setCustomDriverAllowance(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Discount */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Special Discount (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={customDiscount}
                    onChange={(e) => setCustomDiscount(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                {/* Night / Permit Surcharges */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    State Permit / Parking / Surcharges (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={customSurcharge}
                    onChange={(e) => setCustomSurcharge(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Admin Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Dispatch Notes & Route Instructions
                </label>
                <textarea
                  rows={2}
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder="e.g., Include Fastag lane charges, placard at arrival gate..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {/* Real-Time Live Quote Breakdown Box */}
              <div className="p-4 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl space-y-2.5 shadow-lg">
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center justify-between">
                  <span>Calculated Fare Breakdown</span>
                  <span className="text-[10px] text-slate-400">Distance × Rate + Tolls + Batta + Tax</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1 border-t border-slate-800">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Distance Fare</span>
                    <span className="font-bold text-white">₹{calculatedDistanceCharge}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Highway Tolls</span>
                    <span className="font-bold text-amber-300">₹{customTollFare}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Driver Batta</span>
                    <span className="font-bold text-white">₹{customDriverAllowance}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Taxes ({cms.defaultTaxPct}%)</span>
                    <span className="font-bold text-white">₹{calculatedTax}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-200">Total Customer Quote:</span>
                  <span className="text-2xl font-black text-emerald-400 font-['Outfit',sans-serif]">
                    ₹{calculatedFinalQuote.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
              <button
                type="button"
                onClick={handleCopyQuoteMessage}
                className="flex items-center gap-1.5 px-3.5 py-2.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold border border-slate-300 shadow-xs transition-colors cursor-pointer"
              >
                {copiedQuoteText ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-indigo-600" />}
                <span>{copiedQuoteText ? 'Quote Copied!' : 'Copy WhatsApp Quote'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedInquiryForQuote(null)}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveAndApproveQuote(false)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Save Quote Only
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveAndApproveQuote(true)}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Approve & Set "Quote Sent"</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Inquiry Update & Tagging Modal (Follow-up & Sub-disposition Reason) */}
      {selectedInquiryForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="flex items-center justify-between p-5 bg-slate-900 text-white">
              <div>
                <h3 className="text-base font-bold">
                  Update Lead Status: {selectedInquiryForAction.inquiryNumber}
                </h3>
                <p className="text-xs text-slate-400">
                  {selectedInquiryForAction.customerName} • {selectedInquiryForAction.pickupLocation} ➔ {selectedInquiryForAction.dropLocation}
                </p>
              </div>
              <button
                onClick={() => setSelectedInquiryForAction(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStatus} className="p-6 space-y-4 text-xs sm:text-sm">
              {/* Disposition Status Picker */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  Select Lead Status
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['new', 'quote_sent', 'followup', 'confirmed', 'completed', 'not_interested'] as InquiryStatus[]).map((st) => (
                    <button
                      type="button"
                      key={st}
                      onClick={() => setModalStatus(st)}
                      className={`p-2.5 rounded-xl text-xs font-bold capitalize transition-all border cursor-pointer ${
                        modalStatus === st
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {st.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Conditional 1: Follow-Up Date & Time */}
              {modalStatus === 'followup' && (
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span>Schedule Callback / Follow-Up</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Follow-up Date
                      </label>
                      <input
                        type="date"
                        required
                        value={followupDate}
                        onChange={(e) => setFollowupDate(e.target.value)}
                        className="w-full p-2 bg-white border border-amber-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Follow-up Time
                      </label>
                      <input
                        type="time"
                        value={followupTime}
                        onChange={(e) => setFollowupTime(e.target.value)}
                        className="w-full p-2 bg-white border border-amber-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Conditional 2: Not Interested Sub-Reason */}
              {modalStatus === 'not_interested' && (
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 space-y-3 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-rose-800">
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                    <span>Lost Business Reason</span>
                  </div>
                  <div>
                    <select
                      value={notInterestedReason}
                      onChange={(e) => setNotInterestedReason(e.target.value as NotInterestedReason)}
                      className="w-full p-2.5 bg-white border border-rose-300 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    >
                      <option value="price_high">Price High / Budget Constraint</option>
                      <option value="booked_competitor">Booked Competitor</option>
                      <option value="trip_cancelled">Trip Cancelled by Client</option>
                      <option value="vehicle_unavailable">Requested Vehicle Unavailable</option>
                      <option value="route_unserviceable">Route Unserviceable</option>
                      <option value="timing_mismatch">Timing / Date Mismatch</option>
                      <option value="other">Other Reason</option>
                    </select>
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Optional notes on why deal was lost..."
                      value={notInterestedNotes}
                      onChange={(e) => setNotInterestedNotes(e.target.value)}
                      className="w-full p-2 bg-white border border-rose-200 rounded-xl text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Conditional 3: Confirmed - Assign Driver & Vehicle */}
              {modalStatus === 'confirmed' && (
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3 animate-in fade-in">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Assign Fleet Vehicle & Chauffeur</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Select Chauffeur
                      </label>
                      <select
                        value={assignedDriverId}
                        onChange={(e) => setAssignedDriverId(e.target.value)}
                        className="w-full p-2 bg-white border border-emerald-300 rounded-xl text-xs font-medium"
                      >
                        {drivers.map((drv) => (
                          <option key={drv.id} value={drv.id}>
                            {drv.name} ({drv.status})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Fleet Vehicle
                      </label>
                      <select
                        value={assignedVehicleId}
                        onChange={(e) => setAssignedVehicleId(e.target.value)}
                        className="w-full p-2 bg-white border border-emerald-300 rounded-xl text-xs font-medium"
                      >
                        {vehicles.map((veh) => (
                          <option key={veh.id} value={veh.id}>
                            {veh.name} ({veh.plateNumber})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* General Admin Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Internal Remarks
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notes visible only to admin dispatch team..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedInquiryForAction(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-md shadow-indigo-200 transition-all cursor-pointer"
                >
                  Save Lead Updates
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (Moves to Dump) */}
      {inquiryToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Move Inquiry to Recycle Dump?
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Inquiry <strong className="text-slate-800">{inquiryToDelete.inquiryNumber}</strong> ({inquiryToDelete.customerName}) will be moved to the Dump Archive. You can restore it anytime from the Dump tab.
              </p>
            </div>

            <form onSubmit={handleDeleteToDump} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Reason for Deletion
                </label>
                <input
                  type="text"
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  placeholder="e.g. Cancelled by customer / Duplicate inquiry"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setInquiryToDelete(null)}
                  className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs sm:text-sm font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  Move to Dump
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
