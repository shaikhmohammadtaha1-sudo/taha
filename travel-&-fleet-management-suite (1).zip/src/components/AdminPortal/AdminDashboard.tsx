import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminTabType } from '../../types';
import { AnalyticsTab } from './AnalyticsTab';
import { InquiriesCRMTab } from './InquiriesCRMTab';
import { RecycleDumpTab } from './RecycleDumpTab';
import { LiveDriverMapTab } from './LiveDriverMapTab';
import { FleetMaintenanceTab } from './FleetMaintenanceTab';
import { FinancialsExcelTab } from './FinancialsExcelTab';
import { WebsiteCMSTab } from './WebsiteCMSTab';
import { DeployAndApkTab } from './DeployAndApkTab';
import { AdminLoginView } from './AdminLoginView';
import {
  BarChart3,
  Users,
  MapPin,
  Car,
  FileSpreadsheet,
  Settings,
  Rocket,
  ShieldCheck,
  Smartphone,
  Eye,
  AlertTriangle,
  Clock,
  Radio,
  Trash2,
  Lock,
  LogOut,
  HelpCircle,
  Key,
  X,
  CheckCircle2,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    adminTab,
    setAdminTab,
    inquiries,
    deletedInquiries,
    vehicles,
    isGpsTrackingActive,
    setCurrentView,
    cms,
    isAdminLoggedIn,
    logoutAdmin,
    changeAdminPassword,
    startTour,
  } = useApp();

  // Change Password Modal state
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmPassInput, setConfirmPassInput] = useState('');
  const [passError, setPassError] = useState<string | null>(null);
  const [passSuccess, setPassSuccess] = useState<string | null>(null);

  // If Admin is not logged in, enforce security wall
  if (!isAdminLoggedIn) {
    return <AdminLoginView />;
  }

  const followupCount = inquiries.filter((i) => i.status === 'followup').length;
  const newLeadsCount = inquiries.filter((i) => i.status === 'new').length;
  const serviceDueCount = vehicles.filter((v) => {
    const kmSinceLast = v.currentOdometerKm - v.lastServiceKm;
    return v.serviceIntervalKm - kmSinceLast <= 500;
  }).length;

  const navItems: {
    id: AdminTabType;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    {
      id: 'analytics',
      label: 'Executive Analytics & P&L',
      icon: BarChart3,
    },
    {
      id: 'inquiries',
      label: 'CRM & Lead Follow-ups',
      icon: Users,
      badge: followupCount > 0 ? `${followupCount} Follow-ups` : newLeadsCount > 0 ? `${newLeadsCount} New` : undefined,
      badgeColor: followupCount > 0 ? 'bg-amber-500 text-white' : 'bg-indigo-600 text-white',
    },
    {
      id: 'dump',
      label: 'Recycle Dump',
      icon: Trash2,
      badge: deletedInquiries.length > 0 ? `${deletedInquiries.length} Dumped` : undefined,
      badgeColor: 'bg-rose-500 text-white',
    },
    {
      id: 'live_map',
      label: 'Live Driver Fleet Map',
      icon: MapPin,
      badge: isGpsTrackingActive ? 'LIVE GPS' : undefined,
      badgeColor: 'bg-emerald-500 text-white animate-pulse',
    },
    {
      id: 'fleet',
      label: 'Fleet & Service Reminders',
      icon: Car,
      badge: serviceDueCount > 0 ? `${serviceDueCount} Due` : undefined,
      badgeColor: 'bg-rose-500 text-white',
    },
    {
      id: 'financials',
      label: 'Excel Upload & Financials',
      icon: FileSpreadsheet,
    },
    {
      id: 'cms',
      label: 'Zero-Code Website CMS',
      icon: Settings,
    },
    {
      id: 'export_apk',
      label: 'Driver App & Android APK',
      icon: Rocket,
    },
  ];

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPassError(null);
    setPassSuccess(null);

    if (newPassInput !== confirmPassInput) {
      setPassError('New password and confirmation do not match.');
      return;
    }

    const result = changeAdminPassword(currentPassInput, newPassInput);
    if (result.success) {
      setPassSuccess(result.message);
      setTimeout(() => {
        setShowPasswordModal(false);
        setCurrentPassInput('');
        setNewPassInput('');
        setConfirmPassInput('');
        setPassSuccess(null);
      }, 1500);
    } else {
      setPassError(result.message);
    }
  };

  return (
    <div id="admin-management-portal-root" className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top Admin Navigation Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand Title */}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-xs">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-bold font-['Outfit',sans-serif] leading-tight">
                    {cms.brandName} Control Center
                  </h1>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[10px] font-bold uppercase">
                    Admin Authenticated
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Full privilege administrative dashboard • Real-time database & GPS sync
                </p>
              </div>
            </div>

            {/* Admin Header Utilities & Switchers */}
            <div className="flex items-center gap-2">
              {/* Guided Tour Trigger (Admin Only) */}
              <button
                onClick={startTour}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-semibold border border-indigo-500/30 transition-colors cursor-pointer"
                title="Start Admin Guided Tour"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Admin Guided Tour</span>
              </button>

              {/* Change Password Modal Button */}
              <button
                onClick={() => {
                  setPassError(null);
                  setPassSuccess(null);
                  setShowPasswordModal(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                title="Change Admin Password"
              >
                <Key className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Password</span>
              </button>

              {/* Driver Mobile View */}
              <button
                onClick={() => setCurrentView('driver')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Driver App</span>
              </button>

              {/* Customer Portal */}
              <button
                onClick={() => setCurrentView('customer')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Customer View</span>
              </button>

              {/* Admin Logout */}
              <button
                onClick={logoutAdmin}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white text-xs font-semibold border border-rose-500/30 transition-colors cursor-pointer"
                title="Log Out Administrator"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab Navigation Strip */}
        <div className="bg-slate-950 border-t border-slate-800/80 overflow-x-auto no-scrollbar">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 py-1.5">
            {navItems.map((tab) => {
              const Icon = tab.icon;
              const isActive = adminTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`admin-nav-${tab.id}`}
                  onClick={() => setAdminTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span
                      className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                        tab.badgeColor || 'bg-slate-800 text-slate-200'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Admin Tab Content Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {adminTab === 'analytics' && <AnalyticsTab />}
        {adminTab === 'inquiries' && <InquiriesCRMTab />}
        {adminTab === 'dump' && <RecycleDumpTab />}
        {adminTab === 'live_map' && <LiveDriverMapTab />}
        {adminTab === 'fleet' && <FleetMaintenanceTab />}
        {adminTab === 'financials' && <FinancialsExcelTab />}
        {adminTab === 'cms' && <WebsiteCMSTab />}
        {adminTab === 'export_apk' && <DeployAndApkTab />}
      </main>

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Change Admin Password</h3>
                  <p className="text-xs text-slate-400">Update master administrative credentials</p>
                </div>
              </div>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {passError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{passError}</span>
              </div>
            )}

            {passSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{passSuccess}</span>
              </div>
            )}

            <form onSubmit={handlePasswordChangeSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Current Admin Password
                </label>
                <input
                  type="password"
                  value={currentPassInput}
                  onChange={(e) => setCurrentPassInput(e.target.value)}
                  placeholder="Enter current password (default: Taha@2723)"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  New Admin Password
                </label>
                <input
                  type="password"
                  value={newPassInput}
                  onChange={(e) => setNewPassInput(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassInput}
                  onChange={(e) => setConfirmPassInput(e.target.value)}
                  placeholder="Confirm new password"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
