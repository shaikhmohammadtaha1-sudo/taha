import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { TripFinancialRecord } from '../../types';
import {
  exportProfitLossExcel,
  downloadSampleBulkUploadTemplate,
  parseBulkExcelFile,
  BulkUploadParseResult,
} from '../../utils/excelHelper';
import {
  FileSpreadsheet,
  UploadCloud,
  Download,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  X,
  FileText,
  Check,
  Search,
  AlertTriangle,
  RotateCcw,
  ShieldAlert,
  Archive,
} from 'lucide-react';

export const FinancialsExcelTab: React.FC = () => {
  const { trips, deletedTrips, bulkImportTrips, addTripRecord, deleteTripRecord, vehicles, drivers, setAdminTab } = useApp();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isBulkUploadModalOpen, setIsBulkUploadModalOpen] = useState<boolean>(false);
  const [isManualEntryModalOpen, setIsManualEntryModalOpen] = useState<boolean>(false);
  const [parsedResult, setParsedResult] = useState<BulkUploadParseResult | null>(null);
  const [isParsing, setIsParsing] = useState<boolean>(false);
  const [parseError, setParseError] = useState<string | null>(null);

  // 2-Step Double Confirmation Deletion State
  const [deletingTrip, setDeletingTrip] = useState<TripFinancialRecord | null>(null);
  const [deleteConfirmStep, setDeleteConfirmStep] = useState<1 | 2>(1);
  const [deleteReasonPreset, setDeleteReasonPreset] = useState<string>('Duplicate ledger entry');
  const [deleteReasonCustom, setDeleteReasonCustom] = useState<string>('');

  // Manual Trip Entry State
  const [customerName, setCustomerName] = useState<string>('');
  const [pickupLocation, setPickupLocation] = useState<string>('');
  const [dropLocation, setDropLocation] = useState<string>('');
  const [vehiclePlate, setVehiclePlate] = useState<string>('MH-01-EA-4412');
  const [driverName, setDriverName] = useState<string>('Ramesh Kumar');
  const [distanceKm, setDistanceKm] = useState<number>(150);
  const [revenue, setRevenue] = useState<number>(4500);
  const [fuelExpense, setFuelExpense] = useState<number>(1100);
  const [tollExpense, setTollExpense] = useState<number>(320);
  const [driverPayout, setDriverPayout] = useState<number>(1200);
  const [otherExpense, setOtherExpense] = useState<number>(100);
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending'>('paid');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsParsing(true);
    setParseError(null);

    try {
      const result = await parseBulkExcelFile(file);
      setParsedResult(result);
      setIsBulkUploadModalOpen(true);
    } catch (err) {
      setParseError((err as Error).message);
    } finally {
      setIsParsing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleConfirmImport = () => {
    if (!parsedResult || parsedResult.successRows.length === 0) return;
    bulkImportTrips(parsedResult.successRows);
    setIsBulkUploadModalOpen(false);
    setParsedResult(null);
  };

  const handleManualTripSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !pickupLocation || !dropLocation) return;

    const maintAlloc = Math.round(distanceKm * 1.5);
    const netProf = revenue - (fuelExpense + tollExpense + driverPayout + otherExpense + maintAlloc);

    addTripRecord({
      date: new Date().toISOString().slice(0, 10),
      customerName,
      pickupLocation,
      dropLocation,
      vehiclePlate,
      driverName,
      distanceKm,
      revenue,
      fuelExpense,
      tollExpense,
      driverPayout,
      maintenanceAllocated: maintAlloc,
      otherExpense,
      netProfit: netProf,
      paymentStatus,
    });

    setIsManualEntryModalOpen(false);
    setCustomerName('');
    setPickupLocation('');
    setDropLocation('');
  };

  // Filtered trips
  const filteredTrips = trips.filter((t) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      t.tripNumber.toLowerCase().includes(q) ||
      t.customerName.toLowerCase().includes(q) ||
      t.pickupLocation.toLowerCase().includes(q) ||
      t.dropLocation.toLowerCase().includes(q) ||
      t.vehiclePlate.toLowerCase().includes(q) ||
      t.driverName.toLowerCase().includes(q)
    );
  });

  return (
    <div id="admin-financials-excel-tab" className="space-y-6">
      {/* Top Header & Bulk Upload / Download Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
            Financials, Profit & Loss & Bulk Excel Engine
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Export full P&L reports, upload bulk trip sheets with automatic validation, and track net margins.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Download Sample */}
          <button
            onClick={downloadSampleBulkUploadTemplate}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            title="Download formatted Excel sheet sample"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            <span>Sample Excel Template</span>
          </button>

          {/* Bulk Upload Trigger */}
          <label className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-indigo-200 transition-all cursor-pointer">
            <UploadCloud className="w-4 h-4" />
            <span>{isParsing ? 'Parsing File...' : 'Bulk Excel Upload'}</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          {/* Dump Archive Shortcut */}
          <button
            onClick={() => setAdminTab('dump')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
            title="View deleted financial records and recycle dump"
          >
            <Archive className="w-3.5 h-3.5 text-rose-600" />
            <span>Deleted Dump ({deletedTrips.length})</span>
          </button>

          {/* Export P&L */}
          <button
            onClick={() => exportProfitLossExcel(trips)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-200 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Download P&L (Excel)</span>
          </button>

          {/* Manual Entry */}
          <button
            onClick={() => setIsManualEntryModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Trip</span>
          </button>
        </div>
      </div>

      {parseError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{parseError}</span>
        </div>
      )}

      {/* Search & Ledger Summary */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search trip ledger by trip no, customer, route..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-100"
          />
        </div>

        <div className="flex items-center gap-4 text-xs font-semibold text-slate-600">
          <span>Total Records: <b>{filteredTrips.length}</b></span>
          <span>•</span>
          <span className="text-emerald-700">
            Total Net: <b>₹{filteredTrips.reduce((s, r) => s + r.netProfit, 0).toLocaleString('en-IN')}</b>
          </span>
        </div>
      </div>

      {/* Trips Ledger Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[11px] font-bold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Trip ID / Date</th>
                <th className="px-5 py-3.5">Customer & Route</th>
                <th className="px-5 py-3.5">Vehicle & Driver</th>
                <th className="px-5 py-3.5">Gross Revenue</th>
                <th className="px-5 py-3.5">Fuel & Tolls</th>
                <th className="px-5 py-3.5">Driver & Maint</th>
                <th className="px-5 py-3.5 font-bold text-emerald-700">Net Profit</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTrips.map((t) => {
                const isProfitable = t.netProfit >= 0;
                return (
                  <tr key={t.id} className="hover:bg-slate-50/80">
                    <td className="px-5 py-3.5">
                      <span className="font-mono font-bold text-indigo-600 block">{t.tripNumber}</span>
                      <span className="text-[11px] text-slate-400">{t.date}</span>
                    </td>

                    <td className="px-5 py-3.5">
                      <span className="font-bold text-slate-900 block">{t.customerName}</span>
                      <span className="text-xs text-slate-500 truncate max-w-[180px] block">
                        {t.pickupLocation} ➔ {t.dropLocation} ({t.distanceKm} km)
                      </span>
                    </td>

                    <td className="px-5 py-3.5">
                      <span className="font-semibold text-slate-800 block">{t.vehiclePlate}</span>
                      <span className="text-[11px] text-slate-400">{t.driverName}</span>
                    </td>

                    <td className="px-5 py-3.5 font-extrabold text-slate-900">
                      ₹{t.revenue.toLocaleString('en-IN')}
                    </td>

                    <td className="px-5 py-3.5 text-xs">
                      <div>Fuel: ₹{t.fuelExpense}</div>
                      <div className="text-slate-400">Tolls: ₹{t.tollExpense}</div>
                    </td>

                    <td className="px-5 py-3.5 text-xs">
                      <div>Driver: ₹{t.driverPayout}</div>
                      <div className="text-slate-400">Maint: ₹{t.maintenanceAllocated}</div>
                    </td>

                    <td className="px-5 py-3.5">
                      <div
                        className={`font-extrabold text-sm ${
                          isProfitable ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        ₹{t.netProfit.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] text-slate-400 font-semibold">
                        {t.revenue > 0 ? `${((t.netProfit / t.revenue) * 100).toFixed(0)}% margin` : 'Expense'}
                      </div>
                    </td>

                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => {
                          setDeletingTrip(t);
                          setDeleteConfirmStep(1);
                          setDeleteReasonPreset('Duplicate ledger entry');
                          setDeleteReasonCustom('');
                        }}
                        className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Delete Trip Record (Requires 2-step confirmation)"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bulk Upload Preview & Validation Modal */}
      {isBulkUploadModalOpen && parsedResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Excel Bulk Upload Validation</h3>
                <p className="text-xs text-slate-400">
                  Parsed {parsedResult.totalParsed} rows from sheet.
                </p>
              </div>
              <button
                onClick={() => setIsBulkUploadModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm">
              {/* Validation Summary Strip */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-emerald-50 text-emerald-800 rounded-2xl border border-emerald-200">
                  <div className="text-xl font-extrabold">{parsedResult.successRows.length}</div>
                  <div className="text-xs font-semibold">Valid Rows Ready to Import</div>
                </div>

                <div className="p-3 bg-rose-50 text-rose-800 rounded-2xl border border-rose-200">
                  <div className="text-xl font-extrabold">{parsedResult.errorRows.length}</div>
                  <div className="text-xs font-semibold">Skipped / Invalid Rows</div>
                </div>

                <div className="p-3 bg-indigo-50 text-indigo-800 rounded-2xl border border-indigo-200">
                  <div className="text-xl font-extrabold">
                    ₹{parsedResult.successRows.reduce((s, r) => s + r.revenue, 0).toLocaleString('en-IN')}
                  </div>
                  <div className="text-xs font-semibold">Total Revenue Inflow</div>
                </div>
              </div>

              {/* Error Rows Table if any */}
              {parsedResult.errorRows.length > 0 && (
                <div className="p-3 bg-rose-50/50 rounded-2xl border border-rose-200 space-y-2">
                  <div className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4" />
                    <span>Row Validation Alerts (These will be skipped)</span>
                  </div>
                  <div className="space-y-1 max-h-32 overflow-y-auto text-xs text-rose-700">
                    {parsedResult.errorRows.map((err, idx) => (
                      <div key={idx}>
                        • <b>Row {err.rowNumber}:</b> {err.reason}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Preview of Valid Rows */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Preview of Parsed Trips ({parsedResult.successRows.length} records)
                </h4>
                <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-56 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-bold">
                      <tr>
                        <th className="px-3 py-2">Trip</th>
                        <th className="px-3 py-2">Customer & Route</th>
                        <th className="px-3 py-2">Revenue</th>
                        <th className="px-3 py-2">Net Profit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedResult.successRows.map((row, idx) => (
                        <tr key={idx}>
                          <td className="px-3 py-2 font-mono font-bold text-indigo-600">{row.tripNumber}</td>
                          <td className="px-3 py-2">{row.customerName} ({row.pickupLocation} ➔ {row.dropLocation})</td>
                          <td className="px-3 py-2 font-bold">₹{row.revenue}</td>
                          <td className="px-3 py-2 font-bold text-emerald-600">₹{row.netProfit}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
              <button
                onClick={() => setIsBulkUploadModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmImport}
                disabled={parsedResult.successRows.length === 0}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-200 disabled:opacity-50 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Import {parsedResult.successRows.length} Trips into Ledger</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Trip Entry Modal */}
      {isManualEntryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="flex items-center justify-between p-5 bg-slate-900 text-white">
              <h3 className="text-base font-bold">Manual Trip & Expense Entry</h3>
              <button
                onClick={() => setIsManualEntryModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleManualTripSubmit} className="p-6 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Rahul Bajaj"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Distance (KM) *</label>
                  <input
                    type="number"
                    required
                    value={distanceKm}
                    onChange={(e) => setDistanceKm(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Pickup Location *</label>
                  <input
                    type="text"
                    required
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    placeholder="e.g. Mumbai Airport"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Drop Location *</label>
                  <input
                    type="text"
                    required
                    value={dropLocation}
                    onChange={(e) => setDropLocation(e.target.value)}
                    placeholder="e.g. Pune Station"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Vehicle Plate</label>
                  <select
                    value={vehiclePlate}
                    onChange={(e) => setVehiclePlate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.plateNumber}>
                        {v.plateNumber} ({v.name})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Driver Name</label>
                  <select
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    {drivers.map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Revenue (₹)</label>
                  <input
                    type="number"
                    value={revenue}
                    onChange={(e) => setRevenue(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-emerald-700"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Fuel (₹)</label>
                  <input
                    type="number"
                    value={fuelExpense}
                    onChange={(e) => setFuelExpense(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Tolls (₹)</label>
                  <input
                    type="number"
                    value={tollExpense}
                    onChange={(e) => setTollExpense(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Driver (₹)</label>
                  <input
                    type="number"
                    value={driverPayout}
                    onChange={(e) => setDriverPayout(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsManualEntryModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 cursor-pointer"
                >
                  Save Trip Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2-Step Double Confirmation Deletion Modal to Prevent Data Loss */}
      {deletingTrip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className={`p-5 text-white flex items-center justify-between ${
              deleteConfirmStep === 1 ? 'bg-amber-600' : 'bg-rose-700'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/20 rounded-xl">
                  {deleteConfirmStep === 1 ? (
                    <AlertTriangle className="w-5 h-5 text-white" />
                  ) : (
                    <ShieldAlert className="w-5 h-5 text-white animate-pulse" />
                  )}
                </div>
                <div>
                  <h3 className="text-base font-bold">
                    {deleteConfirmStep === 1
                      ? 'Confirm Trip Record Deletion (Step 1 of 2)'
                      : 'Final Confirmation Required (Step 2 of 2)'}
                  </h3>
                  <p className="text-xs text-white/80">
                    {deleteConfirmStep === 1
                      ? 'Record will be safely moved to Dump Archive'
                      : 'Double check to prevent accidental financial data loss'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setDeletingTrip(null);
                  setDeleteConfirmStep(1);
                }}
                className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              {/* Trip Summary Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-indigo-700 text-sm">{deletingTrip.tripNumber}</span>
                  <span className="text-slate-500 font-medium">{deletingTrip.date}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-700 pt-1">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Customer</span>
                    <span className="font-semibold">{deletingTrip.customerName}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Vehicle & Driver</span>
                    <span className="font-semibold">{deletingTrip.vehiclePlate} ({deletingTrip.driverName})</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Route</span>
                    <span className="font-semibold truncate block">{deletingTrip.pickupLocation} ➔ {deletingTrip.dropLocation}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Financial Net Profit</span>
                    <span className="font-extrabold text-emerald-700 text-sm">₹{deletingTrip.netProfit.toLocaleString('en-IN')}</span>
                    <span className="text-[10px] text-slate-400 ml-1">(Rev: ₹{deletingTrip.revenue})</span>
                  </div>
                </div>
              </div>

              {deleteConfirmStep === 1 ? (
                /* Step 1: Reason and Intent */
                <div className="space-y-3">
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
                    <b>Safe Archival Policy:</b> Deleting this record will remove it from the active ledger and profit reports. It will remain preserved in the <b>Recycle Dump</b> where an administrator can restore it at any time.
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Reason for Deletion *
                    </label>
                    <select
                      value={deleteReasonPreset}
                      onChange={(e) => setDeleteReasonPreset(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-amber-400 bg-white"
                    >
                      <option value="Duplicate ledger entry">Duplicate ledger entry</option>
                      <option value="Customer trip cancelled with full refund">Customer trip cancelled with full refund</option>
                      <option value="Test / demo financial entry">Test / demo financial entry</option>
                      <option value="Disputed billing correction">Disputed billing correction</option>
                      <option value="Incorrect vehicle assignment & re-entry required">Incorrect vehicle assignment & re-entry required</option>
                      <option value="Other">Other / Custom Reason</option>
                    </select>
                  </div>

                  {deleteReasonPreset === 'Other' && (
                    <div>
                      <input
                        type="text"
                        placeholder="Please specify deletion reason..."
                        value={deleteReasonCustom}
                        onChange={(e) => setDeleteReasonCustom(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-400"
                      />
                    </div>
                  )}
                </div>
              ) : (
                /* Step 2: High Alert Verification */
                <div className="space-y-3">
                  <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 text-xs text-rose-900 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-rose-800 text-sm">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>Action Confirmation Verification</span>
                    </div>
                    <p className="leading-relaxed">
                      You are about to delete <b>{deletingTrip.tripNumber}</b> for <b>{deletingTrip.customerName}</b>.
                    </p>
                    <p className="text-[11px] text-rose-700">
                      Reason recorded: <i>"{deleteReasonPreset === 'Other' ? deleteReasonCustom || 'Administrative Action' : deleteReasonPreset}"</i>
                    </p>
                  </div>

                  <div className="text-xs text-slate-500 text-center">
                    Please press the button below to confirm and move this transaction to the Dump.
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer Actions */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setDeletingTrip(null);
                  setDeleteConfirmStep(1);
                }}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>

              {deleteConfirmStep === 1 ? (
                <button
                  type="button"
                  onClick={() => setDeleteConfirmStep(2)}
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-md shadow-amber-200 cursor-pointer transition-all"
                >
                  <span>Proceed to Final Confirmation (2/2)</span>
                  <Check className="w-4 h-4" />
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmStep(1)}
                    className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800"
                  >
                    Back to Step 1
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const finalReason = deleteReasonPreset === 'Other'
                        ? deleteReasonCustom || 'Administrative Action'
                        : deleteReasonPreset;
                      deleteTripRecord(deletingTrip.id, finalReason);
                      setDeletingTrip(null);
                      setDeleteConfirmStep(1);
                    }}
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-200 cursor-pointer transition-all animate-in pulse"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Yes, Confirm & Move to Dump</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
