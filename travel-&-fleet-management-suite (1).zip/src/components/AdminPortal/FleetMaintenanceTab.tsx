import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Vehicle, MaintenanceLog, VehicleType, OwnershipType } from '../../types';
import { exportFleetAuditExcel } from '../../utils/excelHelper';
import {
  Wrench,
  AlertTriangle,
  CheckCircle2,
  Plus,
  Car,
  Calendar,
  Fuel,
  FileSpreadsheet,
  Trash2,
  Clock,
  ShieldCheck,
  X,
  Gauge,
  Check,
} from 'lucide-react';

export const FleetMaintenanceTab: React.FC = () => {
  const { vehicles, maintenanceLogs, addVehicle, logMaintenanceService, deleteVehicle, updateVehicle } = useApp();

  const [isServiceModalOpen, setIsServiceModalOpen] = useState<boolean>(false);
  const [isAddVehicleModalOpen, setIsAddVehicleModalOpen] = useState<boolean>(false);
  const [selectedVehicleForService, setSelectedVehicleForService] = useState<Vehicle | null>(null);

  // Service Log Form State
  const [serviceDate, setServiceDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [serviceOdoKm, setServiceOdoKm] = useState<number>(0);
  const [serviceType, setServiceType] = useState<MaintenanceLog['serviceType']>('routine_oil_filter');
  const [serviceCost, setServiceCost] = useState<number>(4500);
  const [garageName, setGarageName] = useState<string>('Authorized Service Center');
  const [serviceNotes, setServiceNotes] = useState<string>('Routine 10,000 km oil change, air filter replacement & brake checkup.');

  // Add Vehicle Form State
  const [name, setName] = useState<string>('');
  const [model, setModel] = useState<string>('');
  const [plateNumber, setPlateNumber] = useState<string>('');
  const [category, setCategory] = useState<VehicleType>('sedan');
  const [ownershipType, setOwnershipType] = useState<OwnershipType>('company_owned');
  const [seatingCapacity, setSeatingCapacity] = useState<number>(4);
  const [luggageCapacity, setLuggageCapacity] = useState<number>(2);
  const [baseFare, setBaseFare] = useState<number>(800);
  const [ratePerKm, setRatePerKm] = useState<number>(14);
  const [fuelEfficiency, setFuelEfficiency] = useState<number>(20);
  const [fuelType, setFuelType] = useState<'diesel' | 'petrol' | 'cng' | 'ev'>('cng');
  const [currentOdometer, setCurrentOdometer] = useState<number>(30000);
  const [serviceIntervalKm, setServiceIntervalKm] = useState<number>(10000);
  const [imageUrl, setImageUrl] = useState<string>('https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80');

  const handleOpenServiceModal = (v: Vehicle) => {
    setSelectedVehicleForService(v);
    setServiceOdoKm(v.currentOdometerKm);
    setIsServiceModalOpen(true);
  };

  const handleSaveServiceLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicleForService) return;

    logMaintenanceService({
      vehicleId: selectedVehicleForService.id,
      vehicleName: selectedVehicleForService.name,
      plateNumber: selectedVehicleForService.plateNumber,
      serviceDate,
      odometerKmAtService: serviceOdoKm,
      serviceType,
      cost: serviceCost,
      garageName,
      notes: serviceNotes,
      nextServiceDueKm: serviceOdoKm + selectedVehicleForService.serviceIntervalKm,
    });

    setIsServiceModalOpen(false);
    setSelectedVehicleForService(null);
  };

  const handleAddVehicleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !plateNumber) return;

    addVehicle({
      name,
      model: model || name,
      plateNumber,
      category,
      ownershipType,
      seatingCapacity,
      luggageCapacity,
      baseFare: baseFare || 2250,
      baseKm: 80,
      ratePerKm: ratePerKm || 13.5,
      localBaseFare8hr80km: baseFare || 2250,
      localExtraKmRate: ratePerKm || 13,
      localExtraHrRate: 110,
      outstationPerKmRate: ratePerKm || 13.5,
      outstationMinKmPerDay: 250,
      driverAllowancePerDay: 350,
      fuelEfficiencyKmPerL: fuelEfficiency,
      fuelType,
      currentOdometerKm: currentOdometer,
      lastServiceKm: currentOdometer,
      serviceIntervalKm,
      insuranceExpiry: '2027-08-30',
      fitnessExpiry: '2028-08-30',
      status: 'active',
      imageUrl,
      features: ['Air Conditioning', 'Fastag', 'Clean Interiors'],
      acType: 'AC',
    });

    setIsAddVehicleModalOpen(false);
    setName('');
    setModel('');
    setPlateNumber('');
  };

  // Check critical service alert count
  const criticalServiceCount = vehicles.filter((v) => {
    const kmSinceLast = v.currentOdometerKm - v.lastServiceKm;
    return v.serviceIntervalKm - kmSinceLast <= 500;
  }).length;

  return (
    <div id="admin-fleet-maintenance-tab" className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
              Vehicle Fleet & Preventive Maintenance Reminders
            </h2>
            {criticalServiceCount > 0 && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                {criticalServiceCount} Service Due
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Enforces 10,000 KM service cycles for company-owned cars with automated odometer countdown alerts.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => exportFleetAuditExcel(vehicles, maintenanceLogs)}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-200 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Fleet & Audit (Excel)</span>
          </button>

          <button
            id="btn-open-add-vehicle"
            onClick={() => setIsAddVehicleModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Vehicle</span>
          </button>
        </div>
      </div>

      {/* Vehicle Grid with Odometer & Service Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vehicles.map((v) => {
          const kmSinceLast = v.currentOdometerKm - v.lastServiceKm;
          const kmRemaining = v.serviceIntervalKm - kmSinceLast;
          const isOverdue = kmRemaining <= 0;
          const isDueSoon = kmRemaining > 0 && kmRemaining <= 500;
          const isHealthy = kmRemaining > 500;
          const percentUsed = Math.min(100, Math.round((kmSinceLast / v.serviceIntervalKm) * 100));

          return (
            <div
              key={v.id}
              className={`bg-white rounded-3xl border-2 shadow-sm overflow-hidden flex flex-col justify-between transition-all ${
                isOverdue
                  ? 'border-rose-300 ring-2 ring-rose-100'
                  : isDueSoon
                  ? 'border-amber-300 ring-2 ring-amber-100'
                  : 'border-slate-200'
              }`}
            >
              <div>
                {/* Image & Header Tags */}
                <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
                  <img
                    src={v.imageUrl}
                    alt={v.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <span className="px-2.5 py-1 bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-bold rounded-lg uppercase">
                      {v.plateNumber}
                    </span>
                    <span
                      className={`px-2.5 py-1 text-[11px] font-bold rounded-lg ${
                        v.ownershipType === 'company_owned'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-700 text-slate-200'
                      }`}
                    >
                      {v.ownershipType === 'company_owned' ? '🏢 Company Owned' : '🤝 Partner Car'}
                    </span>
                  </div>

                  <div className="absolute bottom-3 right-3 px-2.5 py-0.5 bg-white/90 backdrop-blur-md text-slate-800 text-[11px] font-bold rounded-md">
                    {v.fuelEfficiencyKmPerL} km/l ({v.fuelType.toUpperCase()})
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-900 leading-tight">{v.name}</h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Driver: <b>{v.driverName || 'Unassigned'}</b>
                      </p>
                    </div>
                  </div>

                  {/* Odometer Tracker Bar */}
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2 mb-4">
                    <div className="flex justify-between items-center text-xs">
                      <span className="flex items-center gap-1 font-semibold text-slate-700">
                        <Gauge className="w-3.5 h-3.5 text-indigo-600" />
                        Odometer: {v.currentOdometerKm.toLocaleString()} KM
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Last: {v.lastServiceKm.toLocaleString()} KM
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isOverdue ? 'bg-rose-500' : isDueSoon ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${percentUsed}%` }}
                      />
                    </div>

                    {/* Service Alert Badge */}
                    <div className="flex items-center justify-between text-xs pt-1">
                      {isOverdue ? (
                        <span className="flex items-center gap-1 font-bold text-rose-600">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          OVERDUE by {Math.abs(kmRemaining)} KM!
                        </span>
                      ) : isDueSoon ? (
                        <span className="flex items-center gap-1 font-bold text-amber-600">
                          <Clock className="w-3.5 h-3.5" />
                          Service Due in {kmRemaining} KM
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 font-semibold text-emerald-600">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Next Service in {kmRemaining} KM
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400 font-mono">
                        Every {v.serviceIntervalKm / 1000}k km
                      </span>
                    </div>
                  </div>

                  {/* Fast Odometer Advance (for testing reminder) */}
                  <div className="flex items-center justify-between text-xs text-slate-500 pb-2">
                    <span>Simulate KM Driving:</span>
                    <div className="flex gap-1">
                      <button
                        onClick={() =>
                          updateVehicle(v.id, { currentOdometerKm: v.currentOdometerKm + 500 })
                        }
                        className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] cursor-pointer"
                        title="Add 500 km to simulate trip"
                      >
                        +500 KM
                      </button>
                      <button
                        onClick={() =>
                          updateVehicle(v.id, { currentOdometerKm: v.currentOdometerKm + 2000 })
                        }
                        className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] cursor-pointer"
                        title="Add 2000 km"
                      >
                        +2,000 KM
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => handleOpenServiceModal(v)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm shadow-indigo-200 transition-all cursor-pointer"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>Log Service & Reset</span>
                </button>

                <button
                  onClick={() => {
                    if (window.confirm(`Remove ${v.plateNumber} from fleet?`)) {
                      deleteVehicle(v.id);
                    }
                  }}
                  className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
                  title="Delete Vehicle"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Maintenance History Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden mt-8">
        <div className="p-5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 font-['Outfit',sans-serif]">
            Recent Maintenance & Workshop Logs
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            {maintenanceLogs.length} Completed Service Records
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-500 uppercase text-[11px] font-bold border-b border-slate-200">
              <tr>
                <th className="px-6 py-3.5">Service Date</th>
                <th className="px-6 py-3.5">Vehicle / Plate</th>
                <th className="px-6 py-3.5">Service Type</th>
                <th className="px-6 py-3.5">Odometer at Service</th>
                <th className="px-6 py-3.5">Cost</th>
                <th className="px-6 py-3.5">Workshop Garage & Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {maintenanceLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/80">
                  <td className="px-6 py-3.5 font-medium text-slate-700">{log.serviceDate}</td>
                  <td className="px-6 py-3.5">
                    <span className="font-bold text-slate-900 block">{log.vehicleName}</span>
                    <span className="text-[11px] text-slate-400 font-mono">{log.plateNumber}</span>
                  </td>
                  <td className="px-6 py-3.5">
                    <span className="px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 font-bold text-xs uppercase">
                      {log.serviceType.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-3.5 font-semibold text-slate-800">
                    {log.odometerKmAtService.toLocaleString()} KM
                  </td>
                  <td className="px-6 py-3.5 font-extrabold text-slate-900">
                    ₹{log.cost.toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-3.5">
                    <div className="text-slate-800 font-medium">{log.garageName}</div>
                    <div className="text-[11px] text-slate-400 max-w-xs truncate">{log.notes}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Service Modal */}
      {isServiceModalOpen && selectedVehicleForService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="flex items-center justify-between p-5 bg-slate-900 text-white">
              <div>
                <h3 className="text-base font-bold">Log Workshop Service & Reset Reminder</h3>
                <p className="text-xs text-slate-400">
                  {selectedVehicleForService.name} ({selectedVehicleForService.plateNumber})
                </p>
              </div>
              <button
                onClick={() => setIsServiceModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveServiceLog} className="p-6 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Service Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={serviceDate}
                    onChange={(e) => setServiceDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Odometer at Service (KM) *
                  </label>
                  <input
                    type="number"
                    required
                    value={serviceOdoKm}
                    onChange={(e) => setServiceOdoKm(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Service Type *
                  </label>
                  <select
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value as MaintenanceLog['serviceType'])}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="routine_oil_filter">Routine Engine Oil & Filter</option>
                    <option value="tyre_replacement">Tyre Replacement / Alignment</option>
                    <option value="brake_pads">Brake Pads & Disc Rotor</option>
                    <option value="major_overhaul">Major Overhaul / Clutch</option>
                    <option value="ac_servicing">AC Gas & Disinfection</option>
                    <option value="general_checkup">General Inspection</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Service Cost (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    value={serviceCost}
                    onChange={(e) => setServiceCost(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-indigo-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Garage / Authorized Center Name
                </label>
                <input
                  type="text"
                  required
                  value={garageName}
                  onChange={(e) => setGarageName(e.target.value)}
                  placeholder="e.g. Authorized Dealership Workshop"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Service Notes & Parts Replaced
                </label>
                <textarea
                  rows={2}
                  value={serviceNotes}
                  onChange={(e) => setServiceNotes(e.target.value)}
                  placeholder="e.g. Synthetic oil replaced, coolant topped up, brake caliper checked..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="p-3 bg-indigo-50 text-indigo-900 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>
                  Saving will set last service to <b>{serviceOdoKm.toLocaleString()} KM</b> and schedule the next alert for <b>{(serviceOdoKm + selectedVehicleForService.serviceIntervalKm).toLocaleString()} KM</b>.
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsServiceModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 cursor-pointer"
                >
                  Commit Service & Reset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Vehicle Modal */}
      {isAddVehicleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
            <div className="flex items-center justify-between p-5 bg-slate-900 text-white">
              <h3 className="text-base font-bold">Add New Vehicle to Fleet</h3>
              <button
                onClick={() => setIsAddVehicleModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddVehicleSubmit} className="p-6 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Vehicle Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Maruti Ertiga ZXi"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Plate Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={plateNumber}
                    onChange={(e) => setPlateNumber(e.target.value)}
                    placeholder="MH-01-AB-1234"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as VehicleType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="sedan">Sedan</option>
                    <option value="suv">SUV</option>
                    <option value="luxury">Luxury</option>
                    <option value="tempo_traveller">Tempo Traveller</option>
                    <option value="hatchback">Hatchback</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Ownership</label>
                  <select
                    value={ownershipType}
                    onChange={(e) => setOwnershipType(e.target.value as OwnershipType)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="company_owned">Company Owned</option>
                    <option value="partner_attached">Partner Attached</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Fuel Type</label>
                  <select
                    value={fuelType}
                    onChange={(e) => setFuelType(e.target.value as 'cng' | 'diesel' | 'petrol' | 'ev')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  >
                    <option value="cng">CNG</option>
                    <option value="diesel">Diesel</option>
                    <option value="petrol">Petrol</option>
                    <option value="ev">Electric (EV)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Rate (₹/KM)</label>
                  <input
                    type="number"
                    value={ratePerKm}
                    onChange={(e) => setRatePerKm(parseFloat(e.target.value) || 12)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Mileage (km/l)</label>
                  <input
                    type="number"
                    value={fuelEfficiency}
                    onChange={(e) => setFuelEfficiency(parseFloat(e.target.value) || 18)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Current Odo (KM)</label>
                  <input
                    type="number"
                    value={currentOdometer}
                    onChange={(e) => setCurrentOdometer(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Image URL</label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddVehicleModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 cursor-pointer"
                >
                  Save & Add Vehicle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
