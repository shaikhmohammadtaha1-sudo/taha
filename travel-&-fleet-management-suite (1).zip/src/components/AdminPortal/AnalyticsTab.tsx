import React from 'react';
import { useApp } from '../../context/AppContext';
import { exportProfitLossExcel, exportInquiriesExcel } from '../../utils/excelHelper';
import {
  TrendingUp,
  DollarSign,
  Fuel,
  Wrench,
  Users,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ArrowUpRight,
  ShieldAlert,
  Percent,
  Calendar,
} from 'lucide-react';

export const AnalyticsTab: React.FC = () => {
  const { trips, inquiries, vehicles, cms, setAdminTab } = useApp();

  // Financial aggregates
  const totalRevenue = trips.reduce((sum, t) => sum + t.revenue, 0);
  const totalFuel = trips.reduce((sum, t) => sum + t.fuelExpense, 0);
  const totalTolls = trips.reduce((sum, t) => sum + t.tollExpense, 0);
  const totalDriverPayout = trips.reduce((sum, t) => sum + t.driverPayout, 0);
  const totalMaintenance = trips.reduce((sum, t) => sum + t.maintenanceAllocated, 0);
  const totalOther = trips.reduce((sum, t) => sum + t.otherExpense, 0);
  const totalNetProfit = trips.reduce((sum, t) => sum + t.netProfit, 0);
  const profitMarginPct = totalRevenue > 0 ? ((totalNetProfit / totalRevenue) * 100).toFixed(1) : '0';

  // CRM Analytics
  const totalInquiriesCount = inquiries.length;
  const confirmedCount = inquiries.filter((i) => i.status === 'confirmed' || i.status === 'completed').length;
  const followupCount = inquiries.filter((i) => i.status === 'followup').length;
  const notInterestedList = inquiries.filter((i) => i.status === 'not_interested');
  const notInterestedCount = notInterestedList.length;

  const conversionRate = totalInquiriesCount > 0 ? ((confirmedCount / totalInquiriesCount) * 100).toFixed(1) : '0';
  const lostQuoteValue = notInterestedList.reduce((sum, i) => sum + i.totalQuote, 0);

  // Sub-disposition Breakdown
  const reasonBreakdown = notInterestedList.reduce((acc, curr) => {
    const r = curr.notInterestedReason || 'other';
    acc[r] = (acc[r] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div id="admin-analytics-tab-content" className="space-y-8">
      {/* Top Header Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
            Executive Profit & Business Intelligence
          </h2>
          <p className="text-sm text-slate-500">
            Real-time calculation of gross revenue, fuel overheads, maintenance allocations, and CRM inquiry conversion funnel.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => exportProfitLossExcel(trips)}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-200 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Download P&L Statement (Excel)</span>
          </button>
        </div>
      </div>

      {/* High-Level Financial Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Gross Revenue */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Gross Fleet Revenue</span>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            ₹{totalRevenue.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-emerald-600">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>From {trips.length} Completed Trips</span>
          </div>
        </div>

        {/* Net Profit */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Net Operating Profit</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 font-['Outfit',sans-serif]">
            ₹{totalNetProfit.toLocaleString('en-IN')}
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-slate-600">
            <Percent className="w-3 h-3 text-indigo-500" />
            <span>Margin: <b>{profitMarginPct}%</b> of gross revenue</span>
          </div>
        </div>

        {/* Fuel Overheads */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Fuel Overheads</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Fuel className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            ₹{totalFuel.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-medium">
            Based on ₹{cms.fuelIndexPrice}/L fuel benchmark
          </div>
        </div>

        {/* Fleet Maintenance Allocated */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Service & Maintenance</span>
            <div className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            ₹{totalMaintenance.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-medium">
            Preventive 10k km scheduled buffer
          </div>
        </div>
      </div>

      {/* Expense Breakdown & Inquiry Funnel Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Expense Composition Chart / Visual Breakdown */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
          <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif] mb-1">
            Operating Expense Structure & Cost Allocations
          </h3>
          <p className="text-xs text-slate-500 mb-6">
            Detailed distribution of costs deducted from gross client billings.
          </p>

          <div className="space-y-4">
            {/* Fuel */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Fuel Consumption
                </span>
                <span>₹{totalFuel.toLocaleString('en-IN')} ({totalRevenue > 0 ? ((totalFuel / totalRevenue) * 100).toFixed(1) : 0}%)</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${Math.min(100, (totalFuel / (totalRevenue || 1)) * 100)}%` }}
                />
              </div>
            </div>

            {/* Driver Payouts */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" /> Driver Payouts & Allowances
                </span>
                <span>₹{totalDriverPayout.toLocaleString('en-IN')} ({totalRevenue > 0 ? ((totalDriverPayout / totalRevenue) * 100).toFixed(1) : 0}%)</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full"
                  style={{ width: `${Math.min(100, (totalDriverPayout / (totalRevenue || 1)) * 100)}%` }}
                />
              </div>
            </div>

            {/* Tolls */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Fastag Highway Tolls
                </span>
                <span>₹{totalTolls.toLocaleString('en-IN')} ({totalRevenue > 0 ? ((totalTolls / totalRevenue) * 100).toFixed(1) : 0}%)</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${Math.min(100, (totalTolls / (totalRevenue || 1)) * 100)}%` }}
                />
              </div>
            </div>

            {/* Maintenance */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Vehicle Maintenance Provision
                </span>
                <span>₹{totalMaintenance.toLocaleString('en-IN')} ({totalRevenue > 0 ? ((totalMaintenance / totalRevenue) * 100).toFixed(1) : 0}%)</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${Math.min(100, (totalMaintenance / (totalRevenue || 1)) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Inquiry Conversion & Loss Analytics (As requested in prompt) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-['Outfit',sans-serif]">
                  Inquiry Conversion & Loss Analysis
                </h3>
                <p className="text-xs text-slate-500">
                  Sub-disposition tracking of unclosed leads.
                </p>
              </div>
              <button
                onClick={() => setAdminTab('inquiries')}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-bold cursor-pointer"
              >
                View All CRM Leads →
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-2xl border border-slate-100 mb-4 text-center">
              <div>
                <div className="text-lg font-extrabold text-slate-900">{totalInquiriesCount}</div>
                <div className="text-[11px] text-slate-500 font-medium">Total Leads</div>
              </div>
              <div>
                <div className="text-lg font-extrabold text-emerald-600">{conversionRate}%</div>
                <div className="text-[11px] text-slate-500 font-medium">Converted</div>
              </div>
              <div>
                <div className="text-lg font-extrabold text-rose-600">₹{lostQuoteValue.toLocaleString('en-IN')}</div>
                <div className="text-[11px] text-slate-500 font-medium">Lost Quote Vol</div>
              </div>
            </div>

            {/* Reasons for 'Not Interested' */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Top Reasons for "Not Interested":
              </span>

              {Object.keys(reasonBreakdown).length > 0 ? (
                Object.entries(reasonBreakdown).map(([reason, count]) => {
                  const labelMap: Record<string, string> = {
                    price_high: 'Price High / Budget Constraint',
                    booked_competitor: 'Booked Competitor / Other Vendor',
                    trip_cancelled: 'Trip Cancelled by Customer',
                    vehicle_unavailable: 'Requested Vehicle Unavailable',
                    route_unserviceable: 'Route Not Serviceable',
                    timing_mismatch: 'Pickup Timing Mismatch',
                    other: 'Other Dispositions',
                  };
                  return (
                    <div
                      key={reason}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs"
                    >
                      <span className="text-slate-700 font-medium">{labelMap[reason] || reason}</span>
                      <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 font-bold">
                        {count} inquiries
                      </span>
                    </div>
                  );
                })
              ) : (
                <div className="text-xs text-slate-400 p-3 text-center bg-slate-50 rounded-xl">
                  No lost inquiries recorded.
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Active Scheduled Follow-ups: <b>{followupCount}</b></span>
            <button
              onClick={() => exportInquiriesExcel(inquiries)}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
            >
              Export CRM Excel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
