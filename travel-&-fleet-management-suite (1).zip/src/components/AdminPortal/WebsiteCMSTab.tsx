import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { WebsiteCMS } from '../../types';
import {
  Globe,
  Sparkles,
  Phone,
  MessageSquare,
  Mail,
  MapPin,
  Fuel,
  Percent,
  Moon,
  Image as ImageIcon,
  Save,
  RotateCcw,
  CheckCircle2,
  Eye,
  ShieldCheck,
  Copyright,
  FileText,
} from 'lucide-react';

export const WebsiteCMSTab: React.FC = () => {
  const { cms, updateCMS, resetCMSToDefault, setCurrentView } = useApp();

  const [formData, setFormData] = useState<WebsiteCMS>(cms);

  const handleChange = (field: keyof WebsiteCMS, value: string | number | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateCMS(formData);
  };

  const presetHeroImages = [
    {
      label: 'Expressway Highway Sunset',
      url: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=1600&q=80',
    },
    {
      label: 'Executive Chauffeur Sedan',
      url: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1600&q=80',
    },
    {
      label: 'Airport Terminal Cab Line',
      url: 'https://images.unsplash.com/photo-1508974239320-0a029497e820?auto=format&fit=crop&w=1600&q=80',
    },
    {
      label: 'Mountain Outstation Tour',
      url: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1600&q=80',
    },
  ];

  return (
    <div id="admin-website-cms-tab" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
              Zero-Code Website CMS & Live Fuel Rates
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">
              ⚡ Real-Time Sync
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Edit headlines, banner imagery, fuel price indices, and contact details. All changes reflect live instantly on the customer booking portal without writing code.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentView('customer')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-indigo-600" />
            <span>Preview Public Site</span>
          </button>

          <button
            onClick={resetCMSToDefault}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            title="Reset to initial default template"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Dynamic Fuel Index & Fare Parameters */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Fuel className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Live Fuel Price & Calculation Constants
              </h3>
              <p className="text-xs text-slate-500">
                Updating the fuel price automatically recalibrates fares across all vehicle categories.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Fuel Benchmark Index (₹ / Liter) *
              </label>
              <div className="relative">
                <Fuel className="w-4 h-4 text-amber-500 absolute left-3.5 top-3" />
                <input
                  id="input-cms-fuel-price"
                  type="number"
                  step="0.1"
                  required
                  value={formData.fuelIndexPrice}
                  onChange={(e) => handleChange('fuelIndexPrice', parseFloat(e.target.value) || 94.5)}
                  className="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-amber-200"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                Directly impacts the estimated fuel component in customer fares.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                GST / Tax Percentage (%)
              </label>
              <div className="relative">
                <Percent className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="number"
                  step="0.5"
                  value={formData.defaultTaxPct}
                  onChange={(e) => handleChange('defaultTaxPct', parseFloat(e.target.value) || 5)}
                  className="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-900"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                Standard cab transport GST rate.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Night Allowance Rate (₹)
              </label>
              <div className="relative">
                <Moon className="w-4 h-4 text-indigo-500 absolute left-3.5 top-3" />
                <input
                  type="number"
                  value={formData.driverNightAllowanceRate}
                  onChange={(e) => handleChange('driverNightAllowanceRate', parseInt(e.target.value) || 250)}
                  className="w-full pl-10 pr-3 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-900"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                Applied for pickups between 10:00 PM and 06:00 AM.
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Hero Banner & Marketing Messaging */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Hero Banner, Headlines & Promo Announcements
              </h3>
              <p className="text-xs text-slate-500">
                Front-facing display copy visible to all website visitors.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Website Hero Headline *
              </label>
              <input
                id="input-cms-headline"
                type="text"
                required
                value={formData.heroHeadline}
                onChange={(e) => handleChange('heroHeadline', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-indigo-100"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Sub-Headline & Value Proposition
              </label>
              <textarea
                rows={2}
                value={formData.heroSubheadline}
                onChange={(e) => handleChange('heroSubheadline', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-700 focus:ring-2 focus:ring-indigo-100"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Top Announcement Promo Notice Bar
              </label>
              <input
                type="text"
                value={formData.promoNotice}
                onChange={(e) => handleChange('promoNotice', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-medium text-slate-800"
              />
            </div>

            {/* Banner Image Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Hero Banner Background Image URL
              </label>
              <div className="relative mb-2">
                <ImageIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="url"
                  value={formData.heroBannerImage}
                  onChange={(e) => handleChange('heroBannerImage', e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 text-xs text-slate-700"
                />
              </div>

              {/* Preset Image Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-semibold text-slate-400">Presets:</span>
                {presetHeroImages.map((preset, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => handleChange('heroBannerImage', preset.url)}
                    className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 transition-colors cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Brand Identity & Contact Channels */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Brand Identity & Support Desk Details
              </h3>
              <p className="text-xs text-slate-500">
                Official contact info displayed in customer header, footer, and inquiry confirmations.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Brand Name *</label>
              <input
                type="text"
                required
                value={formData.brandName}
                onChange={(e) => handleChange('brandName', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Brand Slogan / Tagline</label>
              <input
                type="text"
                value={formData.brandTagline}
                onChange={(e) => handleChange('brandTagline', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Support Phone</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">WhatsApp Dispatch Desk</label>
              <div className="relative">
                <MessageSquare className="w-4 h-4 text-emerald-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={formData.whatsapp}
                  onChange={(e) => handleChange('whatsapp', e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Support Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Fleet Base Address</label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-200 text-sm"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: Legal Registered Entity, Copyright & "All Rights Reserved" Customization */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Copyright className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Legal Entity, Copyright & "All Rights Reserved" Notice
              </h3>
              <p className="text-xs text-slate-500">
                Customize the legal company name, "All Rights Reserved" statement, trademark claims, and official footer accreditation in case client requires custom wording.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Legal Registered Company / Entity Name *
              </label>
              <input
                type="text"
                placeholder="e.g. TransVoyage Global Travel Technologies Pvt Ltd"
                value={formData.legalCompanyName || ''}
                onChange={(e) => handleChange('legalCompanyName', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-200"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Official entity name shown in copyright notice and legal invoices.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Copyright & Rights Reserved Notice *
              </label>
              <input
                type="text"
                placeholder="e.g. All Rights Reserved."
                value={formData.copyrightNotice || ''}
                onChange={(e) => handleChange('copyrightNotice', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-200"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Customizable rights text (e.g. "All Rights Reserved", "All Rights Reserved. Licensed Tourist Transport Service.").
              </span>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Custom Footer Sub-Note & Regulatory Disclaimers
              </label>
              <input
                type="text"
                placeholder="e.g. Zero-Code CMS & Real-Time Driver Sync. Authorized by Regional Transport Office."
                value={formData.customFooterNote || ''}
                onChange={(e) => handleChange('customFooterNote', e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-200"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Displays below the copyright line on the customer portal footer.
              </span>
            </div>
          </div>

          {/* Real-time Footer Preview Card */}
          <div className="mt-4 p-4 bg-slate-950 text-slate-400 rounded-2xl border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-indigo-400 tracking-wider">
              <Eye className="w-3 h-3" />
              <span>Live Footer Preview</span>
            </div>
            <div className="text-xs text-slate-200 font-medium pt-1">
              © {new Date().getFullYear()} {formData.legalCompanyName || formData.brandName} • {formData.copyrightNotice || 'All Rights Reserved.'}
            </div>
            {formData.customFooterNote && (
              <div className="text-[11px] text-slate-400">
                {formData.customFooterNote}
              </div>
            )}
          </div>
        </div>

        {/* Submit Bar */}
        <div className="flex justify-end pt-2">
          <button
            id="btn-save-cms-settings"
            type="submit"
            className="flex items-center gap-2 px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-sm font-bold shadow-lg shadow-indigo-200 transition-all hover:scale-[1.01] cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save & Publish Live Changes</span>
          </button>
        </div>
      </form>
    </div>
  );
};
