import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LeafletMap } from '../Common/LeafletMap';
import { GoogleMapWrapper, hasValidGoogleMapsKey } from '../GoogleMaps/GoogleMapWrapper';
import { LiveGoogleFleetMap } from '../GoogleMaps/LiveGoogleFleetMap';
import { Driver, DriverStatus } from '../../types';
import {
  MapPin,
  Smartphone,
  Battery,
  Zap,
  Phone,
  Car,
  Star,
  Plus,
  Radio,
  Play,
  Pause,
  X,
  UserCheck,
  CheckCircle2,
  Map as MapIcon,
  Sparkles,
} from 'lucide-react';

export const LiveDriverMapTab: React.FC = () => {
  const {
    drivers,
    selectedDriverId,
    setSelectedDriverId,
    updateDriverStatus,
    addDriver,
    isGpsTrackingActive,
    toggleGpsTracking,
    simulateFleetMovement,
    vehicles,
    inquiries,
  } = useApp();

  const [mapEngine, setMapEngine] = useState<'google' | 'leaflet'>(hasValidGoogleMapsKey ? 'google' : 'leaflet');
  const [isAddDriverModalOpen, setIsAddDriverModalOpen] = useState<boolean>(false);
  const [newDriverName, setNewDriverName] = useState<string>('');
  const [newDriverPhone, setNewDriverPhone] = useState<string>('');
  const [newDriverLicense, setNewDriverLicense] = useState<string>('');
  const [newDriverVehicleId, setNewDriverVehicleId] = useState<string>('');

  const selectedDriver = drivers.find((d) => d.id === selectedDriverId) || drivers[0];

  const handleAddDriver = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDriverName || !newDriverPhone) return;

    const matchedVeh = vehicles.find((v) => v.id === newDriverVehicleId);

    addDriver({
      name: newDriverName,
      phone: newDriverPhone,
      licenseNumber: newDriverLicense || `DL-${Math.floor(100000 + Math.random() * 900000)}`,
      photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      rating: 5.0,
      status: 'available',
      assignedVehicleId: matchedVeh?.id,
      assignedVehicleName: matchedVeh?.name,
      assignedVehiclePlate: matchedVeh?.plateNumber,
      currentLat: 19.076 + (Math.random() - 0.5) * 0.05,
      currentLng: 72.8777 + (Math.random() - 0.5) * 0.05,
      currentLocationName: 'Mumbai City Center',
      lastPingTime: 'Just now',
      batteryPct: 98,
      speedKmph: 0,
      todayEarnings: 0,
      todayTrips: 0,
      totalCompletedTrips: 0,
    });

    setIsAddDriverModalOpen(false);
    setNewDriverName('');
    setNewDriverPhone('');
    setNewDriverLicense('');
  };

  return (
    <div id="admin-driver-live-map-tab" className="space-y-6">
      {/* Top Header & Live Broadcast Telemetry Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-['Outfit',sans-serif]">
              Live Driver Fleet GPS & Dispatch Map
            </h2>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              <Radio className="w-3 h-3 text-emerald-600 animate-pulse" /> Live Telemetry
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            Admin-only high precision driver locator, speed monitors, battery status, and instant route dispatch.
          </p>
        </div>

        {/* Live Simulator & Driver Add Controls */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Map Engine Toggle */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              type="button"
              onClick={() => setMapEngine('google')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                mapEngine === 'google' ? 'bg-white text-indigo-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Google Maps
            </button>
            <button
              type="button"
              onClick={() => setMapEngine('leaflet')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                mapEngine === 'leaflet' ? 'bg-white text-indigo-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Standard Map
            </button>
          </div>

          <button
            id="btn-toggle-gps-telemetry"
            onClick={toggleGpsTracking}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-xs cursor-pointer ${
              isGpsTrackingActive
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200'
            }`}
          >
            {isGpsTrackingActive ? (
              <>
                <Pause className="w-4 h-4" />
                <span>Pause Live GPS Broadcast</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Start Live GPS Stream</span>
              </>
            )}
          </button>

          <button
            onClick={simulateFleetMovement}
            className="px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            title="Simulate random vehicle movement"
          >
            ⚡ Ping Fleet
          </button>

          <button
            id="btn-add-new-driver"
            onClick={() => setIsAddDriverModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Driver</span>
          </button>
        </div>
      </div>

      {/* Map & Driver List Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Main Column: Interactive Map */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white p-3 rounded-3xl border border-slate-200 shadow-xs">
            {mapEngine === 'google' ? (
              <GoogleMapWrapper fallbackHeight="500px">
                <LiveGoogleFleetMap
                  drivers={drivers}
                  selectedDriverId={selectedDriverId}
                  onSelectDriver={(id) => setSelectedDriverId(id)}
                  height="500px"
                />
              </GoogleMapWrapper>
            ) : (
              <LeafletMap
                drivers={drivers}
                selectedDriverId={selectedDriverId}
                onSelectDriver={(id) => setSelectedDriverId(id)}
                height="500px"
                showAllFleetBounds={true}
              />
            )}
          </div>

          {/* Selected Driver Quick Detail Bar */}
          {selectedDriver && (
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={selectedDriver.photoUrl}
                  alt={selectedDriver.name}
                  className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900">{selectedDriver.name}</h4>
                    <span className="flex items-center gap-0.5 text-xs text-amber-500 font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" /> {selectedDriver.rating}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                    <span>🚗 {selectedDriver.assignedVehicleName} ({selectedDriver.assignedVehiclePlate})</span>
                    <span>•</span>
                    <span className="text-emerald-700 font-medium">📍 {selectedDriver.currentLocationName}</span>
                  </div>
                </div>
              </div>

              {/* Status Toggle Buttons */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                {(['available', 'on_trip', 'break', 'offline'] as DriverStatus[]).map((st) => (
                  <button
                    key={st}
                    onClick={() => updateDriverStatus(selectedDriver.id, st)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
                      selectedDriver.status === st
                        ? 'bg-white text-indigo-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Driver Fleet Roster */}
        <div className="lg:col-span-4 space-y-3 max-h-[570px] overflow-y-auto pr-1">
          <div className="flex items-center justify-between pb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active Fleet Chauffeurs ({drivers.length})
            </span>
            <span className="text-xs text-emerald-600 font-bold">
              {drivers.filter((d) => d.status === 'available').length} Online & Ready
            </span>
          </div>

          <div className="space-y-2.5">
            {drivers.map((drv) => {
              const isSelected = drv.id === selectedDriverId;
              const statusColors = {
                available: 'bg-emerald-100 text-emerald-800 border-emerald-200',
                on_trip: 'bg-blue-100 text-blue-800 border-blue-200',
                break: 'bg-amber-100 text-amber-800 border-amber-200',
                offline: 'bg-slate-100 text-slate-600 border-slate-200',
              }[drv.status];

              return (
                <div
                  key={drv.id}
                  onClick={() => setSelectedDriverId(drv.id)}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/60 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative">
                        <img
                          src={drv.photoUrl}
                          alt={drv.name}
                          className="w-10 h-10 rounded-xl object-cover border border-slate-200"
                          referrerPolicy="no-referrer"
                        />
                        <span
                          className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-white ${
                            drv.status === 'available'
                              ? 'bg-emerald-500'
                              : drv.status === 'on_trip'
                              ? 'bg-blue-500'
                              : drv.status === 'break'
                              ? 'bg-amber-500'
                              : 'bg-slate-400'
                          }`}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">{drv.name}</h4>
                          <span className="text-[10px] text-amber-600 font-bold">★ {drv.rating}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">
                          {drv.assignedVehiclePlate || 'No Cab Assigned'}
                        </p>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border shrink-0 ${statusColors}`}
                    >
                      {drv.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Telemetry Metrics Bar */}
                  <div className="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-600">
                    <div className="flex items-center gap-1">
                      <Zap className="w-3 h-3 text-cyan-500" />
                      <span>{drv.speedKmph} km/h</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Battery className={`w-3 h-3 ${drv.batteryPct < 20 ? 'text-rose-500' : 'text-emerald-500'}`} />
                      <span>{drv.batteryPct}% batt</span>
                    </div>
                    <div className="text-right font-bold text-emerald-700">
                      <span>₹{drv.todayEarnings}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Add New Driver Modal */}
      {isAddDriverModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b pb-4 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Register New Driver</h3>
                  <p className="text-xs text-slate-500">Provide driver details to activate in Firestore fleet.</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddDriverModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDriver} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Driver Full Name *</label>
                <input
                  type="text"
                  required
                  value={newDriverName}
                  onChange={(e) => setNewDriverName(e.target.value)}
                  placeholder="e.g. Rajesh Patil"
                  className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    value={newDriverPhone}
                    onChange={(e) => setNewDriverPhone(e.target.value)}
                    placeholder="+91 98..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">License No.</label>
                  <input
                    type="text"
                    value={newDriverLicense}
                    onChange={(e) => setNewDriverLicense(e.target.value)}
                    placeholder="MH-01202..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assign Fleet Vehicle</label>
                <select
                  value={newDriverVehicleId}
                  onChange={(e) => setNewDriverVehicleId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs sm:text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="">-- Select Available Vehicle --</option>
                  {vehicles.map((veh) => (
                    <option key={veh.id} value={veh.id}>
                      {veh.name} ({veh.plateNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setIsAddDriverModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/30 cursor-pointer"
                >
                  Register & Activate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
