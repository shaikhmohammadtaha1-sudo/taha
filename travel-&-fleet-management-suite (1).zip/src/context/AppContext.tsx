import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  Vehicle,
  Inquiry,
  DeletedInquiry,
  Driver,
  MaintenanceLog,
  TripFinancialRecord,
  DeletedTripFinancialRecord,
  WebsiteCMS,
  InquiryStatus,
  NotInterestedReason,
  DriverStatus,
  AdminTabType,
} from '../types';
import {
  db,
  handleFirestoreError,
  OperationType,
  testFirestoreConnection,
} from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';

interface AppContextType {
  // Navigation & View
  currentView: 'customer' | 'admin' | 'driver';
  setCurrentView: (view: 'customer' | 'admin' | 'driver') => void;
  adminTab: AdminTabType;
  setAdminTab: (tab: AdminTabType) => void;

  // Admin Authentication & Security
  isAdminLoggedIn: boolean;
  adminPassword: string;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  changeAdminPassword: (oldPass: string, newPass: string) => { success: boolean; message: string };

  // Onboarding Tour (Admin only)
  isTourActive: boolean;
  tourStepIndex: number;
  startTour: () => void;
  nextTourStep: () => void;
  prevTourStep: () => void;
  skipTour: () => void;

  // Website CMS State
  cms: WebsiteCMS;
  updateCMS: (newCms: Partial<WebsiteCMS>) => void;
  resetCMSToDefault: () => void;

  // Vehicles & Maintenance
  vehicles: Vehicle[];
  maintenanceLogs: MaintenanceLog[];
  addVehicle: (vehicle: Omit<Vehicle, 'id'>) => void;
  updateVehicle: (id: string, updates: Partial<Vehicle>) => void;
  logMaintenanceService: (log: Omit<MaintenanceLog, 'id'>) => void;
  deleteVehicle: (id: string) => void;

  // Inquiries & CRM
  inquiries: Inquiry[];
  addInquiry: (inq: Omit<Inquiry, 'id' | 'inquiryNumber' | 'createdAt' | 'updatedAt'>) => string;
  updateInquiryStatus: (
    id: string,
    status: InquiryStatus,
    extra?: {
      followupDate?: string;
      followupTime?: string;
      notInterestedReason?: NotInterestedReason;
      notInterestedNotes?: string;
      notes?: string;
      assignedDriverId?: string;
      assignedVehicleId?: string;
    }
  ) => void;
  updateInquiryAdminQuote: (
    id: string,
    updates: {
      totalQuote?: number;
      adminCustomTollFare?: number;
      adminCustomDiscount?: number;
      adminCustomSurcharge?: number;
      adminCustomPerKmRate?: number;
      isQuoteApprovedByAdmin?: boolean;
      status?: InquiryStatus;
      notes?: string;
    }
  ) => void;
  deleteInquiry: (id: string, reason?: string) => void;

  // Dump / Recycle Bin
  deletedInquiries: DeletedInquiry[];
  deletedTrips: DeletedTripFinancialRecord[];
  restoreInquiryFromDump: (id: string) => void;
  permanentlyPurgeInquiry: (id: string) => void;
  restoreTripFromDump: (id: string) => void;
  permanentlyPurgeTrip: (id: string) => void;
  clearAllDump: () => void;

  // Driver Fleet & Live Tracking
  drivers: Driver[];
  selectedDriverId: string;
  setSelectedDriverId: (id: string) => void;
  updateDriverStatus: (id: string, status: DriverStatus) => void;
  updateDriverLocation: (id: string, lat: number, lng: number, locationName?: string, speed?: number) => void;
  addDriver: (driver: Omit<Driver, 'id'>) => void;
  updateDriver: (id: string, updates: Partial<Driver>) => void;

  // Driver Simulation & Real GPS toggle
  isGpsTrackingActive: boolean;
  toggleGpsTracking: () => void;
  simulateFleetMovement: () => void;

  // Financials & Trips
  trips: TripFinancialRecord[];
  addTripRecord: (trip: Omit<TripFinancialRecord, 'id' | 'tripNumber'>) => void;
  bulkImportTrips: (newTrips: TripFinancialRecord[]) => void;
  deleteTripRecord: (id: string, reason?: string) => void;

  // Cloud Firestore Sync State
  isFirestoreConnected: boolean;

  // Notifications / Toast alert helper
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const DEFAULT_CMS: WebsiteCMS = {
  brandName: 'TransVoyage Premium Cabs & Fleet',
  brandTagline: 'Seamless Airport, City & Outstation Journeys with Live Driver Tracking',
  phone: '+91 98200 45678',
  whatsapp: '+91 98200 45678',
  email: 'bookings@transvoyage.com',
  address: 'Terminal 2 Commercial Hub, Chhatrapati Shivaji Maharaj Airport, Mumbai 400099',
  heroHeadline: 'Premium Chauffeur Rides & Transparent Highway Fares',
  heroSubheadline: 'Instant dynamic fare estimation based on verified distance and zero hidden charges. Track your assigned chauffeur in real-time.',
  heroBannerImage: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=1600&q=80',
  promoNotice: '⚡ 15% Off on All Outstation Round Trips this Weekend! Use Code: TRANS15',
  aboutUs: 'TransVoyage operates an executive fleet of sanitized sedans, spacious SUVs, and luxury multi-seaters for corporate travel, family vacations, and swift airport transfers across India.',
  fuelIndexPrice: 94.5,
  defaultTaxPct: 5,
  driverNightAllowanceRate: 250,
  currencySymbol: '₹',
  enableLiveBooking: true,
  legalCompanyName: 'TransVoyage Global Travel Technologies Pvt Ltd',
  copyrightNotice: 'All Rights Reserved.',
  customFooterNote: 'Zero-Code CMS & Real-Time Driver Sync. Registered Transport Operator.',
};

const INITIAL_VEHICLES: Vehicle[] = [
  {
    id: 'veh_hatchback',
    name: 'Hatchback (WagonR, Ritz)',
    subtitleModels: 'WagonR, Ritz, Tiago',
    category: 'hatchback',
    model: 'WagonR ZXi / Ritz Tour',
    plateNumber: 'MH-01-HW-1102',
    seatingCapacity: 4,
    luggageCapacity: 2,
    baseFare: 2050,
    baseKm: 80,
    ratePerKm: 12,
    localBaseFare8hr80km: 2050,
    localExtraKmRate: 12,
    localExtraHrRate: 100,
    outstationPerKmRate: 12,
    outstationMinKmPerDay: 250,
    driverAllowancePerDay: 300,
    fuelType: 'cng',
    fuelEfficiencyKmPerL: 26,
    ownershipType: 'company_owned',
    currentOdometerKm: 34200,
    lastServiceKm: 30000,
    serviceIntervalKm: 10000,
    insuranceExpiry: '2027-03-15',
    fitnessExpiry: '2028-04-20',
    status: 'active',
    driverId: 'drv_1',
    driverName: 'Ramesh Kumar',
    imageUrl: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=600&q=80',
    features: ['Affordable AC Cabs', 'Clean Interiors', 'Fastag Enabled', 'Luggage Carrier'],
    acType: 'AC',
  },
  {
    id: 'veh_sedan',
    name: 'Prime Sedan (Dzire, Etios)',
    subtitleModels: 'Dzire, Etios, Sunny, Aura',
    category: 'sedan',
    model: 'Dzire Prime / Etios Platinum',
    plateNumber: 'MH-01-EA-4412',
    seatingCapacity: 4,
    luggageCapacity: 3,
    baseFare: 2250,
    baseKm: 80,
    ratePerKm: 13.5,
    localBaseFare8hr80km: 2250,
    localExtraKmRate: 13,
    localExtraHrRate: 110,
    outstationPerKmRate: 13.5,
    outstationMinKmPerDay: 250,
    driverAllowancePerDay: 350,
    fuelType: 'cng',
    fuelEfficiencyKmPerL: 24,
    ownershipType: 'company_owned',
    currentOdometerKm: 38400,
    lastServiceKm: 30000,
    serviceIntervalKm: 10000,
    insuranceExpiry: '2027-03-15',
    fitnessExpiry: '2028-04-20',
    status: 'active',
    driverId: 'drv_2',
    driverName: 'Vikram Singh',
    imageUrl: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=600&q=80',
    features: ['Comfortable Sedans', 'Extra Legroom', 'Chilled AC', 'Bluetooth Music'],
    acType: 'AC',
  },
  {
    id: 'veh_suv',
    name: 'Prime SUV (Ertiga)',
    subtitleModels: 'Enjoy, Ertiga, Triber',
    category: 'suv',
    model: 'Ertiga ZXi Plus 7-Seater',
    plateNumber: 'MH-12-ER-5533',
    seatingCapacity: 6,
    luggageCapacity: 4,
    baseFare: 2900,
    baseKm: 80,
    ratePerKm: 15.5,
    localBaseFare8hr80km: 2900,
    localExtraKmRate: 15.5,
    localExtraHrRate: 145,
    outstationPerKmRate: 15.5,
    outstationMinKmPerDay: 250,
    driverAllowancePerDay: 400,
    fuelType: 'cng',
    fuelEfficiencyKmPerL: 20,
    ownershipType: 'company_owned',
    currentOdometerKm: 42100,
    lastServiceKm: 40000,
    serviceIntervalKm: 10000,
    insuranceExpiry: '2027-05-18',
    fitnessExpiry: '2028-06-22',
    status: 'active',
    driverId: 'drv_3',
    driverName: 'Mohammed Imran',
    imageUrl: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=600&q=80',
    features: ['Spacious Group Travel', 'Dual AC', 'Rear USB Charging', 'Highway Comfort'],
    acType: 'AC',
  },
  {
    id: 'veh_luxury_suv',
    name: 'Luxury SUV (Innova / Crysta)',
    subtitleModels: 'Innova, Crysta, Hycross',
    category: 'suv',
    model: 'Innova Crysta 2.4 ZX Automatic',
    plateNumber: 'MH-02-CZ-9988',
    seatingCapacity: 7,
    luggageCapacity: 5,
    baseFare: 3600,
    baseKm: 80,
    ratePerKm: 19,
    localBaseFare8hr80km: 3600,
    localExtraKmRate: 19,
    localExtraHrRate: 190,
    outstationPerKmRate: 19,
    outstationMinKmPerDay: 300,
    driverAllowancePerDay: 500,
    fuelType: 'diesel',
    fuelEfficiencyKmPerL: 13,
    ownershipType: 'company_owned',
    currentOdometerKm: 49750,
    lastServiceKm: 40000,
    serviceIntervalKm: 10000,
    insuranceExpiry: '2027-01-10',
    fitnessExpiry: '2028-02-14',
    status: 'active',
    driverId: 'drv_4',
    driverName: 'Suresh Nair',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=600&q=80',
    features: ['Captain Recliner Seats', 'Dual Climate AC', 'Smooth Highway Ride', 'Premium Interiors'],
    acType: 'AC',
  },
  {
    id: 'veh_luxury_sedan',
    name: 'Luxury Sedan (BMW, Merc, Audi)',
    subtitleModels: 'BMW 5 Series, Mercedes E-Class, Audi A6',
    category: 'luxury',
    model: 'Mercedes-Benz E-Class Exclusive',
    plateNumber: 'MH-01-LX-0007',
    seatingCapacity: 4,
    luggageCapacity: 3,
    baseFare: 7250,
    baseKm: 80,
    ratePerKm: 50,
    localBaseFare8hr80km: 7250,
    localExtraKmRate: 48,
    localExtraHrRate: 450,
    outstationPerKmRate: 50,
    outstationMinKmPerDay: 300,
    driverAllowancePerDay: 1000,
    fuelType: 'diesel',
    fuelEfficiencyKmPerL: 14,
    ownershipType: 'partner_attached',
    currentOdometerKm: 31200,
    lastServiceKm: 30000,
    serviceIntervalKm: 15000,
    insuranceExpiry: '2027-09-12',
    fitnessExpiry: '2029-01-15',
    status: 'active',
    driverName: 'Executive Chauffeur',
    imageUrl: 'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=600&q=80',
    features: ['Chauffeur in Uniform', 'Panoramic Sunroof', 'Burmester Audio', 'Mineral Water & Mints'],
    acType: 'AC',
  },
  {
    id: 'veh_tempo',
    name: 'Tempo Traveller (12-Seater)',
    subtitleModels: 'Force Urbania / Traveller 12-17 Seater',
    category: 'tempo_traveller',
    model: 'Urbania 12-17 Seater Monocoque',
    plateNumber: 'MH-03-TR-7711',
    seatingCapacity: 12,
    luggageCapacity: 12,
    baseFare: 5750,
    baseKm: 80,
    ratePerKm: 26.5,
    localBaseFare8hr80km: 5750,
    localExtraKmRate: 25,
    localExtraHrRate: 250,
    outstationPerKmRate: 26.5,
    outstationMinKmPerDay: 300,
    driverAllowancePerDay: 500,
    fuelType: 'diesel',
    fuelEfficiencyKmPerL: 8.5,
    ownershipType: 'company_owned',
    currentOdometerKm: 55200,
    lastServiceKm: 50000,
    serviceIntervalKm: 10000,
    insuranceExpiry: '2027-06-25',
    fitnessExpiry: '2028-08-30',
    status: 'active',
    driverName: 'Senior Highway Captain',
    imageUrl: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=600&q=80',
    features: ['12 Push-Back Seats', 'Individual AC Vents', 'Ambient Roof Lights', 'PA Mic & Sound'],
    acType: 'AC',
  },
];

const INITIAL_DRIVERS: Driver[] = [
  {
    id: 'drv_1',
    name: 'Ramesh Kumar',
    phone: '+91 98201 12345',
    licenseNumber: 'MH-0120150048123',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    rating: 4.9,
    status: 'available',
    assignedVehicleId: 'veh_sedan',
    assignedVehicleName: 'Maruti Suzuki Dzire',
    assignedVehiclePlate: 'MH-01-EA-4412',
    currentLat: 19.076,
    currentLng: 72.8777,
    currentLocationName: 'Bandra Kurla Complex (BKC), Mumbai',
    lastPingTime: '1 min ago',
    batteryPct: 92,
    speedKmph: 34,
    todayEarnings: 2450,
    todayTrips: 3,
    totalCompletedTrips: 482,
  },
  {
    id: 'drv_2',
    name: 'Vikram Singh',
    phone: '+91 98332 98765',
    licenseNumber: 'MH-0220180091234',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    rating: 4.8,
    status: 'on_trip',
    assignedVehicleId: 'veh_luxury_suv',
    assignedVehicleName: 'Toyota Innova Crysta',
    assignedVehiclePlate: 'MH-02-CZ-9988',
    currentLat: 18.922,
    currentLng: 72.8347,
    currentLocationName: 'Gateway of India, Colaba',
    lastPingTime: 'Just now',
    batteryPct: 84,
    speedKmph: 45,
    todayEarnings: 4200,
    todayTrips: 2,
    totalCompletedTrips: 620,
  },
  {
    id: 'drv_3',
    name: 'Mohammed Imran',
    phone: '+91 98920 44556',
    licenseNumber: 'MH-1220200031122',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
    rating: 4.7,
    status: 'available',
    assignedVehicleId: 'veh_suv',
    assignedVehicleName: 'Ertiga 7-Seater',
    assignedVehiclePlate: 'MH-12-ER-5533',
    currentLat: 19.1136,
    currentLng: 72.8697,
    currentLocationName: 'Andheri East SEEPZ Hub',
    lastPingTime: '2 mins ago',
    batteryPct: 76,
    speedKmph: 0,
    todayEarnings: 1800,
    todayTrips: 2,
    totalCompletedTrips: 340,
  },
  {
    id: 'drv_4',
    name: 'Suresh Nair',
    phone: '+91 97654 22110',
    licenseNumber: 'MH-0320140019283',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
    rating: 4.95,
    status: 'available',
    assignedVehicleId: 'veh_tempo',
    assignedVehicleName: 'Force Urbania Luxury',
    assignedVehiclePlate: 'MH-03-TR-7711',
    currentLat: 19.2183,
    currentLng: 72.9781,
    currentLocationName: 'Thane Majiwada Junction',
    lastPingTime: '4 mins ago',
    batteryPct: 65,
    speedKmph: 22,
    todayEarnings: 6500,
    todayTrips: 1,
    totalCompletedTrips: 810,
  },
];

const INITIAL_INQUIRIES: Inquiry[] = [
  {
    id: 'inq_1082',
    inquiryNumber: 'INQ-1082',
    customerName: 'Ananya Sharma',
    phone: '+91 98200 87654',
    email: 'ananya.s@enterprise.com',
    pickupLocation: 'Mumbai Airport Terminal 2',
    dropLocation: 'Pune Koregaon Park',
    tripType: 'one_way',
    pickupDate: '2026-08-20',
    pickupTime: '08:30',
    passengers: 2,
    vehicleId: 'veh_sedan',
    vehicleName: 'Prime Sedan (Dzire, Etios)',
    estimatedDistanceKm: 155,
    estimatedDurationHrs: 3.2,
    calculatedBaseFare: 2092,
    estimatedFuelCost: 610,
    estimatedTolls: 380,
    driverAllowance: 350,
    nightCharges: 0,
    taxAmount: 141,
    totalQuote: 2963,
    status: 'new',
    notes: 'Airport executive pickup. Needs placard greeting with company logo.',
    createdAt: '2026-08-19 10:15 AM',
    updatedAt: '2026-08-19 10:15 AM',
  },
  {
    id: 'inq_1083',
    inquiryNumber: 'INQ-1083',
    customerName: 'Sunil Mehta',
    phone: '+91 98450 11223',
    email: 'sunil.mehta@fintech.io',
    pickupLocation: 'South Mumbai Nariman Point',
    dropLocation: 'Lonavala Khandala',
    tripType: 'round_trip',
    pickupDate: '2026-08-19',
    pickupTime: '11:00',
    returnDate: '2026-08-19',
    returnTime: '22:30',
    passengers: 3,
    vehicleId: 'veh_luxury_suv',
    vehicleName: 'Luxury SUV (Innova / Crysta)',
    estimatedDistanceKm: 210,
    estimatedDurationHrs: 5.5,
    calculatedBaseFare: 5700,
    estimatedFuelCost: 1590,
    estimatedTolls: 420,
    driverAllowance: 500,
    nightCharges: 250,
    taxAmount: 343,
    totalQuote: 7213,
    status: 'confirmed',
    assignedDriverId: 'drv_2',
    assignedVehicleId: 'veh_luxury_suv',
    notes: 'Confirmed booking. Driver Vikram Singh en route to pickup.',
    createdAt: '2026-08-18 04:20 PM',
    updatedAt: '2026-08-19 10:00 AM',
  },
];

const INITIAL_DELETED_INQUIRIES: DeletedInquiry[] = [
  {
    id: 'inq_dump_1079',
    inquiryNumber: 'INQ-1079',
    customerName: 'Kunal Deshmukh',
    phone: '+91 98199 55443',
    email: 'kunal.d@travelcorp.in',
    pickupLocation: 'Mumbai Domestic Airport T1',
    dropLocation: 'Alibaug Mandwa Jetty',
    tripType: 'round_trip',
    pickupDate: '2026-08-16',
    pickupTime: '06:00',
    returnDate: '2026-08-17',
    returnTime: '19:00',
    passengers: 4,
    vehicleId: 'veh_suv',
    vehicleName: 'Prime SUV (Ertiga)',
    estimatedDistanceKm: 220,
    estimatedDurationHrs: 5.0,
    calculatedBaseFare: 2900,
    estimatedFuelCost: 1100,
    estimatedTolls: 360,
    driverAllowance: 800,
    nightCharges: 0,
    taxAmount: 258,
    totalQuote: 5418,
    status: 'cancelled',
    notes: 'Customer postponed trip due to heavy monsoon rain forecast.',
    createdAt: '2026-08-15 09:30 AM',
    updatedAt: '2026-08-16 07:00 AM',
    deletedAt: '2026-08-17 11:20 AM',
    deletedBy: 'Admin (Master)',
    deleteReason: 'Customer requested cancellation & moved to dump archive',
  },
];

const INITIAL_TRIPS: TripFinancialRecord[] = [
  {
    id: 'trp_101',
    tripNumber: 'TRP-8412',
    date: '2026-08-18',
    customerName: 'Deloitte India Corporate',
    vehiclePlate: 'MH-02-CZ-9988',
    driverName: 'Vikram Singh',
    pickupLocation: 'BKC, Mumbai',
    dropLocation: 'Pune Magarpatta City',
    distanceKm: 160,
    revenue: 5200,
    fuelExpense: 1210,
    tollExpense: 380,
    driverPayout: 1200,
    maintenanceAllocated: 240,
    otherExpense: 100,
    netProfit: 2070,
    paymentStatus: 'paid',
  },
  {
    id: 'trp_102',
    tripNumber: 'TRP-8413',
    date: '2026-08-18',
    customerName: 'Pooja Agarwal',
    vehiclePlate: 'MH-01-EA-4412',
    driverName: 'Ramesh Kumar',
    pickupLocation: 'Andheri West',
    dropLocation: 'Navi Mumbai Airport site',
    distanceKm: 65,
    revenue: 2100,
    fuelExpense: 255,
    tollExpense: 110,
    driverPayout: 650,
    maintenanceAllocated: 95,
    otherExpense: 40,
    netProfit: 950,
    paymentStatus: 'paid',
  },
];

const INITIAL_DELETED_TRIPS: DeletedTripFinancialRecord[] = [
  {
    id: 'trp_dump_99',
    tripNumber: 'TRP-8390',
    date: '2026-08-14',
    customerName: 'Accenture Mobility Team',
    vehiclePlate: 'MH-02-CZ-9988',
    driverName: 'Vikram Singh',
    pickupLocation: 'Powai Hiranandani',
    dropLocation: 'Vashi Sector 17',
    distanceKm: 42,
    revenue: 1650,
    fuelExpense: 190,
    tollExpense: 90,
    driverPayout: 500,
    maintenanceAllocated: 60,
    otherExpense: 30,
    netProfit: 780,
    paymentStatus: 'paid',
    deletedAt: '2026-08-15 02:30 PM',
    deletedBy: 'Admin (Master)',
    deleteReason: 'Duplicate invoice entry created in error',
  },
];

const INITIAL_MAINTENANCE: MaintenanceLog[] = [
  {
    id: 'maint_1',
    vehicleId: 'veh_luxury_suv',
    vehicleName: 'Toyota Innova Crysta ZX',
    plateNumber: 'MH-02-CZ-9988',
    serviceDate: '2026-05-10',
    odometerKmAtService: 40000,
    serviceType: 'routine_oil_filter',
    cost: 5400,
    garageName: 'Shinrai Toyota Authorized Service, Mumbai',
    notes: 'Engine synthetic oil change, air filter replacement, wheel alignment & brake checkup.',
    nextServiceDueKm: 50000,
  },
  {
    id: 'maint_2',
    vehicleId: 'veh_sedan',
    vehicleName: 'Maruti Suzuki Dzire Prime',
    plateNumber: 'MH-01-EA-4412',
    serviceDate: '2026-06-15',
    odometerKmAtService: 30000,
    serviceType: 'general_checkup',
    cost: 3200,
    garageName: 'Sai Service Maruti Center, Andheri',
    notes: '30,000 KM major maintenance: coolant flush, spark plug cleaning, AC filter disinfection.',
    nextServiceDueKm: 40000,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const loadStored = <T,>(key: string, defaultVal: T): T => {
    try {
      const item = localStorage.getItem(`transvoyage_${key}`);
      return item ? JSON.parse(item) : defaultVal;
    } catch {
      return defaultVal;
    }
  };

  const saveStored = (key: string, val: any) => {
    try {
      localStorage.setItem(`transvoyage_${key}`, JSON.stringify(val));
    } catch {}
  };

  const [currentView, setCurrentView] = useState<'customer' | 'admin' | 'driver'>('customer');
  const [adminTab, setAdminTab] = useState<AdminTabType>('analytics');

  // Admin Auth State: password default 'Taha@2723', session starts unauthenticated
  const [adminPassword, setAdminPassword] = useState<string>(() => {
    const saved = localStorage.getItem('transvoyage_admin_pass');
    return saved || 'Taha@2723';
  });

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem('transvoyage_admin_auth') === 'true';
  });

  // Tour State
  const [isTourActive, setIsTourActive] = useState<boolean>(false);
  const [tourStepIndex, setTourStepIndex] = useState<number>(0);

  // CMS State
  const [cms, setCms] = useState<WebsiteCMS>(() => loadStored('cms', DEFAULT_CMS));

  // Data Collections
  const [vehicles, setVehicles] = useState<Vehicle[]>(() => loadStored('vehicles', INITIAL_VEHICLES));
  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>(() => loadStored('maintenance', INITIAL_MAINTENANCE));
  const [inquiries, setInquiries] = useState<Inquiry[]>(() => loadStored('inquiries', INITIAL_INQUIRIES));
  const [deletedInquiries, setDeletedInquiries] = useState<DeletedInquiry[]>(() => loadStored('deleted_inquiries', INITIAL_DELETED_INQUIRIES));
  const [drivers, setDrivers] = useState<Driver[]>(() => loadStored('drivers', INITIAL_DRIVERS));
  const [trips, setTrips] = useState<TripFinancialRecord[]>(() => loadStored('trips', INITIAL_TRIPS));
  const [deletedTrips, setDeletedTrips] = useState<DeletedTripFinancialRecord[]>(() => loadStored('deleted_trips', INITIAL_DELETED_TRIPS));

  const [selectedDriverId, setSelectedDriverId] = useState<string>('drv_1');
  const [isGpsTrackingActive, setIsGpsTrackingActive] = useState<boolean>(false);
  const [isFirestoreConnected, setIsFirestoreConnected] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  }, []);

  // Admin Login Handler
  const loginAdmin = useCallback(
    (enteredPass: string): boolean => {
      if (enteredPass === adminPassword) {
        setIsAdminLoggedIn(true);
        sessionStorage.setItem('transvoyage_admin_auth', 'true');
        showToast('🔓 Administrator logged in successfully!');
        return true;
      }
      showToast('❌ Incorrect Admin Password. Access Denied.');
      return false;
    },
    [adminPassword, showToast]
  );

  // Admin Logout Handler
  const logoutAdmin = useCallback(() => {
    setIsAdminLoggedIn(false);
    sessionStorage.removeItem('transvoyage_admin_auth');
    setCurrentView('customer');
    showToast('🔒 Administrator logged out.');
  }, [showToast]);

  // Change Admin Password
  const changeAdminPassword = useCallback(
    (oldPass: string, newPass: string): { success: boolean; message: string } => {
      if (oldPass !== adminPassword) {
        return { success: false, message: 'Current password does not match.' };
      }
      if (!newPass || newPass.trim().length < 4) {
        return { success: false, message: 'New password must be at least 4 characters long.' };
      }
      const trimmed = newPass.trim();
      setAdminPassword(trimmed);
      localStorage.setItem('transvoyage_admin_pass', trimmed);
      showToast('🔑 Admin password updated successfully!');
      return { success: true, message: 'Password updated successfully!' };
    },
    [adminPassword, showToast]
  );

  // Check Firestore connection and setup real-time listeners
  useEffect(() => {
    testFirestoreConnection().then((connected) => {
      setIsFirestoreConnected(connected);
    });

    // 1. Inquiries real-time listener
    const unsubInquiries = onSnapshot(
      collection(db, 'inquiries'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Inquiry[] = [];
          snapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...(docSnap.data() as any) });
          });
          setInquiries(list);
          saveStored('inquiries', list);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'inquiries');
      }
    );

    // 2. Drivers real-time listener
    const unsubDrivers = onSnapshot(
      collection(db, 'drivers'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Driver[] = [];
          snapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...(docSnap.data() as any) });
          });
          setDrivers(list);
          saveStored('drivers', list);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'drivers');
      }
    );

    // 3. Vehicles real-time listener
    const unsubVehicles = onSnapshot(
      collection(db, 'vehicles'),
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Vehicle[] = [];
          snapshot.forEach((docSnap) => {
            list.push({ id: docSnap.id, ...(docSnap.data() as any) });
          });
          setVehicles(list);
          saveStored('vehicles', list);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'vehicles');
      }
    );

    // 4. CMS real-time listener
    const unsubCms = onSnapshot(
      doc(db, 'cms', 'main_config'),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data() as WebsiteCMS;
          setCms(data);
          saveStored('cms', data);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'cms/main_config');
      }
    );

    return () => {
      unsubInquiries();
      unsubDrivers();
      unsubVehicles();
      unsubCms();
    };
  }, []);

  // Update CMS
  const updateCMS = useCallback(
    async (newCms: Partial<WebsiteCMS>) => {
      const merged = { ...cms, ...newCms };
      setCms(merged);
      saveStored('cms', merged);
      showToast('Website content updated successfully! Reflected live.');

      try {
        await setDoc(doc(db, 'cms', 'main_config'), merged, { merge: true });
      } catch (err) {
        console.warn('Firestore CMS sync note:', err);
      }
    },
    [cms, showToast]
  );

  const resetCMSToDefault = useCallback(async () => {
    setCms(DEFAULT_CMS);
    saveStored('cms', DEFAULT_CMS);
    showToast('CMS Reset to default theme settings.');

    try {
      await setDoc(doc(db, 'cms', 'main_config'), DEFAULT_CMS);
    } catch (err) {
      console.warn('Firestore CMS reset note:', err);
    }
  }, [showToast]);

  // Vehicle actions
  const addVehicle = useCallback(
    async (v: Omit<Vehicle, 'id'>) => {
      const newId = `veh_${Date.now()}`;
      const newVeh: Vehicle = { id: newId, ...v };
      setVehicles((prev) => {
        const next = [newVeh, ...prev];
        saveStored('vehicles', next);
        return next;
      });
      showToast(`Vehicle ${newVeh.name} (${newVeh.plateNumber}) added to fleet!`);

      try {
        await setDoc(doc(db, 'vehicles', newId), newVeh);
      } catch (err) {
        console.warn('Firestore vehicle sync note:', err);
      }
    },
    [showToast]
  );

  const updateVehicle = useCallback(
    async (id: string, updates: Partial<Vehicle>) => {
      setVehicles((prev) => {
        const next = prev.map((v) => (v.id === id ? { ...v, ...updates } : v));
        saveStored('vehicles', next);
        return next;
      });
      showToast('Vehicle details updated.');

      try {
        await updateDoc(doc(db, 'vehicles', id), updates);
      } catch (err) {
        console.warn('Firestore vehicle update note:', err);
      }
    },
    [showToast]
  );

  const deleteVehicle = useCallback(
    async (id: string) => {
      setVehicles((prev) => {
        const next = prev.filter((v) => v.id !== id);
        saveStored('vehicles', next);
        return next;
      });
      showToast('Vehicle removed from fleet database.');

      try {
        await deleteDoc(doc(db, 'vehicles', id));
      } catch (err) {
        console.warn('Firestore vehicle delete note:', err);
      }
    },
    [showToast]
  );

  const logMaintenanceService = useCallback(
    async (logData: Omit<MaintenanceLog, 'id'>) => {
      const newLogId = `maint_${Date.now()}`;
      const newLog: MaintenanceLog = { id: newLogId, ...logData };

      setMaintenanceLogs((prev) => {
        const next = [newLog, ...prev];
        saveStored('maintenance', next);
        return next;
      });

      // Update vehicle's last service odometer
      setVehicles((prev) => {
        const next = prev.map((v) =>
          v.id === logData.vehicleId
            ? {
                ...v,
                lastServiceKm: logData.odometerKmAtService,
                status: 'active' as const,
              }
            : v
        );
        saveStored('vehicles', next);
        return next;
      });

      showToast(`Workshop service of ₹${logData.cost} recorded. 10,000 KM counter reset.`);

      try {
        await setDoc(doc(db, 'maintenance_logs', newLogId), newLog);
        await updateDoc(doc(db, 'vehicles', logData.vehicleId), {
          lastServiceKm: logData.odometerKmAtService,
          status: 'active',
        });
      } catch (err) {
        console.warn('Firestore maintenance sync note:', err);
      }
    },
    [showToast]
  );

  // Inquiries CRM
  const addInquiry = useCallback(
    (inqData: Omit<Inquiry, 'id' | 'inquiryNumber' | 'createdAt' | 'updatedAt'>): string => {
      const newId = `inq_${Date.now()}`;
      const inqNumber = `INQ-${Math.floor(1000 + Math.random() * 9000)}`;
      const timestamp = new Date().toLocaleString();

      const newInq: Inquiry = {
        id: newId,
        inquiryNumber: inqNumber,
        createdAt: timestamp,
        updatedAt: timestamp,
        ...inqData,
      };

      setInquiries((prev) => {
        const next = [newInq, ...prev];
        saveStored('inquiries', next);
        return next;
      });

      showToast(`🎉 Booking Inquiry ${inqNumber} submitted successfully!`);

      // Write to Firestore
      setDoc(doc(db, 'inquiries', newId), newInq).catch((err) => {
        console.warn('Firestore inquiry sync note:', err);
      });

      return newId;
    },
    [showToast]
  );

  const updateInquiryStatus = useCallback(
    async (
      id: string,
      status: InquiryStatus,
      extra?: {
        followupDate?: string;
        followupTime?: string;
        notInterestedReason?: NotInterestedReason;
        notInterestedNotes?: string;
        notes?: string;
        assignedDriverId?: string;
        assignedVehicleId?: string;
      }
    ) => {
      const timestamp = new Date().toLocaleString();
      const updates = {
        status,
        updatedAt: timestamp,
        ...extra,
      };

      setInquiries((prev) => {
        const next = prev.map((inq) => (inq.id === id ? { ...inq, ...updates } : inq));
        saveStored('inquiries', next);
        return next;
      });

      showToast(`Inquiry status updated to "${status.toUpperCase()}"!`);

      try {
        await updateDoc(doc(db, 'inquiries', id), updates);
      } catch (err) {
        console.warn('Firestore inquiry update note:', err);
      }
    },
    [showToast]
  );

  // Admin Custom Quote & Toll updates
  const updateInquiryAdminQuote = useCallback(
    async (
      id: string,
      updates: {
        totalQuote?: number;
        adminCustomTollFare?: number;
        adminCustomDiscount?: number;
        adminCustomSurcharge?: number;
        adminCustomPerKmRate?: number;
        isQuoteApprovedByAdmin?: boolean;
        status?: InquiryStatus;
        notes?: string;
      }
    ) => {
      const timestamp = new Date().toLocaleString();
      const updatedFields = {
        ...updates,
        updatedAt: timestamp,
      };

      setInquiries((prev) => {
        const next = prev.map((inq) => (inq.id === id ? { ...inq, ...updatedFields } : inq));
        saveStored('inquiries', next);
        return next;
      });

      showToast('✅ Admin quote & toll pricing updated and saved!');

      try {
        await updateDoc(doc(db, 'inquiries', id), updatedFields);
      } catch (err) {
        console.warn('Firestore inquiry quote update note:', err);
      }
    },
    [showToast]
  );

  // Move Inquiry to Dump / Trash (Soft-Delete)
  const deleteInquiry = useCallback(
    async (id: string, reason?: string) => {
      const inqToDelete = inquiries.find((i) => i.id === id);
      if (!inqToDelete) return;

      const deletedItem: DeletedInquiry = {
        ...inqToDelete,
        deletedAt: new Date().toLocaleString(),
        deletedBy: 'Admin (Master)',
        deleteReason: reason || 'Deleted by Administrator',
      };

      // 1. Add to Dump
      setDeletedInquiries((prev) => {
        const next = [deletedItem, ...prev];
        saveStored('deleted_inquiries', next);
        return next;
      });

      // 2. Remove from active inquiries
      setInquiries((prev) => {
        const next = prev.filter((i) => i.id !== id);
        saveStored('inquiries', next);
        return next;
      });

      showToast(`🗑️ Inquiry ${inqToDelete.inquiryNumber} moved to Dump (Recycle Bin).`);

      try {
        await setDoc(doc(db, 'deleted_inquiries', id), deletedItem);
        await deleteDoc(doc(db, 'inquiries', id));
      } catch (err) {
        console.warn('Firestore inquiry dump sync note:', err);
      }
    },
    [inquiries, showToast]
  );

  // Restore Inquiry from Dump
  const restoreInquiryFromDump = useCallback(
    async (id: string) => {
      const itemToRestore = deletedInquiries.find((i) => i.id === id);
      if (!itemToRestore) return;

      const { deletedAt, deletedBy, deleteReason, ...restoredInq } = itemToRestore;
      restoredInq.updatedAt = new Date().toLocaleString();

      // 1. Remove from Dump
      setDeletedInquiries((prev) => {
        const next = prev.filter((i) => i.id !== id);
        saveStored('deleted_inquiries', next);
        return next;
      });

      // 2. Add back to Active Inquiries
      setInquiries((prev) => {
        const next = [restoredInq, ...prev];
        saveStored('inquiries', next);
        return next;
      });

      showToast(`♻️ Inquiry ${restoredInq.inquiryNumber} restored to active CRM pipeline!`);

      try {
        await setDoc(doc(db, 'inquiries', id), restoredInq);
        await deleteDoc(doc(db, 'deleted_inquiries', id));
      } catch (err) {
        console.warn('Firestore inquiry restore note:', err);
      }
    },
    [deletedInquiries, showToast]
  );

  // Permanently Purge Inquiry from Dump
  const permanentlyPurgeInquiry = useCallback(
    async (id: string) => {
      setDeletedInquiries((prev) => {
        const next = prev.filter((i) => i.id !== id);
        saveStored('deleted_inquiries', next);
        return next;
      });
      showToast('⚠️ Inquiry permanently deleted from database.');

      try {
        await deleteDoc(doc(db, 'deleted_inquiries', id));
      } catch (err) {
        console.warn('Firestore permanent purge note:', err);
      }
    },
    [showToast]
  );

  // Clear All Dump Items
  const clearAllDump = useCallback(async () => {
    setDeletedInquiries([]);
    setDeletedTrips([]);
    saveStored('deleted_inquiries', []);
    saveStored('deleted_trips', []);
    showToast('🧹 Recycle Dump cleared completely.');
  }, [showToast]);

  // Driver Fleet & Tracking
  const updateDriverStatus = useCallback(
    async (id: string, status: DriverStatus) => {
      setDrivers((prev) => {
        const next = prev.map((d) => (d.id === id ? { ...d, status, lastPingTime: 'Just now' } : d));
        saveStored('drivers', next);
        return next;
      });
      showToast(`Driver status set to ${status.toUpperCase()}`);

      try {
        await updateDoc(doc(db, 'drivers', id), { status, lastPingTime: 'Just now' });
      } catch (err) {
        console.warn('Firestore driver status note:', err);
      }
    },
    [showToast]
  );

  const updateDriverLocation = useCallback(
    async (id: string, lat: number, lng: number, locationName?: string, speed?: number) => {
      const updates = {
        currentLat: lat,
        currentLng: lng,
        currentLocationName: locationName || 'En route on highway',
        speedKmph: speed !== undefined ? speed : Math.floor(25 + Math.random() * 45),
        lastPingTime: 'Just now',
      };

      setDrivers((prev) => {
        const next = prev.map((d) => (d.id === id ? { ...d, ...updates } : d));
        saveStored('drivers', next);
        return next;
      });

      try {
        await updateDoc(doc(db, 'drivers', id), updates);
      } catch (err) {
        // Silent update for high frequency telemetry
      }
    },
    []
  );

  const addDriver = useCallback(
    async (driverData: Omit<Driver, 'id'>) => {
      const newId = `drv_${Date.now()}`;
      const newDrv: Driver = { id: newId, ...driverData };
      setDrivers((prev) => {
        const next = [newDrv, ...prev];
        saveStored('drivers', next);
        return next;
      });
      showToast(`Driver ${newDrv.name} registered and activated!`);

      try {
        await setDoc(doc(db, 'drivers', newId), newDrv);
      } catch (err) {
        console.warn('Firestore driver add note:', err);
      }
    },
    [showToast]
  );

  const updateDriver = useCallback(
    async (id: string, updates: Partial<Driver>) => {
      setDrivers((prev) => {
        const next = prev.map((d) => (d.id === id ? { ...d, ...updates } : d));
        saveStored('drivers', next);
        return next;
      });

      try {
        await updateDoc(doc(db, 'drivers', id), updates);
      } catch (err) {
        console.warn('Firestore driver update note:', err);
      }
    },
    []
  );

  // Toggle GPS
  const toggleGpsTracking = useCallback(() => {
    setIsGpsTrackingActive((prev) => {
      const next = !prev;
      showToast(next ? '📡 Real-time GPS Telemetry Stream Started!' : '⏸ GPS Tracking Stream Paused');
      return next;
    });
  }, [showToast]);

  // Simulate movement
  const simulateFleetMovement = useCallback(() => {
    setDrivers((prev) => {
      const updated = prev.map((driver) => {
        if (driver.status === 'offline') return driver;
        const latDelta = (Math.random() - 0.5) * 0.008;
        const lngDelta = (Math.random() - 0.5) * 0.008;
        const newSpeed = driver.status === 'break' ? 0 : Math.floor(30 + Math.random() * 50);

        return {
          ...driver,
          currentLat: driver.currentLat + latDelta,
          currentLng: driver.currentLng + lngDelta,
          speedKmph: newSpeed,
          lastPingTime: 'Just now',
          batteryPct: Math.max(12, driver.batteryPct - (Math.random() > 0.8 ? 1 : 0)),
        };
      });
      saveStored('drivers', updated);
      return updated;
    });
    showToast('🚗 Fleet GPS coordinates shifted dynamically on live Google Map!');
  }, [showToast]);

  // Financials
  const addTripRecord = useCallback(
    async (tripData: Omit<TripFinancialRecord, 'id' | 'tripNumber'>) => {
      const newId = `trp_${Date.now()}`;
      const tripNumber = `TRP-${Math.floor(1000 + Math.random() * 9000)}`;
      const newTrip: TripFinancialRecord = { id: newId, tripNumber, ...tripData };

      setTrips((prev) => {
        const next = [newTrip, ...prev];
        saveStored('trips', next);
        return next;
      });
      showToast(`Trip ${tripNumber} recorded with Net Profit ₹${newTrip.netProfit}`);

      try {
        await setDoc(doc(db, 'financials', newId), newTrip);
      } catch (err) {
        console.warn('Firestore financial record sync note:', err);
      }
    },
    [showToast]
  );

  const bulkImportTrips = useCallback(
    async (newTrips: TripFinancialRecord[]) => {
      setTrips((prev) => {
        const next = [...newTrips, ...prev];
        saveStored('trips', next);
        return next;
      });
      showToast(`✅ Successfully imported ${newTrips.length} Excel financial records to ledger!`);

      // Push to Firestore
      for (const trip of newTrips) {
        setDoc(doc(db, 'financials', trip.id), trip).catch(() => {});
      }
    },
    [showToast]
  );

  const deleteTripRecord = useCallback(
    async (id: string, reason?: string) => {
      const tripToDelete = trips.find((t) => t.id === id);
      if (!tripToDelete) return;

      const deletedTripItem: DeletedTripFinancialRecord = {
        ...tripToDelete,
        deletedAt: new Date().toLocaleString(),
        deletedBy: 'Admin (Master)',
        deleteReason: reason || 'Deleted by Administrator',
      };

      // 1. Move to deletedTrips dump
      setDeletedTrips((prev) => {
        const next = [deletedTripItem, ...prev];
        saveStored('deleted_trips', next);
        return next;
      });

      // 2. Remove from active trips
      setTrips((prev) => {
        const next = prev.filter((t) => t.id !== id);
        saveStored('trips', next);
        return next;
      });

      showToast(`🗑️ Trip ${tripToDelete.tripNumber} moved to Dump (Recycle Bin).`);

      try {
        await setDoc(doc(db, 'deleted_financials', id), deletedTripItem);
        await deleteDoc(doc(db, 'financials', id));
      } catch (err) {
        console.warn('Firestore financial dump note:', err);
      }
    },
    [trips, showToast]
  );

  // Restore Trip from Dump
  const restoreTripFromDump = useCallback(
    async (id: string) => {
      const tripToRestore = deletedTrips.find((t) => t.id === id);
      if (!tripToRestore) return;

      const { deletedAt, deletedBy, deleteReason, ...restoredTrip } = tripToRestore;

      // 1. Remove from dump
      setDeletedTrips((prev) => {
        const next = prev.filter((t) => t.id !== id);
        saveStored('deleted_trips', next);
        return next;
      });

      // 2. Add back to active ledger
      setTrips((prev) => {
        const next = [restoredTrip, ...prev];
        saveStored('trips', next);
        return next;
      });

      showToast(`♻️ Trip ${restoredTrip.tripNumber} restored to active Financials ledger!`);

      try {
        await setDoc(doc(db, 'financials', id), restoredTrip);
        await deleteDoc(doc(db, 'deleted_financials', id));
      } catch (err) {
        console.warn('Firestore financial restore note:', err);
      }
    },
    [deletedTrips, showToast]
  );

  // Permanently Purge Trip from Dump
  const permanentlyPurgeTrip = useCallback(
    async (id: string) => {
      setDeletedTrips((prev) => {
        const next = prev.filter((t) => t.id !== id);
        saveStored('deleted_trips', next);
        return next;
      });
      showToast('⚠️ Financial record permanently deleted.');

      try {
        await deleteDoc(doc(db, 'deleted_financials', id));
      } catch (err) {
        console.warn('Firestore trip permanent purge note:', err);
      }
    },
    [showToast]
  );

  // Guided Tour
  const startTour = useCallback(() => {
    setIsTourActive(true);
    setTourStepIndex(0);
  }, []);

  const nextTourStep = useCallback(() => {
    setTourStepIndex((prev) => prev + 1);
  }, []);

  const prevTourStep = useCallback(() => {
    setTourStepIndex((prev) => Math.max(0, prev - 1));
  }, []);

  const skipTour = useCallback(() => {
    setIsTourActive(false);
    setTourStepIndex(0);
  }, []);

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        adminTab,
        setAdminTab,
        isAdminLoggedIn,
        adminPassword,
        loginAdmin,
        logoutAdmin,
        changeAdminPassword,
        isTourActive,
        tourStepIndex,
        startTour,
        nextTourStep,
        prevTourStep,
        skipTour,
        cms,
        updateCMS,
        resetCMSToDefault,
        vehicles,
        maintenanceLogs,
        addVehicle,
        updateVehicle,
        logMaintenanceService,
        deleteVehicle,
        inquiries,
        addInquiry,
        updateInquiryStatus,
        updateInquiryAdminQuote,
        deleteInquiry,
        deletedInquiries,
        deletedTrips,
        restoreInquiryFromDump,
        permanentlyPurgeInquiry,
        restoreTripFromDump,
        permanentlyPurgeTrip,
        clearAllDump,
        drivers,
        selectedDriverId,
        setSelectedDriverId,
        updateDriverStatus,
        updateDriverLocation,
        addDriver,
        updateDriver,
        isGpsTrackingActive,
        toggleGpsTracking,
        simulateFleetMovement,
        trips,
        addTripRecord,
        bulkImportTrips,
        deleteTripRecord,
        isFirestoreConnected,
        toastMessage,
        showToast,
      }}
    >
      {children}

      {/* Global Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
          <div className="bg-slate-900/95 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 max-w-md text-xs sm:text-sm backdrop-blur-md">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            <p className="flex-1 font-medium">{toastMessage}</p>
          </div>
        </div>
      )}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
