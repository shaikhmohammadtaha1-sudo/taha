export type VehicleType = 'hatchback' | 'sedan' | 'suv' | 'luxury' | 'tempo_traveller' | 'bus';

export type OwnershipType = 'company_owned' | 'partner_attached';

export interface Vehicle {
  id: string;
  name: string;
  category: VehicleType;
  model: string;
  subtitleModels?: string;
  plateNumber: string;
  seatingCapacity: number;
  luggageCapacity: number;
  baseFare: number; // Base minimum fare
  baseKm: number; // Km included in base fare
  ratePerKm: number; // Rate per extra km
  // User Outstation & Local Rental Matrix
  localBaseFare8hr80km: number;
  localExtraKmRate: number;
  localExtraHrRate: number;
  outstationPerKmRate: number;
  outstationMinKmPerDay: number;
  driverAllowancePerDay: number;
  fuelType: 'diesel' | 'petrol' | 'cng' | 'ev';
  fuelEfficiencyKmPerL: number; // Km per liter / charge
  ownershipType: OwnershipType;
  currentOdometerKm: number;
  lastServiceKm: number;
  serviceIntervalKm: number; // e.g. 10000 km
  insuranceExpiry: string;
  fitnessExpiry: string;
  status: 'active' | 'in_service' | 'inactive';
  driverId?: string;
  driverName?: string;
  imageUrl: string;
  features: string[];
  acType: 'AC' | 'Non-AC';
}

export type InquiryStatus = 'new' | 'followup' | 'quote_sent' | 'confirmed' | 'completed' | 'cancelled' | 'not_interested';

export type NotInterestedReason =
  | 'price_high'
  | 'booked_competitor'
  | 'trip_cancelled'
  | 'vehicle_unavailable'
  | 'route_unserviceable'
  | 'timing_mismatch'
  | 'other';

export interface Inquiry {
  id: string;
  inquiryNumber: string;
  customerName: string;
  phone: string;
  email: string;
  pickupLocation: string;
  dropLocation: string;
  pickupCoordinates?: [number, number];
  dropCoordinates?: [number, number];
  tripType: 'daily_ride' | 'one_way' | 'round_trip' | 'local_rental' | 'outstation_tour';
  pickupDate: string;
  pickupTime: string;
  returnDate?: string;
  returnTime?: string;
  passengers: number;
  vehicleId: string;
  vehicleName: string;
  estimatedDistanceKm: number;
  estimatedDurationHrs: number;
  calculatedBaseFare: number;
  estimatedFuelCost: number;
  estimatedTolls: number;
  driverAllowance: number;
  nightCharges: number;
  taxAmount: number;
  totalQuote: number;
  status: InquiryStatus;
  followupDate?: string;
  followupTime?: string;
  notInterestedReason?: NotInterestedReason;
  notInterestedNotes?: string;
  notes?: string;
  assignedDriverId?: string;
  assignedVehicleId?: string;
  // Admin Quote Management & Toll customization
  adminCustomTollFare?: number;
  adminCustomDiscount?: number;
  adminCustomSurcharge?: number;
  adminCustomPerKmRate?: number;
  isQuoteApprovedByAdmin?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DeletedInquiry extends Inquiry {
  deletedAt: string;
  deletedBy: string;
  deleteReason?: string;
}

export type DriverStatus = 'available' | 'on_trip' | 'offline' | 'break';

export interface Driver {
  id: string;
  name: string;
  phone: string;
  licenseNumber: string;
  photoUrl: string;
  rating: number;
  status: DriverStatus;
  assignedVehicleId?: string;
  assignedVehicleName?: string;
  assignedVehiclePlate?: string;
  currentLat: number;
  currentLng: number;
  currentLocationName: string;
  lastPingTime: string;
  batteryPct: number;
  speedKmph: number;
  todayEarnings: number;
  todayTrips: number;
  totalCompletedTrips: number;
  activeInquiryId?: string;
}

export interface MaintenanceLog {
  id: string;
  vehicleId: string;
  vehicleName: string;
  plateNumber: string;
  serviceDate: string;
  odometerKmAtService: number;
  serviceType: 'routine_oil_filter' | 'tyre_replacement' | 'brake_pads' | 'major_overhaul' | 'ac_servicing' | 'general_checkup';
  cost: number;
  garageName: string;
  notes: string;
  nextServiceDueKm: number;
}

export interface TripFinancialRecord {
  id: string;
  tripNumber: string;
  date: string;
  inquiryId?: string;
  customerName: string;
  vehiclePlate: string;
  driverName: string;
  pickupLocation: string;
  dropLocation: string;
  distanceKm: number;
  revenue: number;
  fuelExpense: number;
  tollExpense: number;
  driverPayout: number;
  maintenanceAllocated: number;
  otherExpense: number;
  netProfit: number;
  paymentStatus: 'paid' | 'pending' | 'partial';
}

export interface DeletedTripFinancialRecord extends TripFinancialRecord {
  deletedAt: string;
  deletedBy: string;
  deleteReason?: string;
}

export interface WebsiteCMS {
  brandName: string;
  brandTagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroBannerImage: string;
  promoNotice: string;
  aboutUs: string;
  fuelIndexPrice: number; // Base fuel price used in formula
  defaultTaxPct: number; // e.g. 5%
  driverNightAllowanceRate: number; // per night
  currencySymbol: string;
  enableLiveBooking: boolean;
  // Legal, Trademark & All Rights Reserved Customizations
  legalCompanyName?: string;
  copyrightNotice?: string;
  customFooterNote?: string;
  termsAndConditionsUrl?: string;
  privacyPolicyUrl?: string;
}

export type AdminTabType = 'analytics' | 'inquiries' | 'dump' | 'live_map' | 'fleet' | 'financials' | 'cms' | 'export_apk';

export interface TourStep {
  targetId: string;
  title: string;
  description: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}
